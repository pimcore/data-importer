
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_dataimporter_bundle = "/bundles/pimcoredataimporter/studio/build/9473d1a79cdd/static/js/remoteEntry.js"

      window.alternativePluginExportPaths.pimcore_dataimporter_bundle = "/plugins"
    