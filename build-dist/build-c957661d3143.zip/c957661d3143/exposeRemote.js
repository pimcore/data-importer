
      if (window.pluginRemotes === undefined) {
        window.pluginRemotes = {}
      }

      if (window.alternativePluginExportPaths === undefined) {
        window.alternativePluginExportPaths = {}
      }

      window.pluginRemotes.pimcore_dataimporter_bundle = "/bundles/pimcoredataimporter/studio/build/c957661d3143/static/js/remoteEntry.js"

      window.alternativePluginExportPaths.pimcore_dataimporter_bundle = "/plugins"
    