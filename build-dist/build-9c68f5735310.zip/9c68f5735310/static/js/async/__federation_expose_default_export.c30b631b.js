/*! For license information please see __federation_expose_default_export.c30b631b.js.LICENSE.txt */
"use strict";(self["chunk_pimcore_dataimporter_bundle "]=self["chunk_pimcore_dataimporter_bundle "]||[]).push([["525"],{4533(e,t,r){r.r(t),r.d(t,{DataImporterPlugin:()=>iq});var a=r(2977),n=r(4848),i=r(5446),o=r.n(i),l=r(4781),s=r(2696),d=r(3729),c=r(2703),p=r(8096);let u=(0,p.createStyles)(e=>{let{css:t}=e;return{formWrapper:t`
    display: contents;

    > form {
      display: flex;
      flex-direction: column;
      flex: 1;
      min-height: 0;
    }
  `}});var m=r(4353),g=r.n(m),h=r(445),f=r.n(h),x=r(8267);g().extend(f());let v="DD-MM-YYYY HH:mm";function y(e){return{id:e.id,name:e.name,read:e.read??!1,update:e.update??!1,delete:e.delete??!1}}function b(e){return{id:e.id,name:e.name??"",read:e.read??!1,update:e.update??!1,delete:e.delete??!1}}function j(e,t){var r;let a=S(e.loaderConfig,t.loaderConfig),n=S(e.interpreterConfig,t.interpreterConfig),i=function(e){if((null==e?void 0:e.type)===void 0)return e;let t=(null==e?void 0:e.settings)??{};if("asset"===e.type)return{...e,settings:{assetPath:C(t.assetPath)}};if("upload"===e.type)return{...e,settings:{uploadFilePath:C(t.uploadFilePath)}};if("http"===e.type){let r=C(t.schema),a=C(t.url).replace(/^\s*[a-z][a-z0-9+.-]*:\/\//i,"");return{...e,settings:{schema:r,url:a}}}return"sftp"===e.type?{...e,settings:{host:C(t.host),port:C(t.port),username:C(t.username),password:C(t.password),remotePath:C(t.remotePath)}}:"push"===e.type?{...e,settings:{apiKey:C(t.apiKey),ignoreNotEmptyQueue:I(t.ignoreNotEmptyQueue)}}:"sql"===e.type?{...e,settings:{connection:C(t.connection),select:C(t.select),from:C(t.from),where:C(t.where),groupBy:C(t.groupBy)}}:e}(a),o=function(e){if((null==e?void 0:e.type)===void 0)return e;let t=e.settings??{};return"csv"===e.type?{...e,settings:{skipFirstRow:I(t.skipFirstRow),saveHeaderName:I(t.saveHeaderName),delimiter:C(t.delimiter),enclosure:C(t.enclosure),escape:C(t.escape)}}:"json"===e.type?{...e,settings:{path:C(t.path)}}:"xml"===e.type?{...e,settings:{xpath:C(t.xpath),schema:C(t.schema)}}:"xlsx"===e.type?{...e,settings:{skipFirstRow:I(t.skipFirstRow),sheetName:C(t.sheetName)}}:"sql"===e.type?{...e,settings:{}}:e}(n);return{...t,general:{...t.general,active:e.active,description:e.description,group:e.group},loaderConfig:i,interpreterConfig:o,resolverConfig:e.resolverConfig??t.resolverConfig,mappingConfig:e.mappingConfig??t.mappingConfig,processingConfig:e.processingConfig??t.processingConfig,executionConfig:void 0!==e.executionConfig?{...e.executionConfig,scheduledAt:function(e){if(void 0===e||""===e)return;let t=g()(e);return t.isValid()?t.format(v):e}(e.executionConfig.scheduledAt)}:t.executionConfig,permissions:{role:((null==(r=e.permissions)?void 0:r.roles)??[]).map(y),user:((null==r?void 0:r.users)??[]).map(y)}}}function S(e,t){return void 0===e?t:void 0===e.type||""===e.type?t??e:{...t,...e,settings:{...null==t?void 0:t.settings,...e.settings}}}function C(e){return null==e?"":String(e)}function I(e){return"boolean"==typeof e?e:"1"===e||1===e||"true"===e}function w(e){return Array.isArray(e)?void 0:e}function T(e,t){var r,a,n,i;let o=(function(e){if(Array.isArray(e))return e;if(null===e||"object"!=typeof e)return[];let t=[];for(let r of Object.values(e))for(let e of Array.isArray(r)?r:[r])"object"==typeof e&&null!==e&&t.push(e);return t})(e.mappingConfig).map(e=>({...{...e,mappingId:e.mappingId??(0,x.uuid)()}}));return{active:(null==(r=e.general)?void 0:r.active)??!1,name:t,description:(null==(a=e.general)?void 0:a.description)??"",group:(null==(n=e.general)?void 0:n.group)??"",loaderConfig:w(e.loaderConfig),interpreterConfig:w(e.interpreterConfig),resolverConfig:function(e){let t=w(e);if(void 0!==t)return{...t,loadingStrategy:w(t.loadingStrategy),createLocationStrategy:w(t.createLocationStrategy),locationUpdateStrategy:w(t.locationUpdateStrategy),publishingStrategy:w(t.publishingStrategy)}}(e.resolverConfig),mappingConfig:o,processingConfig:w(e.processingConfig),executionConfig:function(e){let t=w(e);if(void 0!==t)return{...t,scheduledAt:function(e){if(void 0===e||""===e)return;let t=g()(e,v,!0);return t.isValid()?t.format("YYYY-MM-DD HH:mm"):e}("string"==typeof t.scheduledAt&&""!==t.scheduledAt?t.scheduledAt:void 0)}}(e.executionConfig),permissions:{roles:((null==(i=e.permissions)?void 0:i.role)??[]).map(b),users:((null==i?void 0:i.user)??[]).map(b)}}}let D=(0,i.createContext)({readOnly:!1}),F=e=>{let{readOnly:t,children:r}=e,a=(0,i.useMemo)(()=>({readOnly:t}),[t]);return(0,n.jsx)(D.Provider,{value:a,children:r})},N=()=>(0,i.useContext)(D).readOnly;var k=r(1943),$=r.n(k);let L=(0,p.createStyles)(e=>{let{css:t,token:r}=e;return{stepHeading:t`
      color: ${r.colorPrimary};
      font-size: 14px;
      font-weight: ${r.fontWeightStrong};
      height: 32px;
      line-height: 32px;
      margin: 0;
      padding-left: ${r.paddingXXS}px;
    `}}),M=e=>{let{children:t}=e,{styles:r}=L();return(0,n.jsx)("div",{className:r.stepHeading,children:t})};var P=r(3842);let R=(0,p.createStyles)((e,t)=>{let{css:r}=e;return{container:r`
      max-width: ${t}px;
      width: 100%;
    `}}),A=e=>{let{children:t}=e,{medium:r}=(0,P.useFieldWidth)(),{styles:a}=R(r);return(0,n.jsx)("div",{className:a.container,children:t})},O=e=>{let{children:t,theme:r="card-with-highlight",contentPadding:a="extra-small",noWidthLimit:i=!1,...o}=e;if("card-with-highlight"===r){let e=(0,n.jsx)(s.Space,{className:"w-full",direction:"vertical",size:"extra-small",children:t});return(0,n.jsx)(s.FormKit.Panel,{...o,contentPadding:a,theme:r,children:i?e:(0,n.jsx)(A,{children:e})})}let l=(0,n.jsx)(s.FormKit.Panel,{...o,contentPadding:a,theme:r,children:t});return i?l:(0,n.jsx)(A,{children:l})},E=(e,t)=>String((null==t?void 0:t.label)??"").toLowerCase().includes(e.toLowerCase()),B="DataImporter/DynamicTypes/Adapter/DataImporterDataObject",z="DataImporter/DynamicTypes/Interpreter/Registry",H="DataImporter/DynamicTypes/Interpreter/Csv",q="DataImporter/DynamicTypes/Interpreter/Json",W="DataImporter/DynamicTypes/Interpreter/Sql",X="DataImporter/DynamicTypes/Interpreter/Xlsx",V="DataImporter/DynamicTypes/Interpreter/Xml",_="DataImporter/DynamicTypes/Loader/Registry",G="DataImporter/DynamicTypes/Loader/Asset",U="DataImporter/DynamicTypes/Loader/Upload",K="DataImporter/DynamicTypes/Loader/Http",Q="DataImporter/DynamicTypes/Loader/Sftp",Y="DataImporter/DynamicTypes/Loader/Push",J="DataImporter/DynamicTypes/Loader/Sql",Z="DataImporter/DynamicTypes/Resolver/Registry",ee="DataImporter/DynamicTypes/Resolver/Loading/NotLoad",et="DataImporter/DynamicTypes/Resolver/Loading/Id",er="DataImporter/DynamicTypes/Resolver/Loading/Path",ea="DataImporter/DynamicTypes/Resolver/Loading/Attribute",en="DataImporter/DynamicTypes/Resolver/Location/Creation/StaticPath",ei="DataImporter/DynamicTypes/Resolver/Location/Creation/FindOrCreateFolder",eo="DataImporter/DynamicTypes/Resolver/Location/Creation/FindParent",el="DataImporter/DynamicTypes/Resolver/Location/Creation/DoNotCreate",es="DataImporter/DynamicTypes/Resolver/Location/Update/NoChange",ed="DataImporter/DynamicTypes/Resolver/Location/Update/StaticPath",ec="DataImporter/DynamicTypes/Resolver/Location/Update/FindOrCreateFolder",ep="DataImporter/DynamicTypes/Resolver/Location/Update/FindParent",eu="DataImporter/DynamicTypes/Resolver/Publishing/NoChangeUnpublishNew",em="DataImporter/DynamicTypes/Resolver/Publishing/NoChangePublishNew",eg="DataImporter/DynamicTypes/Resolver/Publishing/AlwaysPublish",eh="DataImporter/DynamicTypes/Resolver/Publishing/AttributeBased",ef="DataImporter/DynamicTypes/Transformer/Registry",ex="DataImporter/DynamicTypes/Transformer/Trim",ev="DataImporter/DynamicTypes/Transformer/Combine",ey="DataImporter/DynamicTypes/Transformer/StaticText",eb="DataImporter/DynamicTypes/Transformer/StringReplace",ej="DataImporter/DynamicTypes/Transformer/Date",eS="DataImporter/DynamicTypes/Transformer/Numeric",eC="DataImporter/DynamicTypes/Transformer/Explode",eI="DataImporter/DynamicTypes/Transformer/ConditionalConversion",ew="DataImporter/DynamicTypes/Transformer/ObjectField",eT="DataImporter/DynamicTypes/Transformer/LoadAsset",eD="DataImporter/DynamicTypes/Transformer/FlattenArray",eF="DataImporter/DynamicTypes/Transformer/ReduceArrayKeyValuePairs",eN="DataImporter/DynamicTypes/Transformer/HtmlDecode",ek="DataImporter/DynamicTypes/Transformer/Boolean",e$="DataImporter/DynamicTypes/Transformer/AsArray",eL="DataImporter/DynamicTypes/Transformer/AsColor",eM="DataImporter/DynamicTypes/Transformer/AsCountries",eP="DataImporter/DynamicTypes/Transformer/Gallery",eR="DataImporter/DynamicTypes/Transformer/ImageAdvanced",eA="DataImporter/DynamicTypes/Transformer/QuantityValue",eO="DataImporter/DynamicTypes/Transformer/QuantityValueArray",eE="DataImporter/DynamicTypes/Transformer/InputQuantityValue",eB="DataImporter/DynamicTypes/Transformer/InputQuantityValueArray",ez="DataImporter/DynamicTypes/Transformer/AsGeobounds",eH="DataImporter/DynamicTypes/Transformer/AsGeopoint",eq="DataImporter/DynamicTypes/Transformer/AsGeopolygon",eW="DataImporter/DynamicTypes/Transformer/AsGeopolyline",eX="DataImporter/DynamicTypes/Transformer/LoadDataObject",eV="DataImporter/DynamicTypes/Transformer/ImportAsset",e_="DataImporter/DynamicTypes/DataTarget/Registry",eG="DataImporter/DynamicTypes/DataTarget/Direct",eU="DataImporter/DynamicTypes/DataTarget/Classificationstore",eK="DataImporter/DynamicTypes/DataTarget/ClassificationStoreBatch",eQ="DataImporter/DynamicTypes/DataTarget/ManyToManyRelation",eY=e=>{let{configName:t}=e,{t:r}=(0,l.useTranslation)(),o=(0,i.useMemo)(()=>a.container.get(_),[]),d=(0,i.useMemo)(()=>a.container.get(z),[]),c=(0,i.useMemo)(()=>o.getDynamicTypes(),[o]),p=(0,i.useMemo)(()=>d.getDynamicTypes(),[d]),u=(0,i.useMemo)(()=>c.map(e=>{let{id:t,label:a}=e;return{value:t,label:r(a)}}),[c,r]),m=(0,i.useMemo)(()=>p.map(e=>{let{id:t,label:a}=e;return{value:t,label:r(a)}}),[p,r]);return(0,n.jsxs)(P.FieldWidthProvider,{fieldWidthValues:{medium:900},children:[(0,n.jsx)(M,{children:r("data-importer.data-source.title")}),(0,n.jsxs)(O,{children:[(0,n.jsx)(s.Form.Item,{label:r("data-importer.data-source.type-label"),name:["loaderConfig","type"],required:!0,children:(0,n.jsx)(s.Select,{filterOption:E,options:u,showSearch:!0})}),c.map(e=>(0,n.jsx)(s.Form.Conditional,{condition:t=>{var r;return(null==(r=t.loaderConfig)?void 0:r.type)===e.id},children:(0,n.jsx)(O,{theme:"fieldset",title:r(e.label),children:e.renderSettings(t)})},e.id))]}),(0,n.jsxs)(O,{title:r("data-importer.file-format.title"),children:[(0,n.jsx)(s.Form.Item,{label:r("data-importer.file-format.title"),name:["interpreterConfig","type"],required:!0,children:(0,n.jsx)(s.Select,{filterOption:E,options:m,showSearch:!0})}),p.map(e=>(0,n.jsx)(s.Form.Conditional,{condition:t=>{var r;return(null==(r=t.interpreterConfig)?void 0:r.type)===e.id},children:(0,n.jsx)(O,{border:!0,theme:"fieldset",title:r(e.label),children:e.renderSettings()})},e.id))]})]})};var eJ=r(7984),eZ=r(1436);let e0=eZ.api.enhanceEndpoints({addTagTypes:["Bundle Data Importer"]}).injectEndpoints({endpoints:e=>({bundleDataImporterClassificationstoreLoadAttributes:e.query({query:e=>({url:"/pimcore-studio/api/bundle/data-importer/classificationstore/attributes",params:{classId:e.classId}}),providesTags:["Bundle Data Importer"]}),bundleDataImporterClassificationstoreLoadKeyName:e.query({query:e=>({url:"/pimcore-studio/api/bundle/data-importer/classificationstore/key-name",params:{keyId:e.keyId}}),providesTags:["Bundle Data Importer"]}),bundleDataImporterClassificationstoreLoadKeys:e.query({query:e=>({url:"/pimcore-studio/api/bundle/data-importer/classificationstore/keys",params:{classId:e.classId,fieldName:e.fieldName,transformationResultType:e.transformationResultType,sort:e.sort,start:e.start,limit:e.limit,searchfilter:e.searchfilter,filter:e.filter}}),providesTags:["Bundle Data Importer"]}),bundleDataImporterConfigCalculateTransformationResultType:e.query({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/transformation-result-type`,method:"POST",body:e.bundleDataImporterCalculateTransformationResultTypeParameters}),providesTags:["Bundle Data Importer"]}),bundleDataImporterConfigCancelExecution:e.mutation({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/cancel-execution`,method:"PUT"}),invalidatesTags:["Bundle Data Importer"]}),bundleDataImporterConfigCheckImportProgress:e.query({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/check-import-progress`}),providesTags:["Bundle Data Importer"]}),bundleDataImporterConfigCopyPreview:e.mutation({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/copy-preview`,method:"POST",body:e.bundleDataImporterCopyPreviewParameters}),invalidatesTags:["Bundle Data Importer"]}),bundleDataImporterConfigGet:e.query({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}`}),providesTags:["Bundle Data Importer"]}),bundleDataImporterConfigSave:e.mutation({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}`,method:"PUT",body:e.bundleDataImporterConfigurationSaveParameters}),invalidatesTags:["Bundle Data Importer"]}),bundleDataImporterConfigHasImportFileUploaded:e.query({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/has-import-file-uploaded`}),providesTags:["Bundle Data Importer"]}),bundleDataImporterConfigLoadColumnHeaders:e.query({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/column-headers`,method:"POST",body:e.bundleDataImporterCopyPreviewParameters}),providesTags:["Bundle Data Importer"]}),bundleDataImporterConfigLoadPreview:e.query({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/load-preview`,method:"POST",body:e.bundleDataImporterLoadPreviewParameters}),providesTags:["Bundle Data Importer"]}),bundleDataImporterConfigLoadTransformationResult:e.query({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/transformation-result`,method:"POST",body:e.bundleDataImporterLoadPreviewParameters}),providesTags:["Bundle Data Importer"]}),bundleDataImporterConfigStartImport:e.mutation({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/start-import`,method:"PUT"}),invalidatesTags:["Bundle Data Importer"]}),bundleDataImporterConfigUploadImportFile:e.mutation({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/upload-import-file`,method:"POST",body:e.body}),invalidatesTags:["Bundle Data Importer"]}),bundleDataImporterConfigUploadPreview:e.mutation({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/upload-preview`,method:"POST",body:e.body}),invalidatesTags:["Bundle Data Importer"]}),bundleDataImporterConnectionList:e.query({query:()=>({url:"/pimcore-studio/api/bundle/data-importer/connection/list"}),providesTags:["Bundle Data Importer"]}),bundleDataImporterDataTypeLoadClassAttributes:e.query({query:e=>({url:"/pimcore-studio/api/bundle/data-importer/data-type/class-attributes",params:{classId:e.classId,loadAdvancedRelations:e.loadAdvancedRelations,systemRead:e.systemRead,systemWrite:e.systemWrite,transformationResultType:e.transformationResultType}}),providesTags:["Bundle Data Importer"]}),bundleDataImporterDataTypeLoadUnitData:e.query({query:()=>({url:"/pimcore-studio/api/bundle/data-importer/data-type/unit-data"}),providesTags:["Bundle Data Importer"]}),bundleDataImporterUtilityCheckCrontab:e.query({query:e=>({url:"/pimcore-studio/api/bundle/data-importer/utility/check-crontab",params:{cronExpression:e.cronExpression}}),providesTags:["Bundle Data Importer"]})}),overrideExisting:!1}),{useBundleDataImporterClassificationstoreLoadAttributesQuery:e1,useBundleDataImporterClassificationstoreLoadKeyNameQuery:e2,useBundleDataImporterClassificationstoreLoadKeysQuery:e3,useBundleDataImporterConfigCalculateTransformationResultTypeQuery:e5,useBundleDataImporterConfigCancelExecutionMutation:e9,useBundleDataImporterConfigCheckImportProgressQuery:e6,useBundleDataImporterConfigCopyPreviewMutation:e4,useBundleDataImporterConfigGetQuery:e7,useBundleDataImporterConfigSaveMutation:e8,useBundleDataImporterConfigHasImportFileUploadedQuery:te,useBundleDataImporterConfigLoadColumnHeadersQuery:tt,useBundleDataImporterConfigLoadPreviewQuery:tr,useBundleDataImporterConfigLoadTransformationResultQuery:ta,useBundleDataImporterConfigStartImportMutation:tn,useBundleDataImporterConfigUploadImportFileMutation:ti,useBundleDataImporterConfigUploadPreviewMutation:to,useBundleDataImporterConnectionListQuery:tl,useBundleDataImporterDataTypeLoadClassAttributesQuery:ts,useBundleDataImporterDataTypeLoadUnitDataQuery:td,useBundleDataImporterUtilityCheckCrontabQuery:tc}=e0,tp=e0.enhanceEndpoints({addTagTypes:["DataHubConfigs"],endpoints:{bundleDataImporterClassificationstoreLoadAttributes:{providesTags:[]},bundleDataImporterClassificationstoreLoadKeyName:{providesTags:[]},bundleDataImporterClassificationstoreLoadKeys:{providesTags:[]},bundleDataImporterConfigCancelExecution:{invalidatesTags:[]},bundleDataImporterConfigCheckImportProgress:{providesTags:[]},bundleDataImporterConfigCalculateTransformationResultType:{providesTags:[]},bundleDataImporterConfigCopyPreview:{invalidatesTags:[]},bundleDataImporterConfigLoadColumnHeaders:{providesTags:[]},bundleDataImporterConfigLoadPreview:{providesTags:[]},bundleDataImporterConfigLoadTransformationResult:{providesTags:[]},bundleDataImporterConfigGet:{providesTags:[]},bundleDataImporterConfigSave:{invalidatesTags:["DataHubConfigs"]},bundleDataImporterConfigHasImportFileUploaded:{providesTags:[]},bundleDataImporterConfigUploadImportFile:{invalidatesTags:[]},bundleDataImporterConfigUploadPreview:{invalidatesTags:[]},bundleDataImporterConfigStartImport:{invalidatesTags:[]},bundleDataImporterConnectionList:{providesTags:[]},bundleDataImporterDataTypeLoadClassAttributes:{providesTags:[]},bundleDataImporterDataTypeLoadUnitData:{providesTags:[]},bundleDataImporterUtilityCheckCrontab:{providesTags:[]}}}),{useBundleDataImporterConfigGetQuery:tu,useBundleDataImporterConfigSaveMutation:tm,useBundleDataImporterConfigHasImportFileUploadedQuery:tg,useBundleDataImporterConfigCheckImportProgressQuery:th,useBundleDataImporterConfigStartImportMutation:tf,useBundleDataImporterConfigCancelExecutionMutation:tx,useBundleDataImporterConnectionListQuery:tv}=tp,ty=(0,i.createContext)(void 0),tb=e=>{let{scope:t,children:r}=e,a=(0,i.useMemo)(()=>t,[t]);return(0,n.jsx)(ty.Provider,{value:a,children:r})},tj=()=>(0,i.useContext)(ty);function tS(e){let{configName:t,enabled:r,getCurrentConfig:a,forceRefreshToken:n}=e,o=tj(),[l,s]=(0,i.useState)(void 0),[d,c]=(0,i.useState)(0),[p,u]=(0,i.useState)(!1),{data:m,isLoading:g,isFetching:h,isError:f,error:x,refetch:v}=tr(l,{skip:!r||void 0===l,refetchOnMountOrArgChange:!1}),y=(0,i.useCallback)((e,r)=>{let n=null==a?void 0:a();c(e),s({name:t,bundleDataImporterLoadPreviewParameters:{recordNumber:e,...void 0!==n&&{currentConfig:n},...void 0!==o&&{previewScope:o}}}),(null==r?void 0:r.forceRefetch)===!0&&u(!0)},[t,a,o]);(0,i.useEffect)(()=>{r&&void 0===l&&y(0)},[r,l,y]),(0,i.useEffect)(()=>{p&&void 0!==l&&(u(!1),v())},[p,l,v]);let b=(0,i.useRef)(!0);(0,i.useEffect)(()=>{if(void 0!==n&&0!==n){if(b.current){b.current=!1;return}r&&void 0!==l&&u(!0)}},[n,r,l]);let j=(null==m?void 0:m.previewRecordIndex)??d;return{dataPreview:(0,i.useMemo)(()=>(null==m?void 0:m.dataPreview)??[],[m]),currentRecordIndex:j,isLoading:g,isFetching:h,isError:f,error:x,load:y}}var tC=r(807);let tI=(0,eJ.createColumnHelper)(),tw=e=>{let{configName:t,isActive:r,onPreviewDataChange:a}=e,{t:o}=(0,l.useTranslation)(),d=s.Form.useFormInstance(),[p,u]=(0,i.useState)(0),[m,g]=(0,i.useState)(""),[h,f]=(0,i.useState)(!1),{data:x}=tu({name:t}),v=(0,i.useCallback)(()=>j(d.getFieldsValue(!0),(null==x?void 0:x.configuration)??{}),[d,x]),[y,{isLoading:b,error:S}]=e4(),C=tj(),I=s.Form.useWatch(["interpreterConfig","type"]),{dataPreview:w,currentRecordIndex:T,isLoading:D,isFetching:F,isError:N,error:k,load:$}=tS({configName:t,enabled:r,getCurrentConfig:v});(0,i.useEffect)(()=>{u(T)},[T]),(0,i.useEffect)(()=>{null!=k&&("object"!=typeof k||null===k||404!==k.status)&&(0,c.trackError)(new c.ApiError(k))},[k]),(0,i.useEffect)(()=>{void 0!==S&&(0,c.trackError)(new c.ApiError(S))},[S]);let L=async()=>{"error"in await y({name:t,bundleDataImporterCopyPreviewParameters:{currentConfig:v(),previewScope:C}})||($(0,{forceRefetch:!0}),null==a||a())},P=[{key:"upload",label:o("data-importer.preview-import.upload-file"),onClick:()=>{f(!0)}},{key:"copy",label:o("data-importer.preview-import.copy-from-source"),onClick:()=>{L()}}],R=(0,i.useMemo)(()=>[tI.accessor("label",{header:o("data-importer.preview-import.column.label"),size:300}),tI.accessor("data",{header:o("data-importer.preview-import.column.data"),meta:{autoWidth:!0}})],[o]),A=(0,i.useMemo)(()=>N?[]:w.map(e=>({...e,data:"string"==typeof e.data?e.data:JSON.stringify(e.data)})),[w,N]),O=(0,i.useMemo)(()=>{if(""===m)return A;let e=m.toLowerCase();return A.filter(t=>(t.label??"").toLowerCase().includes(e))},[A,m]),E=D||F||b;return(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(s.Box,{margin:{bottom:"extra-small"},children:(0,n.jsxs)(s.Flex,{align:"center",gap:"extra-small",justify:"space-between",children:[(0,n.jsxs)(s.Flex,{align:"center",gap:"extra-small",children:[(0,n.jsx)(M,{children:o("data-importer.preview-import.title")}),(0,n.jsxs)(tC.Ay,{componentDisabled:!1,children:[(0,n.jsx)(s.Dropdown,{menu:{items:P},children:(0,n.jsx)(s.DropdownButton,{disabled:E,type:"default",children:o("data-importer.preview-import.choose-preview-data")})}),(0,n.jsx)(s.IconButton,{disabled:E||p<=0,icon:{value:"chevron-left"},onClick:()=>{$(Math.max(0,p-1))},tooltip:{title:o("data-importer.preview-import.prev")},type:"default"}),(0,n.jsx)(s.IconButton,{disabled:E,icon:{value:"chevron-right"},onClick:()=>{$(p+1)},tooltip:{title:o("data-importer.preview-import.next")},type:"default"})]})]}),(0,n.jsx)(s.SearchInput,{maxWidth:320,onChange:e=>{g(e.target.value)},placeholder:o("data-importer.preview-import.search-placeholder"),withClear:!0,withPrefix:!0})]})}),(0,n.jsx)(s.Grid,{autoWidth:!0,columns:R,data:O,isLoading:E}),(0,n.jsx)(s.ImportModal,{action:`${(0,eZ.getPrefix)()}/bundle/data-importer/config/${t}/upload-preview`,data:{...void 0!==C&&{previewScope:C},...void 0!==I&&{interpreterType:I}},onOpenChange:e=>{f(e)},onUploadSuccess:()=>{f(!1),$(0,{forceRefetch:!0}),null==a||a()},open:h,title:o("data-importer.preview-import.upload-file")})]})};var tT=r(3513);let tD=e=>{let{registry:t,...r}=e,{t:a}=(0,l.useTranslation)(),o=(0,i.useMemo)(()=>t.getDynamicTypesForGroup("loading"),[t]),d=(0,i.useMemo)(()=>o.map(e=>{let{type:t,label:r}=e;return{value:t,label:a(r)}}),[o,a]);return(0,n.jsxs)(O,{title:a("data-importer.resolver.element-loading"),children:[(0,n.jsx)(s.Form.Item,{label:a("data-importer.resolver.loading-strategy"),name:["resolverConfig","loadingStrategy","type"],tooltip:a("data-importer.resolver.loading-strategy.tooltip"),children:(0,n.jsx)(s.Select,{filterOption:E,options:d,showSearch:!0})}),o.map(e=>(0,n.jsx)(s.Form.Conditional,{condition:t=>{var r,a;return(null==(a=t.resolverConfig)||null==(r=a.loadingStrategy)?void 0:r.type)===e.type},children:e.renderSettings(r)},e.id))]})},tF=e=>{let{registry:t,...r}=e,{t:a}=(0,l.useTranslation)(),o=(0,i.useMemo)(()=>t.getDynamicTypesForGroup("createLocation"),[t]),d=(0,i.useMemo)(()=>o.map(e=>{let{type:t,label:r}=e;return{value:t,label:a(r)}}),[o,a]);return(0,n.jsxs)(O,{title:a("data-importer.resolver.element-creation"),children:[(0,n.jsx)(s.Form.Item,{label:a("data-importer.resolver.create-location-strategy"),name:["resolverConfig","createLocationStrategy","type"],tooltip:a("data-importer.resolver.create-location-strategy.tooltip"),children:(0,n.jsx)(s.Select,{filterOption:E,options:d,showSearch:!0})}),o.map(e=>(0,n.jsx)(s.Form.Conditional,{condition:t=>{var r,a;return(null==(a=t.resolverConfig)||null==(r=a.createLocationStrategy)?void 0:r.type)===e.type},children:e.renderSettings(r)},e.id))]})},tN=e=>{let{registry:t,...r}=e,{t:a}=(0,l.useTranslation)(),o=(0,i.useMemo)(()=>t.getDynamicTypesForGroup("updateLocation"),[t]),d=(0,i.useMemo)(()=>o.map(e=>{let{type:t,label:r}=e;return{value:t,label:a(r)}}),[o,a]);return(0,n.jsxs)(O,{title:a("data-importer.resolver.element-location-update"),children:[(0,n.jsx)(s.Form.Item,{label:a("data-importer.resolver.location-update-strategy"),name:["resolverConfig","locationUpdateStrategy","type"],tooltip:a("data-importer.resolver.location-update-strategy.tooltip"),children:(0,n.jsx)(s.Select,{filterOption:E,options:d,showSearch:!0})}),o.map(e=>(0,n.jsx)(s.Form.Conditional,{condition:t=>{var r,a;return(null==(a=t.resolverConfig)||null==(r=a.locationUpdateStrategy)?void 0:r.type)===e.type},children:e.renderSettings(r)},e.id))]})},tk=e=>{let{registry:t,...r}=e,{t:a}=(0,l.useTranslation)(),o=(0,i.useMemo)(()=>t.getDynamicTypesForGroup("publishing"),[t]),d=(0,i.useMemo)(()=>o.map(e=>{let{type:t,label:r}=e;return{value:t,label:a(r)}}),[o,a]);return(0,n.jsxs)(O,{title:a("data-importer.resolver.element-publishing"),children:[(0,n.jsx)(s.Form.Item,{label:a("data-importer.resolver.publishing-strategy"),name:["resolverConfig","publishingStrategy","type"],tooltip:a("data-importer.resolver.publishing-strategy.tooltip"),children:(0,n.jsx)(s.Select,{filterOption:E,options:d,showSearch:!0})}),o.map(e=>(0,n.jsx)(s.Form.Conditional,{condition:t=>{var r,a;return(null==(a=t.resolverConfig)||null==(r=a.publishingStrategy)?void 0:r.type)===e.type},children:e.renderSettings(r)},e.id))]})},t$=e=>{let{configName:t,columnHeaderOptions:r,isActive:o}=e,{t:d}=(0,l.useTranslation)(),p=(0,c.useSettings)(),u=(0,i.useMemo)(()=>(p.validLanguages??[]).map(e=>({value:e,label:e})),[p.validLanguages]),{data:m,isLoading:g}=(0,tT.useClassDefinitionCollectionQuery)(void 0,{skip:!o}),h=((null==m?void 0:m.items)??[]).map(e=>({value:e.id,label:e.name})),f=(0,i.useMemo)(()=>a.container.get(Z),[]);return(0,n.jsx)(P.FieldWidthProvider,{fieldWidthValues:{medium:600},children:(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(M,{children:d("data-importer.resolver.title")}),(0,n.jsx)(O,{children:(0,n.jsx)(s.Form.Item,{label:d("data-importer.resolver.class"),name:["resolverConfig","dataObjectClassId"],required:!0,children:(0,n.jsx)(s.Select,{filterOption:E,loadingSkeleton:g,options:h,placeholder:d("data-importer.resolver.class-placeholder"),showSearch:!0})})}),(0,n.jsx)(tD,{columnHeaderOptions:r,languageOptions:u,registry:f}),(0,n.jsx)(tF,{classOptions:h,columnHeaderOptions:r,isLoadingClasses:g,languageOptions:u,registry:f}),(0,n.jsx)(tN,{classOptions:h,columnHeaderOptions:r,isLoadingClasses:g,languageOptions:u,registry:f}),(0,n.jsx)(tk,{columnHeaderOptions:r,registry:f})]})})};function tL(e){var t;return{dataIndex:String(e.dataIndex??""),label:String(e.label??e.dataIndex??""),value:"string"==typeof(t=e.data)?t:void 0!==t?JSON.stringify(t):""}}let tM=(0,p.createStyles)(e=>{let{css:t,token:r}=e;return{mappingLayout:t`
      width: 100%;
      height: 100%;
      min-width: 720px;
    `,mappingLayoutLeft:t`
      flex: 2;
      min-width: 0;
      height: 100%;
      overflow-y: scroll;
    `,mappingLayoutCenter:t`
      width: 46px;
      flex-shrink: 0;
      height: 100%;
    `,mappingLayoutCenterArrow:t`
      position: sticky;
      top: 50%;
      transform: translateY(-50%);
      pointer-events: none;
      color: ${r.colorFillActive};
    `,mappingLayoutRight:t`
      flex: 3;
      min-width: 0;
      height: 100%;
      overflow-y: scroll;
    `,panel:t`
      height: 100%;
    `,panelScrollable:t`
      flex: 1;
      min-height: 0;
      padding: 0 ${r.paddingSM}px ${r.paddingMD}px;
    `,sourcesPanel:t`
      height: 100%;
      background: ${r.colorFillTertiary};
    `,sourcesHeader:t`
      padding: 0 ${r.paddingMD}px;
      height: 52px;
      box-sizing: border-box;
      flex-shrink: 0;
    `,sourcesTitle:t`
      color: ${r.colorPrimary};
      font-weight: 600;
      font-size: ${r.fontSizeLG}px;
      margin: 0;
    `,sourceRowOuter:t`
      border-left: 2px solid ${r.colorBorder};
      border-radius: ${r.borderRadiusLG}px;
      box-shadow: ${r.boxShadowTertiary};
      transition: opacity 0.15s;
      position: relative;

      &:hover .source-add-btn {
        opacity: 1;
        pointer-events: auto;
      }
    `,sourceRowOuterMapped:t`
      border-left-color: ${r.colorPrimaryBorderHover};
    `,sourceRowOuterFaded:t`
      opacity: 0.4;
    `,sourceRowInner:t`
      background: ${r.colorBgContainer};
      border: 1px solid ${r.colorBorderSecondary};
      border-left: none;
      border-radius: ${r.borderRadiusLG}px;
      min-height: 40px;
      overflow: hidden;
    `,sourceRowInnerMapped:t`
      cursor: pointer;
    `,sourceRowInnerUnmapped:t`
      cursor: pointer;
    `,sourceRowTagArea:t`
      flex: 1;
      padding: ${r.paddingXS}px ${r.paddingXS}px;
      min-width: 0;
    `,sourceTagInner:t`
      display: inline-flex;
      align-items: center;
    `,sourceAddBtn:t`
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.15s;
      flex-shrink: 0;
      display: inline-flex;
      align-items: center;
    `,sourceValue:t`
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      color: ${r.colorTextDescription};
      font-size: ${r.fontSize}px;
      padding: 0 ${r.paddingXS}px;
      min-width: 0;
    `,noContentWrapper:t`
      flex: 1;
      padding: ${r.paddingXL}px ${r.paddingMD}px;
    `,sourceRowsSpace:t`
      width: 100%;
    `,badgeMappedCount:t`
      & .ant-badge-count {
        background-color: ${r.colorFillActive};
        color: ${r.colorPrimary};
        box-shadow: none;
      }
    `,droppablePanel:t`
      width: 100%;

      & .dnd--drag-active,
      & .dnd--drag-valid,
      & .dnd--drag-error {
        background: unset !important;
        border: unset !important;
        outline: none !important;
      }
    `,panelDndWrapper:t`
      & .ant-collapse {
        transition: border-color 0.15s, border-style 0.15s;
      }

      &.dnd--drag-active .ant-collapse {
        border-style: dashed !important;
        border-color: ${r.colorBorder} !important;
      }

      &.dnd--drag-valid .ant-collapse {
        border-style: dashed !important;
        border-color: ${r.colorPrimary} !important;
      }

      &.dnd--drag-error .ant-collapse {
        border-style: dashed !important;
        border-color: ${r.colorError} !important;
      }
    `,panelExpanded:t`
      & .ant-collapse {
        border-color: ${r.colorPrimaryBorder} !important;
      }
    `,sourceDropZone:t`
      border-radius: ${r.borderRadius}px;
    `,mappingsHeader:t`
      padding: 0 ${r.paddingMD}px 0 0;
      height: 52px;
      box-sizing: border-box;
      flex-shrink: 0;
    `,mappingsTitle:t`
      color: ${r.colorPrimary};
      font-weight: 600;
      font-size: ${r.fontSizeLG}px;
      margin: 0;
      margin-right: ${r.paddingXS}px;
    `,mappingsActions:t`
      flex: 1;
    `,mappingsDivider:t`
      margin: 0;
      height: 16px;
    `,mappingsContent:t`
      flex: 1;
      padding: 0 ${r.paddingMD}px ${r.paddingMD}px 0;
      margin-top: -10px;
    `,emptyState:t`
      flex: 1;
      display: flex;
      flex-direction: column;
      height: 100%;
      min-height: 0;

      /* Droppable renders a wrapper div — make it fill too */
      & > div {
        flex: 1;
        display: flex;
        flex-direction: column;
        height: 100%;
      }
    `,emptyStateInner:t`
      flex: 1;
      height: 100%;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      color: ${r.colorTextSecondary};
      line-height: 1.6;
      border-radius: ${r.borderRadiusLG}px;
      transition: background 0.15s, outline-color 0.15s;

      &.dnd--drag-active {
        outline: 2px dashed ${r.colorBorderSecondary};
        outline-offset: -2px;
      }

      &.dnd--drag-valid {
        background: ${r.colorFillSecondary};
        outline: 2px dashed ${r.colorInfoBorderHover};
        outline-offset: -2px;
      }

      &.dnd--drag-error {
        outline: 2px dashed ${r.colorErrorBorder};
        outline-offset: -2px;
      }
    `,mappingItemContent:t`
      padding: ${r.paddingSM}px ${r.paddingXS}px;
    `,mappingLabelRow:t`
      display: flex;
      align-items: center;
      gap: ${r.sizeXS}px;
      padding: 0 ${r.paddingXXS}px;
    `,mappingLabelInput:t`
      flex: 1;
    `,mappingDivider:t`
      border-top: 1px solid ${r.colorBorderSecondary};
      margin-top: ${r.paddingXS}px;
    `,sourcesDestRow:t`
      display: flex;
      align-items: stretch;
      padding-top: ${r.paddingSM}px;
    `,sourcesDestCol:t`
      display: flex;
      flex-direction: column;
      gap: ${r.sizeXXS}px;
      flex: 1;
      min-width: 0;
      padding: 0 ${r.paddingXXS}px;
    `,arrowCol:t`
      flex-shrink: 0;
      padding: 0 ${r.paddingSM}px;
    `,arrowColSimple:t`
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
    `,arrowLabelSpacer:t`
      height: calc(22px + ${r.paddingXXS}px);
      flex-shrink: 0;
    `,arrowSelectRow:t`
      display: flex;
      align-items: center;
      height: ${r.controlHeight}px;
    `,arrowColAdvanced:t`
      display: flex;
      flex-direction: column;
      justify-content: center;
      gap: 10px;
    `,arrowWarningBadge:t`
      display: flex;
      align-items: center;
      justify-content: center;
      color: ${r.colorWarning};
      font-size: ${r.fontSizeLG}px;
      line-height: 1;
    `,arrowAdvancedIcon:t`
      display: flex;
      align-items: center;
      justify-content: center;
      color: ${r.colorIcon};
      font-size: ${r.fontSizeLG}px;
      line-height: 1;
    `,arrowSvg:t`
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    `,destinationTextBlock:t`
      display: flex;
      flex-direction: column;
      justify-content: center;
      /* Fills the destination column and centers within it, so the text stays on the same
         vertical center as the source control and the arrow — including when a multi-source
         Select wraps onto several lines and sourcesDestRow stretches both columns taller.
         The min-height keeps the unwrapped case matching the Select it replaces. */
      flex: 1;
      min-height: ${r.controlHeight}px;
      padding: 0 ${r.paddingXXS}px;
      font-size: ${r.fontSize}px;
      line-height: 22px;
      color: ${r.colorText};
    `,requiresAdvancedHint:t`
      display: flex;
      align-items: center;
      flex: 1;
      min-height: ${r.controlHeight}px;
      padding: 0 ${r.paddingXXS}px;
      font-size: ${r.fontSize}px;
      line-height: 22px;
      color: ${r.colorWarningText};
    `,languageSelect:t`
      flex: 1;
    `,filterEmptyState:t`
      flex: 1;
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0;

      /* Droppable renders a wrapper div — make it fill too */
      & > div {
        flex: 1;
        display: flex;
        flex-direction: column;
        width: 100%;
        height: 100%;
      }
    `,filterEmptyStateInner:t`
      flex: 1;
      width: 100%;
      height: 100%;
      min-height: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: ${r.paddingSM}px;
      text-align: center;
      color: ${r.colorTextSecondary};
      border-radius: ${r.borderRadiusLG}px;
      transition: background 0.15s, outline-color 0.15s;

      &.dnd--drag-active {
        outline: 2px dashed ${r.colorBorderSecondary};
        outline-offset: -2px;
      }

      &.dnd--drag-valid {
        background: ${r.colorFillSecondary};
        outline: 2px dashed ${r.colorInfoBorderHover};
        outline-offset: -2px;
      }

      &.dnd--drag-error {
        outline: 2px dashed ${r.colorErrorBorder};
        outline-offset: -2px;
      }
    `,hiddenItem:t`
      display: none;
    `,mappingDropZoneWrapper:t`
      width: 100%;
      padding: 2px 0;

      & .dnd--drag-active,
      & .dnd--drag-valid,
      & .dnd--drag-error {
        border: none !important;
        outline: none !important;
      }
    `,mappingDropZone:t`
      width: 100%;
      height: 6px;
      border-radius: ${r.borderRadiusSM}px;
      background: transparent;
      transition: background 0.15s;
      pointer-events: none;
      flex-shrink: 0;

      &.dnd--drag-active {
        pointer-events: auto;
        background: ${r.colorBorderSecondary};
      }

      &.dnd--drag-valid {
        pointer-events: auto;
        background: ${r.colorInfoBorderHover};
      }

      &.dnd--drag-error {
        pointer-events: auto;
        background: ${r.colorErrorBorder};
      }
    `,mappingItemNew:t`
      @keyframes mapping-item-slide-in {
        0% {
          opacity: 0;
          transform: translateY(-12px);
        }
        100% {
          opacity: 1;
          transform: translateY(0);
        }
      }

      animation: mapping-item-slide-in 400ms ease-in-out;
    `,annotatedTitle:t`
      display: inline-flex;
      align-items: center;
      gap: ${r.marginXS}px;
      min-width: 0;
    `,removedTitle:t`
      text-decoration: line-through;
      color: ${r.colorTextTertiary};
    `}}),tP="data-importer-source-column",tR=e=>{let{configName:t,sourceRows:r,hasPreviewError:a,activeFilter:o,onSetFilter:d,onAddMappingFromSource:c}=e,{t:p}=(0,l.useTranslation)(),{styles:u}=tM(),m=s.Form.useWatch(e=>JSON.stringify((e.mappingConfig??[]).map(e=>e.dataSourceIndex??[]))),g=(0,i.useMemo)(()=>void 0!==m?JSON.parse(m):void 0,[m]),h=(0,i.useMemo)(()=>{let e={};return(g??[]).forEach(t=>{t.forEach(t=>{e[t]=(e[t]??0)+1})}),e},[g]),f=null!==o,x=r.length>0;return(0,n.jsxs)(s.Flex,{className:u.sourcesPanel,vertical:!0,children:[(0,n.jsxs)(s.Flex,{align:"center",className:u.sourcesHeader,justify:"space-between",children:[(0,n.jsx)(s.Text,{className:u.sourcesTitle,children:p("data-importer.mapping.sources.title")}),f&&(0,n.jsx)(s.Button,{onClick:()=>{d(null)},size:"small",type:"link",children:p("data-importer.mapping.sources.reset-view")})]}),(0,n.jsxs)(s.Flex,{className:u.panelScrollable,vertical:!0,children:[!x&&a&&(0,n.jsx)(s.Flex,{align:"center",className:u.noContentWrapper,justify:"center",children:(0,n.jsx)(s.NoContent,{text:p("data-importer.mapping.sources.empty")})}),x&&(0,n.jsx)(s.Space,{className:u.sourceRowsSpace,direction:"vertical",size:"extra-small",children:r.map(e=>{let t=h[e.dataIndex]??0,r=t>0,a=f&&o!==e.dataIndex;return(0,n.jsx)("div",{className:$()(u.sourceRowOuter,{[u.sourceRowOuterMapped]:r,[u.sourceRowOuterFaded]:a}),children:(0,n.jsx)(s.Draggable,{info:{type:tP,title:e.label,icon:{value:"workflow"},data:{dataIndex:e.dataIndex,label:e.label}},children:(0,n.jsxs)(s.Flex,{align:"center",className:$()(u.sourceRowInner,r?u.sourceRowInnerMapped:u.sourceRowInnerUnmapped),onClick:()=>{d(o===e.dataIndex?null:e.dataIndex)},children:[(0,n.jsxs)(s.Flex,{align:"center",className:u.sourceRowTagArea,gap:"extra-small",children:[(0,n.jsx)("div",{className:u.sourceTagInner,children:(0,n.jsxs)(s.Space,{size:"extra-small",children:[(0,n.jsx)(s.Tag,{color:r?"purple":void 0,children:e.label}),r&&(0,n.jsx)(s.Badge,{className:u.badgeMappedCount,count:t,size:"large"})]})}),!r&&(0,n.jsx)("span",{className:`source-add-btn ${u.sourceAddBtn}`,children:(0,n.jsx)(s.IconButton,{icon:{value:"plus-circle"},onClick:t=>{t.stopPropagation(),c(e.dataIndex,e.label),d(e.dataIndex)},size:"small",tooltip:{title:p("data-importer.mapping.add")},type:"default"})})]}),(0,n.jsx)("span",{className:u.sourceValue,title:e.value,children:e.value})]})})},e.dataIndex)})})]})]})},tA="__default__";function tO(e){return void 0===e||""===e||"default"===e?tA:e}let tE=(0,p.createStyles)(e=>{let{css:t,token:r}=e;return{wrapper:t`
      flex: 1;
    `,header:t`
      height: 32px;
    `,title:t`
      font-size: 12px;
      font-weight: 600;
      color: ${r.colorPrimaryText};
    `,tableWrapper:t`
      min-height: 180px;
      max-height: 420px;
      border: 0.5px solid ${r.colorBorderSecondary};
      border-radius: ${r.borderRadiusSM}px;
      overflow: hidden;
      overflow-y: auto;
    `,tableHeader:t`
      display: grid;
      grid-template-columns: 1fr 1fr;
      background: ${r.colorFillAlter};
      border-bottom: 0.5px solid ${r.colorBorderSecondary};
    `,tableHeaderCell:t`
      font-size: 12px;
      padding: 6px ${r.paddingXS}px;
      font-weight: 500;
    `,tableHeaderCellBorder:t`
      border-right: 0.5px solid ${r.colorBorderSecondary};
    `,tableRow:t`
      display: grid;
      grid-template-columns: 1fr 1fr;
      background: ${r.colorBgContainer};
      height: 32px;
    `,tableRowHighlighted:t`
      background: ${r.colorSuccessBg};
    `,tableRowBorder:t`
      border-bottom: 0.5px solid ${r.colorBorderSecondary};
    `,tableCell:t`
      font-size: 12px;
      padding: 0 ${r.paddingXS}px;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    `,tableCellBorder:t`
      border-right: 0.5px solid ${r.colorBorderSecondary};
    `,stateMessage:t`
      padding: ${r.paddingMD}px ${r.paddingXS}px;
      font-size: 12px;
      color: ${r.colorTextSecondary};
      text-align: center;
    `,previewArea:t`
      min-height: 100px;
      overflow-y: auto;
    `,muted:t`
      font-size: 12px;
      color: ${r.colorTextQuaternary};
    `,previewLine:t`
      font-size: 12px;
      color: ${r.colorTextSecondary};
      margin-bottom: ${r.paddingXXS}px;
    `}}),tB=e=>{let{t}=(0,l.useTranslation)(),{styles:r,cx:a}=tE(),[o,d]=(0,i.useState)([]),[c,p]=(0,i.useState)(0),[u,m]=(0,i.useState)(0),[g,h]=(0,i.useState)(""),{dataPreview:f,currentRecordIndex:x,isLoading:v,isFetching:y,isError:b,load:j}=tS({configName:e.configName,enabled:"import"===e.mode,forceRefreshToken:e.forceRefreshToken}),[S,C]=(0,i.useState)([]),[I,w]=(0,i.useState)(0),T=tj(),[D,F]=(0,i.useState)(void 0),{data:N,isLoading:k,isFetching:$,isError:L,refetch:M}=ta(D,{skip:"result"!==e.mode||void 0===D,refetchOnMountOrArgChange:!1});(0,i.useEffect)(()=>{d(f.map(e=>tL(e)))},[f]),(0,i.useEffect)(()=>{m(x)},[x]),(0,i.useEffect)(()=>{b&&d([])},[b]);let P=t=>{var r,a,n,i;let o=void 0===e.currentMappingItem?void 0:{mappingConfig:[e.currentMappingItem],...(null==(r=e.baseConfig)?void 0:r.loaderConfig)!==void 0&&{loaderConfig:e.baseConfig.loaderConfig},...(null==(a=e.baseConfig)?void 0:a.interpreterConfig)!==void 0&&{interpreterConfig:e.baseConfig.interpreterConfig},...(null==(n=e.baseConfig)?void 0:n.resolverConfig)!==void 0&&{resolverConfig:e.baseConfig.resolverConfig},...(null==(i=e.baseConfig)?void 0:i.processingConfig)!==void 0&&{processingConfig:e.baseConfig.processingConfig}};F({name:e.configName,bundleDataImporterLoadPreviewParameters:{recordNumber:t,...void 0!==o&&{currentConfig:o},...void 0!==T&&{previewScope:T}}})};(0,i.useEffect)(()=>{if("result"!==e.mode||void 0===N)return;let t=N.transformationResultPreviews??[];C(void 0===e.currentMappingItem?t:t.slice(0,1))},[e.mode,N,e.currentMappingItem]),(0,i.useEffect)(()=>{L&&C([])},[L]),(0,i.useEffect)(()=>{"result"===e.mode&&P(I)},[e.refreshToken]);let R=(0,i.useRef)(!0);(0,i.useEffect)(()=>{if("result"===e.mode&&void 0!==e.forceRefreshToken&&0!==e.forceRefreshToken){if(R.current){R.current=!1;return}void 0===D?P(I):M()}},[e.forceRefreshToken]);let A=(e,t,a,i,o)=>(0,n.jsxs)(s.Flex,{align:"center",className:r.header,justify:"space-between",children:[(0,n.jsx)("span",{className:r.title,children:e}),(0,n.jsxs)(s.Space,{size:"mini",children:[(0,n.jsx)(s.IconButton,{disabled:!t||a,icon:{value:"chevron-left"},onClick:i,size:"small",type:"default"}),(0,n.jsx)(s.IconButton,{disabled:a,icon:{value:"chevron-right"},onClick:o,size:"small",type:"default"})]})]});if("import"===e.mode){let i=""===g.trim()?o:o.filter(e=>e.label.toLowerCase().includes(g.toLowerCase())||e.value.toLowerCase().includes(g.toLowerCase()));return(0,n.jsxs)(s.Flex,{className:r.wrapper,gap:"extra-small",vertical:!0,children:[A(t("data-importer.mapping.advanced-modal.step-source.import-preview"),u>0,v||y,()=>{let e=Math.max(0,c-1);p(e),j(e)},()=>{let e=c+1;p(e),j(e)}),(0,n.jsx)(s.SearchInput,{maxWidth:"100%",onChange:e=>{h(e.target.value)},placeholder:t("data-importer.mapping.advanced-modal.step-source.search-placeholder"),value:g,withClear:!0,withPrefix:!0}),(0,n.jsxs)("div",{className:r.tableWrapper,children:[(0,n.jsxs)("div",{className:r.tableHeader,children:[(0,n.jsx)("div",{className:a(r.tableHeaderCell,r.tableHeaderCellBorder),children:t("data-importer.mapping.advanced-modal.step-source.column-name")}),(0,n.jsx)("div",{className:r.tableHeaderCell,children:t("data-importer.mapping.advanced-modal.step-source.column-data")})]}),(v||y)&&(0,n.jsx)("div",{className:r.stateMessage,children:(0,n.jsx)(s.Spin,{type:"classic"})}),!(v||y)&&i.map((t,o)=>{let l=e.selectedDataSourceIndex.includes(t.dataIndex),d=o===i.length-1;return(0,n.jsxs)("div",{className:a(r.tableRow,l&&r.tableRowHighlighted,!d&&r.tableRowBorder),children:[(0,n.jsx)(s.Flex,{align:"center",className:a(r.tableCell,r.tableCellBorder),children:t.label}),(0,n.jsx)(s.Flex,{align:"center",className:r.tableCell,children:t.value})]},t.dataIndex)}),!(v||y)&&0===i.length&&(0,n.jsx)("div",{className:r.stateMessage,children:t("data-importer.mapping.advanced-modal.no-data")})]})]})}return(0,n.jsxs)(s.Flex,{className:r.wrapper,gap:"extra-small",vertical:!0,children:[A(t("data-importer.mapping.advanced-modal.step-target.preview-result"),I>0,k||$,()=>{let e=Math.max(0,I-1);w(e),P(e)},()=>{let e=I+1;w(e),P(e)}),(0,n.jsxs)("div",{className:r.previewArea,children:[(k||$)&&(0,n.jsx)("div",{className:r.muted,children:(0,n.jsx)(s.Spin,{type:"classic"})}),!(k||$)&&0===S.length&&(0,n.jsx)("div",{className:r.muted,children:t("data-importer.mapping.advanced-modal.no-preview")}),!(k||$)&&S.map((e,t)=>(0,n.jsx)("div",{className:r.previewLine,children:e},`preview-${t}`))]})]})},tz=(0,p.createStyles)(e=>{let{css:t,token:r}=e;return{twoColumnLayout:t`
      min-height: 280px;
      width: 100%;
      overflow: hidden;
    `,leftColumn:t`
      flex: 1 1 0;
      min-width: 0;
      background: ${r.colorFillAdditional};
      border-radius: ${r.borderRadius}px;
      padding: 10px ${r.paddingSM}px;
    `,labelSmall:t`
      font-size: 12px;
    `,selectFull:t`
      width: 100%;
      /* Ant Design sets max-width: 9999px as an inline style on .ant-select
         for multiple-mode selects — override it so the select cannot overflow
         its flex container. */
      &.ant-select {
        max-width: 100% !important;
      }
    `,rightColumn:t`
      flex: 1 1 0;
      min-width: 0;
    `}}),tH=e=>{let{configName:t,dataSourceIndex:r,forceRefreshToken:a,columnHeaderOptions:i,onDataSourceIndexChange:o}=e,{t:d}=(0,l.useTranslation)(),{styles:c}=tz();return(0,n.jsxs)(s.Flex,{className:c.twoColumnLayout,gap:"extra-small",children:[(0,n.jsxs)(s.Flex,{className:c.leftColumn,gap:6,vertical:!0,children:[(0,n.jsx)(s.Text,{className:c.labelSmall,strong:!0,children:d("data-importer.mapping.advanced-modal.step-source.label")}),(0,n.jsx)(s.Text,{className:c.labelSmall,type:"secondary",children:d("data-importer.mapping.advanced-modal.step-source.description")}),(0,n.jsx)(s.Select,{className:c.selectFull,mode:"multiple",onChange:o,options:i,placeholder:d("data-importer.mapping.item.source-placeholder"),showSearch:!0,value:r})]}),(0,n.jsx)(s.Flex,{className:c.rightColumn,vertical:!0,children:(0,n.jsx)(tB,{configName:t,forceRefreshToken:a,mode:"import",selectedDataSourceIndex:r})})]})};var tq=r(2692);let tW=(0,p.createStyles)(e=>{let{css:t,token:r}=e;return{twoColumnLayout:t`
      width: 100%;
      overflow: hidden;
    `,leftColumn:t`
      flex: 1 0 0;
      min-width: 0;
    `,listHeader:t`
      height: 32px;
      flex-shrink: 0;
    `,listHeaderTitle:t`
      font-size: 12px;
      font-weight: 600;
      color: ${r.colorPrimaryText};
      flex: 1;
    `,itemsList:t`
      flex: 1;
      overflow-y: auto;
    `,emptyState:t`
      font-size: 12px;
      color: ${r.colorTextQuaternary};
    `,transformerCardOverlay:t`
      border: 1px solid ${r.colorBorderSecondary};
      border-radius: ${r.borderRadiusSM}px;
      padding: 6px ${r.paddingXS}px;
      gap: ${r.paddingXXS}px;
      background: ${r.colorFillAdditional};
      box-shadow: ${r.boxShadowSecondary};
      cursor: grabbing;
    `,rightColumn:t`
      flex: 1 0 0;
      min-width: 0;
      padding-left: ${r.paddingXXS}px;
    `,sourceSectionHeader:t`
      height: 32px;
    `,sourceSectionTitle:t`
      font-size: 12px;
      font-weight: 600;
      color: ${r.colorPrimaryText};
    `,sourceValues:t`
      font-size: 12px;
      color: ${r.colorText};
      line-height: 22px;
      flex-wrap: wrap;
    `,sourceSeparator:t`
      color: ${r.colorTextSecondary};
      margin: 0 4px;
    `}});var tX=r(8668),tV=r(3627),t_=r(8831),tG=r(4979);let tU=(0,p.createStyles)(e=>{let{css:t,token:r}=e;return{transformerCardWrapper:t`
      & .ant-collapse.collapse-item--theme-primary {
        background-color: ${r.colorFillAdditional};
      }

      & .ant-collapse-content {
        background-color: ${r.colorFillAdditional} !important;
      }
    `,dragHandle:t`
      cursor: grab;
      user-select: none;
      flex-shrink: 0;
      margin-right: ${r.paddingXXS}px;

      &:active {
        cursor: grabbing;
      }
    `,dragHandleIcon:t`
      font-size: 14px;
      line-height: 1;
      color: ${r.colorTextTertiary};
    `,transformerLabel:t`
      font-weight: 400;
      font-size: 12px;
      color: ${r.colorText};
    `,transformerDeleteButton:t`
      color: ${r.colorPrimary} !important;

      &:hover {
        color: ${r.colorPrimaryHover} !important;
        background: transparent !important;
      }
    `}}),tK=e=>{let{label:t,children:r,dragHandleProps:a,index:i,onRemove:o,removeTooltip:l}=e,{styles:d}=tU(),c=(0,n.jsxs)(s.Flex,{align:"center",gap:"mini",children:[(0,n.jsx)(s.Flex,{align:"center",className:d.dragHandle,...a,children:(0,n.jsx)("span",{className:d.dragHandleIcon,children:"⠿"})}),(0,n.jsx)("span",{className:d.transformerLabel,children:t})]}),p=(0,n.jsx)(s.IconButton,{className:d.transformerDeleteButton,icon:{value:"trash"},onClick:e=>{e.stopPropagation(),o(i)},size:"small",tooltip:{title:l},type:"text"});return(0,n.jsx)("div",{className:d.transformerCardWrapper,children:(0,n.jsx)(s.CollapseItem,{bordered:!1,defaultActive:!0,extra:p,hasContentSeparator:!1,label:c,size:"small",theme:"primary",children:r})})},tQ=e=>{let{item:t,index:r,label:a,children:i,onRemove:o,removeTooltip:l}=e,{attributes:s,listeners:d,setNodeRef:c,transform:p,transition:u,isDragging:m}=(0,tV.gl)({id:t._id}),g={transform:tG.Ks.Transform.toString(p),transition:u,opacity:+!m};return(0,n.jsx)("div",{ref:c,style:g,children:(0,n.jsx)(tK,{dragHandleProps:{...s,...d},index:r,label:a,onRemove:o,removeTooltip:l,children:i})})},tY=e=>{let{items:t,activeId:r,transformerRegistry:a,onDragStart:i,onDragEnd:o,onRemove:s,onUpdateSettings:d}=e,{t:c}=(0,l.useTranslation)(),{styles:p}=tW(),u=(0,tX.FR)((0,tX.MS)(tX.AN,{activationConstraint:{distance:8}}),(0,tX.MS)(tX.uN,{coordinateGetter:tV.JR}));return(0,n.jsxs)(tX.Mp,{collisionDetection:tX.fp,modifiers:[t_.FN],onDragEnd:o,onDragStart:i,sensors:u,children:[(0,n.jsx)(tV.gB,{items:t.map(e=>e._id),strategy:tV._G,children:t.map((e,t)=>{let r="string"==typeof e.type?e.type:"",i=a.getDynamicType(r,!1),o=e.settings??{};return(0,n.jsx)(tQ,{index:t,item:e,label:(null==i?void 0:i.label)??r,onRemove:s,removeTooltip:c("data-importer.mapping.advanced-modal.transformer.remove"),children:null==i?void 0:i.renderSettings(o,e=>{d(t,e)})},e._id)})}),(0,n.jsx)(tX.Hd,{children:(()=>{if(null===r)return null;let e=t.findIndex(e=>e._id===r);if(-1===e)return null;let i=t[e],o="string"==typeof i.type?i.type:"",l=a.getDynamicType(o,!1),u=i.settings??{};return(0,n.jsx)("div",{className:p.transformerCardOverlay,children:(0,n.jsx)(tK,{index:e,label:(null==l?void 0:l.label)??o,onRemove:s,removeTooltip:c("data-importer.mapping.advanced-modal.transformer.remove"),children:null==l?void 0:l.renderSettings(u,t=>{d(e,t)})})})})()})]})},tJ=(0,p.createStyles)(e=>{let{css:t,token:r}=e;return{root:t`
    color: ${r.colorErrorText};
    font-size: 12px;
    line-height: 18px;
    background: ${r.colorErrorBg};
    border: 1px solid ${r.colorErrorBorder};
    border-radius: ${r.borderRadius}px;
    padding: ${r.paddingXXS}px ${r.paddingXS}px;
  `}}),tZ=e=>{let{children:t}=e,{styles:r}=tJ();return(0,n.jsx)("div",{className:r.root,children:t})},t0=(0,i.createContext)(void 0);function t1(){let e=(0,i.useContext)(t0);if(void 0===e)throw Error("useResultPreviewContext must be used within a ResultPreviewProvider");return e}let t2=e=>{let{children:t,...r}=e,a=(0,i.useMemo)(()=>r,[r.configName,r.previewRefreshToken,r.forceRefreshToken,r.currentMappingItem,r.baseConfig,r.calculateTypeError,r.isFetchingAttributes]);return(0,n.jsx)(t0.Provider,{value:a,children:t})},t3=(0,p.createStyles)(e=>{let{css:t}=e;return{wrapper:t`
    flex: 1;
    overflow: hidden;
  `}}),t5=()=>{let{configName:e,previewRefreshToken:t,forceRefreshToken:r,currentMappingItem:a,baseConfig:i,calculateTypeError:o,isFetchingAttributes:l}=t1(),{styles:d}=t3();return(0,n.jsxs)("div",{className:d.wrapper,children:[l&&(0,n.jsx)(s.Spin,{type:"classic"}),!l&&void 0!==o&&(0,n.jsx)(tZ,{children:o}),!l&&void 0===o&&(0,n.jsx)(tB,{baseConfig:i,configName:e,currentMappingItem:a,forceRefreshToken:r,mode:"result",refreshToken:t})]})},t9=(0,p.createStyles)(e=>{let{css:t,token:r}=e;return{outlineButton:t`
      height: 32px;
      padding: 0 15px;
      font-size: 12px;
      color: ${r.colorPrimary};
      background: ${r.colorBgContainer};
      border: 1px solid ${r.colorPrimaryBorder};
      border-radius: ${r.borderRadius}px;
      cursor: pointer;
      box-shadow: ${r.boxShadowTertiary};
    `,boxHeader:t`
      padding: ${r.paddingXXS}px ${r.paddingXS}px;
    `,boxHeaderTitle:t`
      font-size: 12px;
      font-weight: 600;
    `,selectFull:t`
      width: 100%;
      &.ant-select {
        max-width: 100% !important;
      }
    `}}),t6=e=>{let{dataSourceIndex:t,columnHeaderOptions:r,editingSource:a,onToggleEditing:i,onBlurSource:d,onChangeSource:c,getSourceLabel:p}=e,{t:u}=(0,l.useTranslation)(),{styles:m}=tW(),{styles:g}=t9();return(0,n.jsxs)(s.Flex,{className:m.rightColumn,gap:"extra-small",vertical:!0,children:[(0,n.jsxs)(s.Flex,{gap:"mini",vertical:!0,children:[(0,n.jsxs)(s.Flex,{align:"center",className:m.sourceSectionHeader,gap:"mini",children:[(0,n.jsx)("span",{className:m.sourceSectionTitle,children:u("data-importer.mapping.advanced-modal.step-source.label")}),(0,n.jsx)(s.IconButton,{icon:{value:"edit-pen"},onClick:i,size:"small",tooltip:{title:u("data-importer.mapping.advanced-modal.transformer.edit-source")},type:"text"})]}),a?(0,n.jsx)(s.Select,{className:g.selectFull,mode:"multiple",onBlur:d,onChange:e=>{c(Array.isArray(e)?e:[])},options:r,showSearch:!0,value:t}):(0,n.jsx)(s.Flex,{className:m.sourceValues,wrap:"wrap",children:0===t.length?(0,n.jsx)("span",{className:m.emptyState,children:"—"}):t.map((e,t)=>(0,n.jsxs)(o().Fragment,{children:[t>0&&(0,n.jsx)("span",{className:m.sourceSeparator,children:" | "}),(0,n.jsx)("span",{children:p(e)})]},e))})]}),(0,n.jsx)(t5,{})]})},t4=e=>({...e,_id:(0,tq.v4)()}),t7=e=>{let{_id:t,...r}=e;return r},t8=e=>{let{pipeline:t,dataSourceIndex:r,columnHeaderOptions:o,onPipelineChange:d,onDataSourceIndexChange:c}=e,{t:p}=(0,l.useTranslation)(),{styles:u}=tW(),[m,g]=(0,i.useState)(()=>t.map(t4)),h=(0,i.useRef)(t);(0,i.useEffect)(()=>{t!==h.current&&(h.current=t,g(e=>t.map((t,r)=>{let a=e[r];return(null==a?void 0:a.type)===t.type?{...t,_id:a._id}:t4(t)})))},[t]);let[f,x]=(0,i.useState)(!1),[v,y]=(0,i.useState)(null),b=(0,i.useMemo)(()=>a.container.get(ef),[]),j=(0,i.useMemo)(()=>{let e=b.getDynamicTypes(),t=t=>e.filter(e=>e.group===t).map(e=>({key:e.id,label:e.label}));return[{key:"dataManipulation",label:p("data-importer.mapping.advanced-modal.transformer.group.data-manipulation"),children:t("dataManipulation")},{key:"dataTypes",label:p("data-importer.mapping.advanced-modal.transformer.group.data-types"),children:t("dataTypes")},{key:"loadImport",label:p("data-importer.mapping.advanced-modal.transformer.group.load-import"),children:t("loadImport")}]},[b]);return(0,n.jsxs)(s.Flex,{className:u.twoColumnLayout,gap:"extra-small",children:[(0,n.jsxs)(s.Flex,{className:u.leftColumn,gap:"extra-small",vertical:!0,children:[(0,n.jsxs)(s.Flex,{align:"center",className:u.listHeader,gap:"extra-small",children:[(0,n.jsx)("span",{className:u.listHeaderTitle,children:p("data-importer.mapping.advanced-modal.step-transformations")}),(0,n.jsx)(s.Dropdown,{menu:{items:j,onClick:e=>{let t,{key:r}=e;g(t=[...m,t4({type:String(r),settings:{}})]),d(t.map(t7))}},trigger:["click"],children:(0,n.jsx)(s.IconTextButton,{icon:{value:"add"},size:"small",type:"default",children:p("data-importer.mapping.add")})})]}),(0,n.jsxs)(s.Flex,{className:u.itemsList,gap:6,vertical:!0,children:[0===m.length&&(0,n.jsx)("span",{className:u.emptyState,children:p("data-importer.mapping.advanced-modal.no-transformers")}),(0,n.jsx)(tY,{activeId:v,items:m,onDragEnd:e=>{y(null);let{active:t,over:r}=e;if(null===r||t.id===r.id)return;let a=m.findIndex(e=>e._id===t.id),n=m.findIndex(e=>e._id===r.id);if(-1===a||-1===n)return;let i=[...m],[o]=i.splice(a,1);i.splice(n,0,o),g(i),d(i.map(t7))},onDragStart:e=>{y(String(e.active.id))},onRemove:e=>{let t=m.filter((t,r)=>r!==e);g(t),d(t.map(t7))},onUpdateSettings:(e,t)=>{let r=m.map((r,a)=>a===e?{...r,settings:t}:r);g(r),d(r.map(t7))},transformerRegistry:b})]})]}),(0,n.jsx)(t6,{columnHeaderOptions:o,dataSourceIndex:r,editingSource:f,getSourceLabel:e=>{let t=o.find(t=>t.value===e);return(null==t?void 0:t.label)??e},onBlurSource:()=>{x(!1)},onChangeSource:e=>{c(e),x(!1)},onToggleEditing:()=>{x(e=>!e)}})]})},re=(0,p.createStyles)(e=>{let{css:t,token:r}=e;return{twoColumnLayout:t`
      min-height: 240px;
    `,leftColumn:t`
      flex: 0 0 calc(50% - 4px);
      min-width: 0;
      background: ${r.colorFillAdditional};
      border-radius: ${r.borderRadius}px;
    `,leftHeader:t`
      padding: ${r.paddingXXS}px ${r.paddingXS}px;
      height: 32px;
    `,leftHeaderTitle:t`
      font-size: 12px;
    `,fieldsContainer:t`
      padding: 0 ${r.paddingXS}px ${r.paddingXS}px ${r.paddingXS}px;
      flex: 1;

      & > div {
        min-width: 0;
      }
    `,fieldLabel:t`
      font-size: 12px;
      margin-bottom: ${r.paddingXXS}px;
    `,overwriteLabel:t`
      font-size: 12px;
      margin-top: 2px;
    `,switchLabel:t`
      font-size: 12px;
    `,selectFull:t`
      width: 100%;
      height: 32px;
    `,selectSkeletonWrapper:t`
      width: 100%;
      min-width: 0;

      & > * {
        width: 100%;
        min-width: 0;
      }
    `,classificationStoreKeyInput:t`
      flex: 1;
    `,rightColumn:t`
      flex: 0 0 calc(50% - 4px);
      min-width: 0;
    `}}),rt=()=>{let{styles:e}=re();return(0,n.jsx)(s.Flex,{className:e.rightColumn,vertical:!0,children:(0,n.jsx)(t5,{})})},rr=e=>{let{dataTarget:t,transformationResultType:r,classId:o,classFieldOptions:d,isLocalized:c,onDataTargetChange:p}=e,{t:u}=(0,l.useTranslation)(),{styles:m}=re(),g=(0,i.useMemo)(()=>a.container.get(e_),[]),h=(0,i.useMemo)(()=>g.getDynamicType((null==t?void 0:t.type)??"",!1),[g,null==t?void 0:t.type]),f=(0,i.useMemo)(()=>g.getDynamicTypes().map(e=>{let{id:t,label:r}=e;return{value:t,label:u(r)}}),[g]);return(0,n.jsxs)(s.Flex,{className:m.fieldsContainer,gap:6,vertical:!0,children:[(0,n.jsxs)("div",{children:[(0,n.jsx)("div",{className:m.fieldLabel,children:u("data-importer.mapping.advanced-modal.step-target.type")}),(0,n.jsx)("div",{className:m.selectSkeletonWrapper,children:(0,n.jsx)(s.Select,{className:m.selectFull,onChange:function(e){var r;let a=g.getDynamicType(e??"",!1),n=(null==a||null==(r=a.getDefaultSettings)?void 0:r.call(a,null==t?void 0:t.settings))??(null==t?void 0:t.settings)??{};p({...t,type:e,settings:n})},options:f,value:null==t?void 0:t.type})})]}),void 0!==h?h.supportsType(r)?h.renderSettings({classId:o,transformationResultType:r,settings:null==t?void 0:t.settings,onChange:e=>{p({...t,settings:e})},isLocalized:c,classFieldOptions:d}):(0,n.jsx)(tZ,{children:null==h?void 0:h.getTypeErrorMessage(u)}):(0,n.jsx)(n.Fragment,{})]})},ra=e=>{let{classId:t,transformationResultType:r,dataTarget:a,onDataTargetChange:o}=e,{t:d}=(0,l.useTranslation)(),{styles:c}=re(),{classFieldOptions:p,isLocalized:u}=function(e){var t;let{attributesMap:r,transformationResultType:a,dataTarget:n,onDataTargetChange:o}=e,{isFetchingAttributes:l,calculateTypeError:s}=t1(),d=(0,i.useMemo)(()=>r[tO(a)]??[],[r,a]),c=(0,i.useMemo)(()=>(s??"")!==""?[]:d.map(e=>({value:e.key,label:e.title})),[s,d]),p=(0,i.useMemo)(()=>{var e;return(null==(e=d.find(e=>{var t;return e.key===(null==n||null==(t=n.settings)?void 0:t.fieldName)}))?void 0:e.localized)??!1},[d,null==n||null==(t=n.settings)?void 0:t.fieldName]);return(0,i.useEffect)(()=>{var e;let t=null==n?void 0:n.type,r=null==n||null==(e=n.settings)?void 0:e.fieldName;"classificationstore"!==t&&"classificationstoreBatch"!==t&&!l&&void 0!==r&&(c.some(e=>e.value===r)||o({...n,settings:{...null==n?void 0:n.settings,fieldName:void 0,language:void 0}}))},[c,l]),{classFieldOptions:c,isLocalized:p}}(e);return(0,n.jsxs)(s.Flex,{className:c.twoColumnLayout,gap:"extra-small",children:[(0,n.jsxs)(s.Flex,{className:c.leftColumn,vertical:!0,children:[(0,n.jsx)(s.Flex,{align:"center",className:c.leftHeader,children:(0,n.jsx)(s.Text,{className:c.leftHeaderTitle,strong:!0,children:d("data-importer.mapping.advanced-modal.step-target")})}),(0,n.jsx)(rr,{classFieldOptions:p,classId:t,dataTarget:a,isLocalized:u,onDataTargetChange:o,transformationResultType:r})]}),(0,n.jsx)(rt,{})]})},rn=(0,p.createStyles)(e=>{let{css:t,token:r}=e;return{sectionPanel:t`
      & .ant-collapse.collapse-item--theme-default {
        background-color: ${r.colorFillAlter};

        & .ant-collapse-content {
          background-color: ${r.colorBgContainer};
        }
      }
    `,stepBadge:t`
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 20px;
      height: 20px;
      padding: 0 6px;
      border-radius: 10px;
      background-color: ${r.colorPrimary};
      color: ${r.colorTextLightSolid};
      font-size: ${r.fontSizeSM}px;
      font-weight: ${r.fontWeightStrong};
      line-height: 20px;
      margin-inline-end: ${r.marginXXS}px;
    `,footer:t`
      border-top: 1px solid ${r.colorBorderSecondary};
      padding-top: ${r.paddingSM}px;
      margin-top: ${r.paddingXXS}px;
    `}});function ri(e){return{key:e.key??e.name??"",title:e.title??e.name??e.key??"",localized:!!e.localized}}let ro=e=>{var t;let{open:r,onClose:a,onSave:o,configName:d,classId:c,item:p,columnHeaderOptions:u,attributesMap:m,baseConfig:g}=e,{t:h}=(0,l.useTranslation)(),{styles:f}=rn(),[x,v]=(0,i.useState)(()=>structuredClone(p)),[y,b]=(0,i.useState)({source:!0,transformations:!1,target:!1}),[j,S]=(0,i.useState)(0),[C,I]=(0,i.useState)(0),w=(0,i.useRef)(null),T=(0,i.useCallback)(()=>{null!==w.current&&clearTimeout(w.current),w.current=setTimeout(()=>{S(e=>e+1),w.current=null},800)},[]),D=tj(),[F,k]=(0,i.useState)(void 0),{data:$,isFetching:L,error:M,refetch:P}=e5(F,{skip:void 0===F,refetchOnMountOrArgChange:!1});(0,i.useEffect)(()=>{void 0!==$&&v(e=>({...e,transformationResultType:$.type}))},[$]);let R=void 0!==M?null==(t=M.data)?void 0:t.detail:void 0;(0,i.useEffect)(()=>{r&&(v(structuredClone(p)),b({source:!0,transformations:!1,target:!1}))},[r,p]);let A=e=>{b(t=>({source:!1,transformations:!1,target:!1,[e]:!t[e]}))},O=x.transformationPipeline??[],E=e=>{v(t=>({...t,dataSourceIndex:e})),T()},B=(0,i.useRef)(x);B.current=x;let{mergedAttributesMap:z,isFetchingExtraAttributes:H}=function(e){let{open:t,configName:r,classId:a,localItem:n,localItemRef:o,attributesMap:l,setCalculateTypeRequest:s}=e,d=JSON.stringify(n.transformationPipeline??[]),c=JSON.stringify(n.dataSourceIndex??[]),p=(0,i.useRef)(!0),u=tj();(0,i.useEffect)(()=>{if(!t){p.current=!0;return}if(p.current){p.current=!1;return}let e=o.current??{};s({name:r,bundleDataImporterCalculateTransformationResultTypeParameters:{previewScope:u,currentConfig:{label:e.label,dataSourceIndex:e.dataSourceIndex,transformationPipeline:e.transformationPipeline,dataTarget:e.dataTarget}}})},[d,c,t,r,u,o,s]);let m=tO(n.transformationResultType),g=m!==tA&&void 0===l[m],{data:h,isFetching:f}=ts({classId:a??"",transformationResultType:n.transformationResultType,systemWrite:!0},{skip:!g||void 0===a||""===a});return{mergedAttributesMap:(0,i.useMemo)(()=>{if(!g||(null==h?void 0:h.attributes)===void 0)return l;let e=h.attributes.map(ri);return{...l,[m]:e}},[l,g,h,m]),isFetchingExtraAttributes:g&&f}}({open:r,configName:d,classId:c,localItem:x,localItemRef:B,attributesMap:m,setCalculateTypeRequest:k}),q=(0,i.useCallback)(async()=>{let e=B.current,t={name:d,bundleDataImporterCalculateTransformationResultTypeParameters:{previewScope:D,currentConfig:{label:e.label,dataSourceIndex:e.dataSourceIndex,transformationPipeline:e.transformationPipeline,dataTarget:e.dataTarget}}},r=JSON.stringify(F)===JSON.stringify(t);if(k(t),r)try{await P()}catch{}},[d,F,P,D]),W=(0,i.useCallback)(()=>{q(),I(e=>e+1)},[q]),X=N();return(0,n.jsx)(s.Modal,{footer:(0,n.jsxs)(s.Flex,{align:"center",className:f.footer,gap:"extra-small",justify:"flex-end",children:[(0,n.jsx)(s.IconButton,{disabled:L,icon:{value:"refresh"},onClick:W,tooltip:{title:h("data-importer.mapping.advanced-modal.refresh-all-previews")}}),!X&&(0,n.jsx)(s.Button,{onClick:()=>{o(x),a()},type:"primary",children:h("data-importer.mapping.advanced-modal.save")})]}),onCancel:a,open:r,title:h("data-importer.mapping.advanced-modal.title"),width:996,children:(0,n.jsx)(t2,{baseConfig:g,calculateTypeError:R,configName:d,currentMappingItem:x,forceRefreshToken:C,isFetchingAttributes:H||L,previewRefreshToken:j,children:(0,n.jsxs)(s.Flex,{gap:"small",vertical:!0,children:[(0,n.jsx)("div",{className:f.sectionPanel,children:(0,n.jsx)(s.Panel,{active:y.source,collapsible:!0,onChange:()=>{A("source")},theme:"default",title:(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)("span",{className:f.stepBadge,children:"1"}),h("data-importer.mapping.advanced-modal.step-source")]}),children:(0,n.jsx)(tH,{columnHeaderOptions:u,configName:d,dataSourceIndex:x.dataSourceIndex??[],forceRefreshToken:C,onDataSourceIndexChange:E})})}),(0,n.jsx)("div",{className:f.sectionPanel,children:(0,n.jsx)(s.Panel,{active:y.transformations,collapsible:!0,onChange:()=>{A("transformations")},theme:"default",title:(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)("span",{className:f.stepBadge,children:"2"}),h("data-importer.mapping.advanced-modal.step-transformations")]}),children:(0,n.jsx)(t8,{columnHeaderOptions:u,dataSourceIndex:x.dataSourceIndex??[],onDataSourceIndexChange:E,onPipelineChange:e=>{v(t=>({...t,transformationPipeline:e})),T()},pipeline:O})})}),(0,n.jsx)("div",{className:f.sectionPanel,children:(0,n.jsx)(s.Panel,{active:y.target,collapsible:!0,onChange:()=>{A("target")},theme:"default",title:(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)("span",{className:f.stepBadge,children:"3"}),h("data-importer.mapping.advanced-modal.step-target")]}),children:(0,n.jsx)(ra,{attributesMap:z,classId:c,dataTarget:x.dataTarget,onDataTargetChange:e=>{v(t=>({...t,dataTarget:e}))},transformationResultType:x.transformationResultType})})})]})})})},rl=e=>{let{children:t,className:r}=e,{getStateClasses:a}=(0,s.useDroppable)();return(0,n.jsx)("div",{className:$()(r,...a()),children:t})};var rs=r(5710);let rd=e=>{let{fill:t}=e;return(0,n.jsx)("svg",{fill:"none",height:"12",viewBox:"0 0 26 12",width:"26",xmlns:"http://www.w3.org/2000/svg",children:(0,n.jsx)("path",{d:"M25.5303 6.05377C25.8232 5.76087 25.8232 5.286 25.5303 4.99311L20.7574 0.220137C20.4645 -0.0727568 19.9896 -0.0727568 19.6967 0.220137C19.4038 0.51303 19.4038 0.987904 19.6967 1.2808L23.9393 5.52344L19.6967 9.76608C19.4038 10.059 19.4038 10.5338 19.6967 10.8267C19.9896 11.1196 20.4645 11.1196 20.7574 10.8267L25.5303 6.05377ZM0 5.52344V6.27344H25V5.52344V4.77344H0V5.52344Z",fill:t,fillOpacity:1})})},rc=e=>{let{isAdvanced:t,isWarningState:r,isInProgressState:a}=e,{styles:i}=tM(),{token:o}=rs.A.useToken(),l=t||r||a,d=r||a?o.colorWarning:o.colorIcon,c=(0,n.jsx)("span",{className:i.arrowSvg,children:(0,n.jsx)(rd,{fill:d})});return l?(0,n.jsxs)("div",{className:$()(i.arrowCol,i.arrowColAdvanced),children:[t&&!r&&!a&&(0,n.jsx)("span",{className:i.arrowAdvancedIcon,children:(0,n.jsx)(s.Icon,{value:"transformation"})}),(r||a)&&(0,n.jsx)("span",{className:i.arrowWarningBadge,children:(0,n.jsx)(s.Icon,{value:"warning-circle"})}),c]}):(0,n.jsxs)("div",{className:$()(i.arrowCol,i.arrowColSimple),children:[(0,n.jsx)("div",{className:i.arrowLabelSpacer}),(0,n.jsx)("div",{className:i.arrowSelectRow,children:c})]})},rp=o().memo(e=>{let{fieldIndex:t,itemLabel:r,dataSourceIndex:a,isAdvanced:o,isInProgressState:d,isWarningState:c,selectedAttr:p,selectedFieldName:u,isLocalized:m,language:g,columnHeaderOptions:h,attributeOptions:f,languageOptions:x,onOpenAdvanced:v,onRemove:y}=e,b=N(),{t:j}=(0,l.useTranslation)(),{styles:S}=tM(),C=s.Form.useFormInstance(),[I,w]=(0,i.useState)(!1),[T,D]=(0,i.useState)(!1),F=(0,i.useMemo)(()=>{if(0===(a??[]).length)return[];let e=new Set(a);return h.filter(t=>e.has(t.value))},[a,h]),k=I?h:F,$=(0,i.useMemo)(()=>void 0===u||""===u?[]:[{value:u,label:(null==p?void 0:p.title)??u}],[p,u]);return(0,i.useEffect)(()=>{if(!0!==globalThis.__DI_MAPPING_DEBUG__)return;let e=performance.now();requestAnimationFrame(()=>{console.debug("[DI][Perf] mapping item content painted",{fieldIndex:t,expandedState:"expanded",durationMs:Number((performance.now()-e).toFixed(2))})})},[t]),(0,n.jsxs)("div",{className:S.mappingItemContent,children:[(0,n.jsxs)("div",{className:S.mappingLabelRow,children:[(0,n.jsx)("div",{className:S.mappingLabelInput,style:{flex:1},children:(0,n.jsx)(s.Input,{onChange:e=>{C.setFieldValue(["mappingConfig",t,"label"],e.target.value,{triggerChange:!0})},placeholder:j("data-importer.mapping.item.label"),value:r??""})}),(0,n.jsx)(tC.Ay,{componentDisabled:!1,children:(0,n.jsx)(s.IconTextButton,{disabled:!1,icon:{value:"transformation"},onClick:v,type:"default",children:j("data-importer.mapping.item.advanced")})}),!b&&(0,n.jsx)(s.IconButton,{icon:{value:"trash"},onClick:y,tooltip:{title:j("data-importer.mapping.item.delete")},type:"default"})]}),(0,n.jsx)("div",{className:S.mappingDivider}),(0,n.jsxs)("div",{className:S.sourcesDestRow,children:[(0,n.jsxs)("div",{className:S.sourcesDestCol,children:[(0,n.jsx)("div",{children:j("data-importer.mapping.item.source")}),(0,n.jsx)("div",{className:S.sourceDropZone,children:(0,n.jsx)(s.Select,{filterOption:E,mode:"multiple",onChange:e=>{C.setFieldValue(["mappingConfig",t,"dataSourceIndex"],e,{triggerChange:!0}),e.length>1&&(C.setFieldValue(["mappingConfig",t,"transformationResultType"],"default"),C.setFieldValue(["mappingConfig",t,"dataTarget","settings","fieldName"],void 0),C.setFieldValue(["mappingConfig",t,"dataTarget","settings","language"],void 0))},onFocus:()=>{w(!0)},options:k,placeholder:j("data-importer.mapping.item.source-placeholder"),showSearch:!0,style:{maxWidth:"100%"},value:a??[]})})]}),(0,n.jsx)(rc,{isAdvanced:o,isInProgressState:d,isWarningState:c}),(0,n.jsxs)("div",{className:S.sourcesDestCol,children:[(0,n.jsx)("div",{children:j("data-importer.mapping.item.destination")}),o&&(0,n.jsx)("div",{className:S.destinationTextBlock,children:(0,n.jsx)("span",{children:(null==p?void 0:p.title)??u??""})}),!o&&d&&(0,n.jsx)("div",{className:S.requiresAdvancedHint,children:j("data-importer.mapping.item.requires-advanced-setup")}),!o&&!d&&(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(s.Select,{filterOption:E,onChange:e=>{C.setFieldValue(["mappingConfig",t,"dataTarget","settings","fieldName"],e,{triggerChange:!0})},onFocus:()=>{D(!0)},options:T?f:$,placeholder:j("data-importer.mapping.item.destination-placeholder"),showSearch:!0,style:{maxWidth:"100%"},value:u??void 0}),m&&(0,n.jsx)(s.Select,{filterOption:E,onChange:e=>{C.setFieldValue(["mappingConfig",t,"dataTarget","settings","language"],e,{triggerChange:!0})},options:x,placeholder:j("data-importer.mapping.item.data-target.language-placeholder"),showSearch:!0,style:{maxWidth:"100%"},value:g??void 0})]})]})]})]})});rp.displayName="MappingItemContent";let ru=s.FormAnnotationsProvider,rm="function"==typeof ru?ru:null,rg=s.useFormItemAnnotation,rh="function"==typeof rg?rg:()=>void 0,rf={added:"green",changed:"gold",removed:"red",moved:"geekblue"},rx=e=>{let{status:t}=e,{t:r}=(0,l.useTranslation)();return(0,n.jsx)(s.Tag,{color:rf[t],"data-review-mark":"",style:{marginInlineEnd:0},children:r(`data-importer.review.status.${t}`)})},rv=o().memo(e=>{let t,{fieldIndex:r,mappingId:a,remove:d,onRemoveItem:p,configName:u,columnHeaderOptions:m,classId:g,expanded:h,onToggle:f,itemLabel:x,dataSourceIndex:v,transformationResultType:y,selectedFieldName:b,language:j,attributesMap:S}=e,C=o().useRef(0);C.current+=1,!0===globalThis.__DI_MAPPING_DEBUG__&&(1===C.current||C.current%50==0)&&console.debug("[DI][MappingItem] render",{fieldIndex:r,mappingId:a,renderCount:C.current,expanded:h,hasDataSource:(v??[]).length>0,trt:y??"default"});let{t:I}=(0,l.useTranslation)(),{styles:w,cx:T}=tM(),D=s.Form.useFormInstance(),[F,N]=(0,i.useState)(!1),k=(0,c.useSettings)(),$=(0,i.useMemo)(()=>(k.validLanguages??[]).map(e=>({value:e,label:e})),[k.validLanguages]),L=(v??[]).length,M=void 0!==b&&""!==b,P=(0,i.useCallback)(()=>(D.getFieldValue("mappingConfig")??[]).findIndex(e=>e.mappingId===a),[D,a]);(0,i.useEffect)(()=>{if(!h)return;let e=P();if(e<0)return;let t=D.getFieldValue(["mappingConfig",e])??{},r=t.label??"",a=t.dataSourceIndex??[];if(""===r&&a.length>0){let t=m.find(e=>e.value===a[0]);void 0!==t&&D.setFieldValue(["mappingConfig",e,"label"],t.label,{triggerChange:!0})}},[h,m,D,P]);let R=S[tO(y)]??[],A=(0,i.useMemo)(()=>h?R.map(e=>({value:e.key,label:e.title})):[],[h,R]),O=(0,i.useMemo)(()=>{if(h)return R.find(e=>e.key===b)},[h,R,b]),E=(null==O?void 0:O.localized)??!1,B=void 0!==x&&""!==x?x:I("data-importer.mapping.item.new-label"),z=rh(["mappingConfig",r]),H=void 0===z?B:(0,n.jsxs)("span",{className:w.annotatedTitle,children:[(0,n.jsx)("span",{className:"removed"===z.status?w.removedTitle:void 0,children:B}),(0,n.jsx)(rx,{status:z.status})]}),q=(0,i.useCallback)(e=>{let t=P();if(t<0)return;let r=e.data.dataIndex,a=D.getFieldValue(["mappingConfig",t,"dataSourceIndex"])??[];if(!a.includes(r)){let e=[...a,r];D.setFieldValue(["mappingConfig",t,"dataSourceIndex"],e,{triggerChange:!0}),e.length>1&&(D.setFieldValue(["mappingConfig",t,"transformationResultType"],"default"),D.setFieldValue(["mappingConfig",t,"dataTarget","settings","fieldName"],void 0),D.setFieldValue(["mappingConfig",t,"dataTarget","settings","language"],void 0))}},[D,P]),W=(0,i.useCallback)(()=>{N(!0)},[]),X=(0,i.useCallback)(()=>{p(r)},[p,r]);return(0,n.jsxs)(s.Droppable,{className:w.droppablePanel,disableDndActiveIndicator:!1,isValidContext:e=>e.type===tP,onDrop:q,variant:"default",children:[(0,n.jsx)(rl,{className:T(w.panelDndWrapper,h&&w.panelExpanded),children:(0,n.jsx)(s.Panel,{active:h,border:!0,collapsible:!0,contentPadding:"none",onChange:f,theme:"default",title:H,children:h&&(0,n.jsx)(rp,{attributeOptions:A,columnHeaderOptions:m,dataSourceIndex:v,fieldIndex:r,isAdvanced:void 0!==y&&""!==y&&"default"!==y,isInProgressState:L>1&&!M,isLocalized:E,isWarningState:L>0&&!M,itemLabel:x,language:j,languageOptions:$,onOpenAdvanced:W,onRemove:X,selectedAttr:O,selectedFieldName:b})})}),F&&(0,n.jsx)(ro,{attributesMap:S,baseConfig:{loaderConfig:D.getFieldsValue(!0).loaderConfig,interpreterConfig:D.getFieldsValue(!0).interpreterConfig,resolverConfig:D.getFieldsValue(!0).resolverConfig,processingConfig:D.getFieldsValue(!0).processingConfig},classId:g,columnHeaderOptions:m,configName:u,item:(t=P())<0?{}:D.getFieldValue(["mappingConfig",t])??{},onClose:()=>{N(!1)},onSave:e=>{let t=P();t<0||D.setFieldValue(["mappingConfig",t],e,{triggerChange:!0}),N(!1)},open:F})]})},function(e,t){if(!e.expanded&&!t.expanded)return e.expanded===t.expanded&&e.fieldIndex===t.fieldIndex&&e.mappingId===t.mappingId&&e.itemLabel===t.itemLabel&&e.onToggle===t.onToggle&&e.onRemoveItem===t.onRemoveItem&&e.remove===t.remove;let r=e.dataSourceIndex,a=t.dataSourceIndex,n=r===a||void 0!==r&&r.length===(null==a?void 0:a.length)&&r.every((e,t)=>e===a[t]);return e.fieldIndex===t.fieldIndex&&e.mappingId===t.mappingId&&e.remove===t.remove&&e.onRemoveItem===t.onRemoveItem&&e.configName===t.configName&&e.columnHeaderOptions===t.columnHeaderOptions&&e.classId===t.classId&&e.expanded===t.expanded&&e.onToggle===t.onToggle&&e.itemLabel===t.itemLabel&&n&&e.transformationResultType===t.transformationResultType&&e.selectedFieldName===t.selectedFieldName&&e.language===t.language&&e.attributesMap===t.attributesMap});function ry(e,t){return void 0!==e&&(null===t||e===t)}rv.displayName="MappingItem";let rb=e=>{let{insertIndex:t,add:r,onInsertItem:a,onDropped:o,acceptedDataIndex:l}=e,{styles:d}=tM(),c=(0,i.useCallback)(e=>{let{dataIndex:n,label:i}=e.data;a(r,t,n,i),o(t)},[r,t,a,o]);return(0,n.jsx)(s.Droppable,{className:d.mappingDropZoneWrapper,disableDndActiveIndicator:!1,isValidContext:e=>e.type===tP&&ry(e.data.dataIndex,l??null),onDrop:c,variant:"default",children:(0,n.jsx)(rl,{className:d.mappingDropZone})})},rj=(0,i.createContext)({configName:"",classId:void 0,columnHeaderOptions:[],attributesMap:{},sourceRows:[]}),rS=rj.Provider,rC=o().memo(e=>{var t,r,a,l;let{fieldIndex:d,mappingId:c,insertIndex:p,remove:u,onRemoveItem:m,expanded:g,onToggle:h,activeFilter:f,isNew:x,add:v,onDropped:y,onInsertItem:b,acceptedDataIndex:j}=e,S=o().useRef(0);S.current+=1,!0===globalThis.__DI_MAPPING_DEBUG__&&(1===S.current||S.current%50==0)&&console.debug("[DI][MappingItemWithFilter] render",{fieldIndex:d,mappingId:c,renderCount:S.current,expanded:g,activeFilter:f});let{configName:C,classId:I,columnHeaderOptions:w,attributesMap:T}=(0,i.useContext)(rj),{styles:D,cx:F}=tM(),N=s.Form.useFormInstance(),k=(0,i.useRef)(d);k.current=d,s.Form.useWatch(e=>{var t;return null==e||null==(t=e.mappingConfig)?void 0:t[k.current]});let $=N.getFieldValue(["mappingConfig",d])??{},L=$.dataSourceIndex,M=null!==f&&!(L??[]).includes(f);return(0,n.jsxs)("div",{className:F(M&&D.hiddenItem),children:[(0,n.jsx)(rb,{acceptedDataIndex:j,add:v,insertIndex:p,onDropped:y,onInsertItem:b}),(0,n.jsx)("div",{className:F(x&&D.mappingItemNew),children:(0,n.jsx)(rv,{attributesMap:T,classId:I,columnHeaderOptions:w,configName:C,dataSourceIndex:L,expanded:g,fieldIndex:d,itemLabel:$.label,language:null==(r=$.dataTarget)||null==(t=r.settings)?void 0:t.language,mappingId:c,onRemoveItem:m,onToggle:h,remove:u,selectedFieldName:null==(l=$.dataTarget)||null==(a=l.settings)?void 0:a.fieldName,transformationResultType:$.transformationResultType})})]})});rC.displayName="MappingItemWithFilter";let rI=e=>{let{add:t,onInsertItem:r,onDropped:a}=e,{t:o}=(0,l.useTranslation)(),{styles:d}=tM(),c=(0,i.useCallback)(e=>{let{dataIndex:n,label:i}=e.data;r(t,0,n,i),a(0)},[t,r,a]);return(0,n.jsx)(s.Droppable,{className:d.emptyState,disableDndActiveIndicator:!1,isValidContext:e=>e.type===tP,onDrop:c,variant:"default",children:(0,n.jsx)(rl,{className:d.emptyStateInner,children:(0,n.jsx)("span",{children:o("data-importer.mapping.empty-state")})})})},rw=e=>{let{activeFilter:t,activeFilterLabel:r,fields:a,onAddMappingForFilter:o,add:d,onInsertItem:c,onDropped:p}=e,{t:u}=(0,l.useTranslation)(),{styles:m}=tM(),g=s.Form.useWatch(e=>JSON.stringify((e.mappingConfig??[]).map(e=>e.dataSourceIndex??[]))),h=(0,i.useMemo)(()=>void 0!==g?JSON.parse(g):[],[g]),f=(0,i.useCallback)(e=>{let{dataIndex:r,label:n}=e.data;ry(r,t)&&(c(d,a.length,r,n),p(a.length))},[t,c,d,a.length,p]);return h.some(e=>e.includes(t))?null:(0,n.jsx)(s.Droppable,{className:m.filterEmptyState,disableDndActiveIndicator:!1,isValidContext:e=>e.type===tP&&ry(e.data.dataIndex,t),onDrop:f,variant:"default",children:(0,n.jsxs)(rl,{className:m.filterEmptyStateInner,children:[(0,n.jsx)("span",{children:u("data-importer.mapping.filter-empty",{source:r??t})}),(0,n.jsx)(s.IconTextButton,{icon:{value:"add"},onClick:o,type:"default",children:u("data-importer.mapping.add")})]})})};function rT(){return!0===globalThis.__DI_MAPPING_DEBUG__}let rD=o().memo(e=>{let{fields:t,add:r,remove:a,hasItems:d,flashIndex:c,activeFilter:p,activeFilterLabel:u,expandedKeys:m,allVisibleCollapsed:g,onCollapseAll:h,onNewKey:f,onToggleKey:x,onOpenAutofillSuggestions:v,onAddItem:y,onRemoveItem:b,onAddMappingForFilter:j,onInsertItem:S,onDropped:C,getMappingIdByIndex:I}=e,w=N(),{t:T}=(0,l.useTranslation)(),{styles:D}=tM(),F=(0,i.useRef)(0);F.current+=1,rT()&&(1===F.current||F.current%20==0)&&console.debug("[DI][MappingsPanelContent] render",{renderCount:F.current,fieldCount:t.length,activeFilter:p,flashIndex:c,expandedMode:"all"===m?"all":"set"});let k=(0,i.useRef)(new Set(t.map(e=>e.key)));(0,i.useLayoutEffect)(()=>{let e=rT(),r=new Set(t.map(e=>e.key)),a=k.current,n=Array.from(r).filter(e=>!a.has(e));1===n.length?f(n[0]):e&&n.length>1&&console.debug("[DI][MappingsPanelContent] skip auto-expand for bulk add",{addedKeyCount:n.length,fieldCount:t.length}),k.current=r},[t,f]);let $=(0,i.useMemo)(()=>t.map(e=>e.key),[t]),L=(0,i.useCallback)(e=>()=>{b(a,e)},[b,a]),M=(0,i.useRef)(x),P=(0,i.useRef)(t);M.current=x,P.current=t;let R=(0,i.useRef)(new Map),A=(0,i.useCallback)(e=>(R.current.has(e)||R.current.set(e,()=>{let t=P.current.map(e=>e.key);M.current(e,t)}),R.current.get(e)),[]),O=(0,i.useMemo)(()=>{let e=rT(),i=e?performance.now():0,l=p??void 0,s=t.map((e,t)=>{let i=I(e.name),s="all"===m||m.has(e.key);return(0,n.jsx)(o().Fragment,{children:(0,n.jsx)(rC,{acceptedDataIndex:l,activeFilter:p,add:r,expanded:s,fieldIndex:e.name,insertIndex:t,isNew:c===t,mappingId:i,onDropped:C,onInsertItem:S,onRemoveItem:L(e.name),onToggle:A(e.key),remove:a})},e.key)});return e&&console.debug("[DI][MappingsPanelContent] itemList built",{itemCount:s.length,durationMs:Number((performance.now()-i).toFixed(2)),activeFilter:p}),s},[t,r,a,p,m,c,C,S,L,A,I]);return(0,n.jsxs)(n.Fragment,{children:[(0,n.jsxs)(s.Flex,{align:"center",className:D.mappingsHeader,gap:"small",children:[(0,n.jsx)(s.Text,{className:D.mappingsTitle,children:T("data-importer.mapping.title-short")}),(0,n.jsxs)(s.Flex,{align:"center",className:D.mappingsActions,gap:"extra-small",children:[!w&&(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(s.IconTextButton,{icon:{value:"new"},onClick:()=>{y(r,t.length)},type:"default",children:T("data-importer.mapping.add")}),(0,n.jsx)(s.Divider,{className:D.mappingsDivider,type:"vertical"}),(0,n.jsx)(s.IconTextButton,{icon:{value:"autofill"},onClick:v,type:"default",children:T("data-importer.mapping.auto-fill")})]}),d&&(0,n.jsx)(s.Button,{onClick:()=>{h($)},size:"small",style:{marginLeft:"auto"},type:"link",children:T(g?"data-importer.mapping.expand-all":"data-importer.mapping.collapse-all")})]})]}),(0,n.jsxs)(s.Flex,{className:D.mappingsContent,vertical:!0,children:[!d&&null===p&&(0,n.jsx)(rI,{add:r,onDropped:C,onInsertItem:S}),O,d&&(0,n.jsx)(rb,{acceptedDataIndex:p??void 0,add:r,insertIndex:t.length,onDropped:C,onInsertItem:S}),null!==p&&(0,n.jsx)(rw,{activeFilter:p,activeFilterLabel:u,add:r,fields:t,onAddMappingForFilter:()=>{j(r)},onDropped:C,onInsertItem:S})]})]})});rD.displayName="MappingsPanelContent";let rF=e=>{let{activeFilter:t,activeFilterLabel:r,expandedKeys:a,expandAllPending:o,onCollapseAll:l,onNewKey:d,onToggleKey:c,onOpenAutofillSuggestions:p,onAddItem:u,onRemoveItem:m,onAddMappingForFilter:g,onInsertItem:h,getMappingIdByIndex:f}=e,{styles:x}=tM(),[v,y]=(0,i.useState)(null),b=(0,i.useRef)(null),j=(0,i.useCallback)(e=>{null!==b.current&&clearTimeout(b.current),y(e),b.current=setTimeout(()=>{y(null)},400)},[]),S=(0,i.useRef)(()=>void 0),C=(0,i.useRef)(()=>void 0),I=(0,i.useMemo)(()=>(e,t)=>{S.current(e,t)},[]),w=(0,i.useMemo)(()=>e=>{C.current(e)},[]),T=(0,i.useRef)([]),D=(0,i.useCallback)(e=>{let t=T.current;return t.length===e.length&&e.every((e,r)=>e.key===t[r].key&&e.name===t[r].name)?t:(T.current=e,e)},[]);return(0,n.jsx)(s.Flex,{className:x.panel,vertical:!0,children:(0,n.jsx)(s.Form.List,{name:"mappingConfig",children:(e,i)=>{let{add:s,remove:x}=i;S.current=s,C.current=x;let y=D(e),b=y.length>0,T=!o&&"all"!==a&&y.every(e=>!a.has(e.key));return(0,n.jsx)(rD,{activeFilter:t,activeFilterLabel:r,add:I,allVisibleCollapsed:T,expandedKeys:a,fields:y,flashIndex:v,getMappingIdByIndex:f,hasItems:b,onAddItem:u,onAddMappingForFilter:g,onCollapseAll:l,onDropped:j,onInsertItem:h,onNewKey:d,onOpenAutofillSuggestions:p,onRemoveItem:m,onToggleKey:c,remove:w})}})})},rN=e=>{let{options:t,valueRef:r,errorRef:a}=e,{t:o}=(0,l.useTranslation)(),[d,c]=(0,i.useState)(void 0),[p,u]=(0,i.useState)(!1);return a.current=u,(0,n.jsx)(s.Form.Item,{help:p?o("data-importer.mapping.new-modal.source-required"):void 0,label:o("data-importer.mapping.new-modal.source-label"),required:!0,style:{marginTop:12,marginBottom:0},validateStatus:p?"error":void 0,children:(0,n.jsx)(s.Select,{allowClear:!0,filterOption:E,onChange:e=>{c(e),r.current=e,void 0!==e&&u(!1)},options:t,placeholder:o("data-importer.mapping.item.source-placeholder"),showSearch:!0,style:{width:"100%"},value:d})})};function rk(){return!0===globalThis.__DI_MAPPING_DEBUG__}let r$=["array","boolean","date","quantityValue","asset","assetArray","gallery","dataObject","dataObjectArray"];function rL(e,t){let r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"manual",a=arguments.length>3?arguments[3]:void 0,n=arguments.length>4?arguments[4]:void 0,i=arguments.length>5?arguments[5]:void 0;return{mappingId:(0,x.uuid)(),label:t,dataSourceIndex:[e],transformationResultType:"autofill"===r?i??"default":void 0,dataTarget:{type:"direct",settings:{..."autofill"===r&&{fieldName:a??e},...void 0!==n&&""!==n&&{language:n},writeIfTargetIsNotEmpty:!0,writeIfSourceIsEmpty:!0}}}}let rM=()=>(0,n.jsxs)("svg",{fill:"none",height:"38",viewBox:"0 0 38 38",width:"38",xmlns:"http://www.w3.org/2000/svg",children:[(0,n.jsxs)("g",{clipPath:"url(#panel-arrow-clip)",children:[(0,n.jsx)("path",{d:"M26.9167 12.6641L33.25 18.9974L26.9167 25.3307",stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2"}),(0,n.jsx)("path",{d:"M33.25 19L24.7095 19C22.9533 19.0001 21.2242 18.5666 19.6758 17.738C18.1274 16.9094 16.8075 15.7113 15.8333 14.25C14.8592 12.7887 13.5393 11.5906 11.9909 10.762C10.4424 9.93337 8.71337 9.49988 6.95717 9.5L4.75 9.5",stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2"}),(0,n.jsx)("path",{d:"M33.25 19L24.7095 19C22.9533 18.9999 21.2242 19.4334 19.6758 20.262C18.1274 21.0906 16.8075 22.2887 15.8333 23.75C14.8592 25.2113 13.5393 26.4094 11.9909 27.238C10.4424 28.0666 8.71337 28.5001 6.95717 28.5L4.75 28.5",stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2"})]}),(0,n.jsx)("defs",{children:(0,n.jsx)("clipPath",{id:"panel-arrow-clip",children:(0,n.jsx)("rect",{fill:"white",height:"38",transform:"translate(38 1.66103e-06) rotate(90)",width:"38"})})})]});function rP(e){return e.toLowerCase().replace(/[^a-z0-9]/g,"")}function rR(e){return e.split(/(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])|[\s_.-]+/).map(e=>e.toLowerCase()).filter(e=>e.length>0)}function rA(e,t){if(0===e.length&&0===t.length)return 1;if(e.length<2||t.length<2)return+(e===t);let r=new Set,a=new Set;for(let t=0;t<e.length-1;t++)r.add(e.slice(t,t+2));for(let e=0;e<t.length-1;e++)a.add(t.slice(e,e+2));let n=0;r.forEach(e=>{a.has(e)&&n++});let i=r.size+a.size-n;return 0===i?0:n/i}function rO(e,t){if(0===e.length&&0===t.length)return 1;let r=new Set(e),a=new Set(t),n=0;r.forEach(e=>{a.has(e)&&n++});let i=r.size+a.size-n;return 0===i?0:n/i}function rE(e,t){let r=rP(e),a=rP(t.title),n=rP(t.key),i=t.key.lastIndexOf("."),o=i>=0?t.key.slice(i+1):null,l=null!==o?rP(o):null;if(r===a||r===n||null!==l&&r===l)return 100;let s=rR(e),d=rR(t.title),c=rR(t.key),p=Math.max(rO(s,d),rO(s,c),rA(r,a),rA(r,n));return null!==o&&null!==l&&(p=Math.max(p,rO(s,rR(o)),rA(r,l))),Math.round(100*p)}let rB=(0,p.createStyles)(e=>{let{css:t,token:r}=e;return{tableHeaderRow:t`
      padding: ${r.paddingXXS}px ${r.paddingMD}px;
      border-bottom: 1px solid ${r.colorBorderSecondary};
    `,tableHeaderCell:t`
      color: ${r.colorTextSecondary};
      white-space: nowrap;
    `,tableRow:t`
      padding: ${r.paddingXXS}px ${r.paddingMD}px;
      min-height: 36px;

      &:hover {
        background: ${r.colorFillAlter};
        cursor: pointer;
      }
    `,sourceCell:t`
      flex: 1.5;
      min-width: 0;
      overflow: hidden;
    `,destinationCell:t`
      flex: 2.5;
      min-width: 0;
      overflow: hidden;
    `,localeTag:t`
      flex-shrink: 0;
      font-size: ${r.fontSizeSM}px;
      background-color: ${r.colorPrimaryBg} !important;
      color: ${r.colorPrimary} !important;
      border-color: ${r.colorPrimaryBorder} !important;
    `,resultCell:t`
      flex: 2;
      min-width: 0;
      color: ${r.colorTextDescription};
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    `,cellText:t`
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    `,emptyState:t`
      padding: ${r.paddingXL}px ${r.paddingMD}px;
    `,scoreText:t`
      white-space: nowrap;
    `,dotGreen:t`
      display: inline-block;
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background-color: ${r.colorSuccess};
      flex-shrink: 0;
    `,dotYellow:t`
      display: inline-block;
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background-color: ${r.colorWarning};
      flex-shrink: 0;
    `,dotOrange:t`
      display: inline-block;
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background-color: ${r.colorWarningTextActive};
      flex-shrink: 0;
    `}}),rz=e=>{let{suggestions:t,selectedIds:r,onToggle:a,previewRow:i,hasPrevRow:o,isLoadingPreviewRow:d,onPrevRow:c,onNextRow:u}=e,{t:m}=(0,l.useTranslation)(),{styles:g}=rB(),h=(0,p.useTheme)();return 0===t.length?(0,n.jsx)("div",{className:g.emptyState,children:(0,n.jsx)(s.NoContent,{text:m("data-importer.mapping.autofill-suggestions.empty")})}):(0,n.jsxs)(s.Flex,{vertical:!0,children:[(0,n.jsxs)(s.Flex,{align:"center",className:g.tableHeaderRow,gap:"small",children:[(0,n.jsx)("div",{style:{width:24,flexShrink:0}}),(0,n.jsx)("div",{style:{width:56,flexShrink:0},children:(0,n.jsx)("span",{className:g.tableHeaderCell,children:m("data-importer.mapping.autofill-suggestions.score")})}),(0,n.jsx)("div",{className:g.sourceCell,children:(0,n.jsx)("span",{className:g.tableHeaderCell,children:m("data-importer.mapping.autofill-suggestions.source")})}),(0,n.jsx)("div",{style:{width:36,flexShrink:0}}),(0,n.jsx)(s.Flex,{align:"center",className:g.destinationCell,gap:h.paddingSM,children:(0,n.jsx)("span",{className:g.tableHeaderCell,children:m("data-importer.mapping.autofill-suggestions.destination")})}),(0,n.jsx)("div",{className:g.resultCell,children:(0,n.jsxs)(s.Flex,{align:"center",justify:"space-between",children:[(0,n.jsx)("span",{className:g.tableHeaderCell,children:m("data-importer.mapping.autofill-suggestions.result")}),(0,n.jsxs)(s.Flex,{align:"center",gap:4,children:[(0,n.jsx)(s.IconButton,{disabled:!o||d,icon:{value:"chevron-left"},onClick:c,size:"small",type:"text"}),(0,n.jsx)(s.IconButton,{disabled:d,icon:{value:"chevron-right"},onClick:u,size:"small",type:"text"})]})]})})]}),t.map(e=>{var t;return(0,n.jsxs)(s.Flex,{align:"center",className:g.tableRow,gap:"small",onClick:()=>{a(e.id)},children:[(0,n.jsx)("div",{style:{width:24,flexShrink:0},children:(0,n.jsx)(s.Checkbox,{checked:r.has(e.id),onChange:()=>{a(e.id)},onClick:e=>{e.stopPropagation()}})}),(0,n.jsx)("div",{style:{width:56,flexShrink:0},children:(0,n.jsxs)(s.Flex,{align:"center",gap:6,children:[(0,n.jsx)("span",{className:g.scoreText,children:`${e.score}%`}),(0,n.jsx)("span",{className:(t=e.score,t>=90?g.dotGreen:t>=70?g.dotYellow:g.dotOrange)})]})}),(0,n.jsx)("div",{className:g.sourceCell,children:(0,n.jsx)("span",{className:g.cellText,children:`${e.sourceLabel} [${e.sourceIndex}]`})}),(0,n.jsx)(s.Flex,{align:"center",justify:"center",style:{width:36,flexShrink:0},children:(0,n.jsx)(rd,{fill:h.colorTextTertiary})}),(0,n.jsxs)(s.Flex,{align:"center",className:g.destinationCell,gap:h.paddingSM,children:[(0,n.jsx)("span",{className:g.cellText,children:`Direct, ${e.targetFieldLabel}`}),null!==e.language&&(0,n.jsx)(s.Tag,{className:g.localeTag,children:e.language})]}),(0,n.jsx)("div",{className:g.resultCell,children:d?(0,n.jsx)(s.Spin,{size:"small",type:"classic"}):i[e.sourceIndex]??""})]},e.id)})]})};function rH(){return!0===globalThis.__DI_MAPPING_DEBUG__}let rq=o().memo(e=>{let{configName:t,isActive:r}=e,{styles:a}=tM(),{t:o}=(0,l.useTranslation)(),d=(0,p.useTheme)(),{validLanguages:u}=(0,c.useSettings)(),m=(0,s.useFormModal)(),g=(0,s.useMessage)(),h=s.Form.useFormInstance(),f=s.Form.useWatch(["loaderConfig","type"]),v=s.Form.useWatch(["interpreterConfig","type"]),{columnHeaderOptions:y,initialLoadDone:b,sourceRows:S,hasPreviewError:C,attributesMap:I,classId:w,getMappingConfig:T,getBackendConfig:D}=function(e,t){var r,a;let n=s.Form.useFormInstance(),o=(0,l.useAppDispatch)(),{data:d,isSuccess:c,requestId:p}=tu({name:e}),[u,m]=(0,i.useState)([]),[g,h]=(0,i.useState)(!1),[f,x]=(0,i.useState)([]),[v,y]=(0,i.useState)(!1),[b,S]=(0,i.useState)({}),C=tj(),[I,w]=(0,i.useState)(void 0),[T,D]=(0,i.useState)(void 0),[F,N]=(0,i.useState)(!1),{data:k,refetch:$,isFetching:L,isError:M,isSuccess:P}=tt(I,{skip:void 0===I,refetchOnMountOrArgChange:!1}),{data:R,refetch:A,isFetching:O,isError:E,isSuccess:B}=tr(T,{skip:void 0===T,refetchOnMountOrArgChange:!1}),z=null==d||null==(a=d.configuration)||null==(r=a.resolverConfig)?void 0:r.dataObjectClassId,H=s.Form.useWatch(["resolverConfig","dataObjectClassId"])??z,q=s.Form.useWatch(e=>JSON.stringify((e.mappingConfig??[]).map(e=>e.transformationResultType??""))),W=(0,i.useMemo)(()=>void 0!==q?JSON.parse(q):void 0,[q]),X=(0,i.useCallback)(()=>n.getFieldValue("mappingConfig")??[],[n]),V=(0,i.useCallback)(()=>j(n.getFieldsValue(!0),(null==d?void 0:d.configuration)??{}),[n,d]),_=(0,i.useCallback)(()=>{let e=V();return{loaderConfig:e.loaderConfig,interpreterConfig:e.interpreterConfig}},[V]);(0,i.useEffect)(()=>{P&&void 0!==k&&m((k.columnHeaders??[]).map(e=>({value:String(e.dataIndex??e.id??""),label:String(e.label??e.dataIndex??e.id??"")})))},[P,k]),(0,i.useEffect)(()=>{M&&m([])},[M]),(0,i.useEffect)(()=>{if(!B||void 0===R)return;let e=(R.dataPreview??[]).map(e=>tL(e));x(e),y(0===e.length)},[B,R]),(0,i.useEffect)(()=>{E&&(x([]),y(!0))},[E]),(0,i.useEffect)(()=>{let e=void 0!==T&&!O;h(void 0!==I&&!L&&F&&e)},[I,T,L,O,F]);let G=s.Form.useWatch(["loaderConfig","type"]),U=s.Form.useWatch(["interpreterConfig","type"]),K=(0,i.useMemo)(()=>JSON.stringify(_()),[G,U,d]),[Q,Y]=(0,i.useState)(""),[J,Z]=(0,i.useState)(void 0),ee=(0,i.useRef)(0),et=(0,i.useRef)(!1);return(0,i.useEffect)(()=>{if(!c||!t){et.current=t;return}let r=K!==Q,a=void 0!==p&&p!==J,i=!et.current&&t;if(et.current=t,!r&&!a){i&&void 0!==I&&void 0!==T&&Promise.all([$().catch(()=>void 0),A().catch(()=>void 0)]);return}let l=rk(),s=++ee.current,u=l?performance.now():0;l&&console.debug("[DI][Loader] source config refresh start",{cycleId:s,configName:e,argsChanged:r,requestChanged:a,loaderConfigType:G,interpreterConfigType:U,classId:z}),h(!1),N(!1),y(!1),w({name:e,bundleDataImporterCopyPreviewParameters:{currentConfig:_(),previewScope:C}}),D({name:e,bundleDataImporterLoadPreviewParameters:{currentConfig:_(),previewScope:C,recordNumber:0}}),a&&!r&&void 0!==I&&void 0!==T&&(l&&console.debug("[DI][Loader] refetch headers+preview",{cycleId:s}),Promise.all([$().catch(()=>void 0),A().catch(()=>void 0)])),(async()=>{let e=l?performance.now():0;try{let e=n.getFieldValue(["resolverConfig","dataObjectClassId"])??z,t=((null==d?void 0:d.configuration)??{}).mappingConfig??[],r=new Set;void 0!==e&&""!==e&&(r.add(void 0),r$.forEach(e=>r.add(e)),t.forEach(e=>{r.add(e.transformationResultType)}));let i=Array.from(r);l&&console.debug("[DI][Loader] class attributes load start",{cycleId:s,effectiveClassId:e,types:i.map(e=>e??tA)});let c=i.map(async t=>await o(tp.endpoints.bundleDataImporterDataTypeLoadClassAttributes.initiate({classId:e,transformationResultType:t,systemWrite:!0},{forceRefetch:a}))),p=await Promise.all(c);if(i.length>0){let e={};p.forEach((t,r)=>{var a;let n=i[r],o=((null==(a=t.data)?void 0:a.attributes)??[]).map(ri);e[void 0===n||""===n||"default"===n?tA:n]=o}),S(t=>{let r=!1;for(let a of Object.keys(e))if(t[a]!==e[a]){r=!0;break}return r?{...t,...e}:t})}}finally{l&&console.debug("[DI][Loader] class attributes load done",{cycleId:s,durationMs:Number((performance.now()-e).toFixed(2))}),N(!0)}})(),l&&console.debug("[DI][Loader] source config refresh queued",{cycleId:s,durationMs:Number((performance.now()-u).toFixed(2))}),Y(K),Z(p)},[c,t,e,K,Q,p,J,_,I,T,$,A,o,n,d,z]),(0,i.useEffect)(()=>{var e;!rk()||P&&console.debug("[DI][Loader] headers load success",{count:(null==k||null==(e=k.columnHeaders)?void 0:e.length)??0})},[P,k]),(0,i.useEffect)(()=>{!rk()||M&&console.debug("[DI][Loader] headers load error")},[M]),(0,i.useEffect)(()=>{!rk()||B&&console.debug("[DI][Loader] preview load success",{rowCount:((null==R?void 0:R.dataPreview)??[]).length})},[B,R]),(0,i.useEffect)(()=>{!rk()||E&&console.debug("[DI][Loader] preview load error")},[E]),(0,i.useEffect)(()=>{if(void 0===H||""===H||!g)return;let e=X(),t=new Set;if(e.forEach(e=>{let r=tO(e.transformationResultType);void 0===b[r]&&t.add(r)}),0===t.size)return;let r=Array.from(t);Promise.all(r.map(async e=>await o(tp.endpoints.bundleDataImporterDataTypeLoadClassAttributes.initiate({classId:H,transformationResultType:e===tA?void 0:e,systemWrite:!0})))).then(e=>{S(t=>{let a={};return(e.forEach((e,t)=>{var n;a[r[t]]=((null==(n=e.data)?void 0:n.attributes)??[]).map(ri)}),r.some(e=>t[e]!==a[e]))?{...t,...a}:t})})},[W,g,H]),{columnHeaderOptions:u,initialLoadDone:g,sourceRows:f,hasPreviewError:v,attributesMap:b,setAttributesMap:S,classId:H,mappingTrtList:W,getMappingConfig:X,getBackendConfig:V}}(t,r),{dataPreview:F,currentRecordIndex:N,isFetching:k,load:$}=tS({configName:t,enabled:r,getCurrentConfig:D}),[L,M]=(0,i.useState)(new Set),[R,A]=(0,i.useState)(!1),[,O]=(0,i.useTransition)(),[E,B]=(0,i.useState)(null),[z,H]=(0,i.useState)(null),[q,W]=(0,i.useState)(new Set),X=(0,i.useRef)(!0),V=(0,i.useRef)(f),_=(0,i.useRef)(v),G=(0,i.useRef)(null),U=(0,i.useRef)(E);U.current=E;let K=(0,i.useMemo)(()=>{var e;return null===E?null:(null==(e=S.find(e=>e.dataIndex===E))?void 0:e.label)??E},[E,S]),Q=(0,i.useMemo)(()=>({configName:t,classId:w,columnHeaderOptions:y,attributesMap:I,sourceRows:S}),[t,w,y,I,S]);(0,i.useEffect)(()=>{let e=V.current!==f,t=_.current!==v;(e||t)&&(rH()&&console.debug("[DI][Action] reset expanded panels on source type change",{prevLoaderType:V.current,nextLoaderType:f,prevInterpreterType:_.current,nextInterpreterType:v}),M(new Set),V.current=f,_.current=v)},[f,v]);let Y=(0,i.useRef)(L);Y.current=L;let J=(0,i.useCallback)(e=>{let t=Y.current,r="all"===t?new Set(e):t,a=e.every(e=>!r.has(e)),n=a?"expand-all":"collapse-all";if(G.current={action:n,startedAt:performance.now()},rH()&&console.debug("[DI][Action] toggle expand/collapse all",{action:n,visibleCount:e.length,previouslyExpandedVisibleCount:e.filter(e=>r.has(e)).length}),a)X.current=!0,A(!0),O(()=>{M("all"),A(!1)});else{X.current=!1;let t=new Set(r);e.forEach(e=>t.delete(e)),M(t)}},[]);(0,i.useEffect)(()=>{if(!rH()||null===G.current||"collapse-all"!==G.current.action)return;let e=G.current;G.current=null,requestAnimationFrame(()=>{requestAnimationFrame(()=>{console.debug("[DI][Perf] expand/collapse all painted",{action:e.action,durationMs:Number((performance.now()-e.startedAt).toFixed(2))})})})},[L]);let Z=(0,i.useCallback)((e,t)=>{M(r=>{let a=new Set("all"===r?t:r);return a.has(e)?a.delete(e):a.add(e),a})},[]),ee=(0,i.useCallback)(e=>{M(t=>{if(!X.current)return t;if("all"===t)return"all";let r=new Set(t);return r.add(e),r})},[]),et=(0,i.useCallback)((e,t)=>{let r=rH();r&&console.debug("[DI][Action] remove mapping requested",{index:t,beforeCount:T().length,activeFilter:U.current});let a=U.current,n=null;null!==a&&(T().filter((e,r)=>r!==t).some(e=>(e.dataSourceIndex??[]).includes(a))||(n=a,B(null))),e(t),r&&console.debug("[DI][Action] remove mapping done",{index:t,clearedFilter:n,keptFilter:null===n?a:null})},[T]),er=(0,i.useCallback)((e,t)=>rL(e,t,"manual"),[]),ea=(0,i.useCallback)((e,t)=>{let r={current:void 0},a={current:void 0};m.confirm({title:o("data-importer.mapping.new-modal.title"),content:(0,n.jsx)(rN,{errorRef:a,options:y,valueRef:r}),okText:o("data-importer.mapping.add"),onOk:async()=>{var t,n;let i=r.current;if(void 0===i)return null==(n=a.current)||n.call(a,!0),await Promise.reject(Error("source required"));let o=(null==(t=y.find(e=>e.value===i))?void 0:t.label)??i;rH()&&console.debug("[DI][Action] add mapping via modal",{dataIndex:i,label:o,insertIndex:0,beforeCount:T().length}),e(er(i,o),0);let l=U.current;null!==l&&l!==i&&B(i)}})},[m,o,y,er,T]),en=(0,i.useCallback)((e,t,r,a)=>{rH()&&console.debug("[DI][Action] insert mapping via drop",{dataIndex:r,label:a,insertIndex:t,beforeCount:T().length}),e(er(r,a),t)},[er,T]),ei=(0,i.useMemo)(()=>(F.length>0?F.map(tL):S).reduce((e,t)=>(e[t.dataIndex]=t.value,e),{}),[F,S]),eo=(0,i.useCallback)(()=>{if(0===y.length)return void g.warning(o("data-importer.mapping.autofill-suggestions.no-source-columns"));let e=function(e,t,r,a,n){let i,o=(i=new Set,r.forEach(e=>{(e.dataSourceIndex??[]).forEach(e=>i.add(e))}),i),l=function(e){let t=new Map;for(let r of[tA,...Object.keys(e).filter(e=>e!==tA)])for(let a of e[r]??[])t.has(a.key)||t.set(a.key,{attr:a,transformationResultType:r===tA?"default":r});return Array.from(t.values())}(t),s=new Set(n.map(e=>e.toLowerCase())),d=[];for(let t of e){if(o.has(t.value))continue;let e=function(e,t,r){let a=function(e,t){let r=/^(.*?)[_.-]([a-z]{2})(?:[_-]([A-Za-z]{2,4}))?$/.exec(e);if(null===r)return null;let a=r[1],n=r[2],i=r[3];return 0!==a.length&&t.has(n)?{base:a,locale:void 0!==i?`${n}_${i.toUpperCase()}`:n}:null}(e,r),n=-1,i=null,o=-1,l=null,s=null;for(let r of t){let t=rE(e,r.attr);if(t>n&&(n=t,i=r),!0===r.attr.localized&&null!==a){let e=rE(a.base,r.attr);e>o&&(o=e,l=r,s=a.locale)}}let d=o>=n&&null!==l,c=d?l:i,p=d?o:n,u=d?s:null;return null===c||p<40?null:{entry:c,score:p,language:u}}(t.label,l,s);if(null===e)continue;let r=a.find(e=>e.dataIndex===t.value);d.push({id:(0,x.uuid)(),sourceIndex:t.value,sourceLabel:t.label,targetFieldName:e.entry.attr.key,targetFieldLabel:e.entry.attr.title,transformationResultType:e.entry.transformationResultType,score:e.score,language:e.language,previewResult:(null==r?void 0:r.value)??null})}return d.sort((e,t)=>t.score-e.score)}(y,I,T(),S,u??[]);H(e),W(new Set(e.map(e=>e.id))),$(0)},[T,y,I,S,u,g,o,$]),el=(0,i.useCallback)(()=>{let e=Math.max(0,N-1);e!==N&&$(e)},[N,$]),es=(0,i.useCallback)(()=>{$(N+1)},[N,$]),ed=(0,i.useCallback)(e=>{W(t=>{let r=new Set(t);return r.has(e)?r.delete(e):r.add(e),r})},[]),ec=(0,i.useCallback)(()=>{H(null),W(new Set)},[]),ep=(0,i.useCallback)(()=>{null!==z&&W(e=>z.every(t=>e.has(t.id))?new Set:new Set(z.map(e=>e.id)))},[z]),eu=(0,i.useCallback)(()=>{if(null===z)return;let e=z.filter(e=>q.has(e.id)).map(e=>rL(e.sourceIndex,e.sourceLabel,"autofill",e.targetFieldName,e.language??void 0,e.transformationResultType)),t=T();rH()&&console.debug("[DI][Action] autofill suggestions applied",{appliedCount:e.length,beforeCount:t.length}),h.setFieldValue("mappingConfig",[...t,...e],{triggerChange:!0}),H(null),W(new Set)},[z,q,T,h]),em=(0,i.useCallback)((e,t)=>{let r=T(),a=er(e,t);rH()&&console.debug("[DI][Action] add mapping from source panel",{dataIndex:e,label:t,beforeCount:r.length}),h.setFieldValue("mappingConfig",[...r,a],{triggerChange:!0})},[T,er,h]),eg=(0,i.useCallback)(e=>{let t=U.current;if(null===t)return;let r=K??t;rH()&&console.debug("[DI][Action] add mapping for active filter",{dataIndex:t,label:r,beforeCount:T().length}),e(er(t,r))},[K,er,T]),eh=(0,i.useCallback)(e=>(function(e,t){let r=e.getFieldValue(["mappingConfig",t]),a=null==r?void 0:r.mappingId;if(void 0!==a&&""!==a)return a;let n=(0,x.uuid)();return e.setFieldValue(["mappingConfig",t,"mappingId"],n,{triggerChange:!1}),n})(h,e),[h]),ef=(0,i.useMemo)(()=>{if(null!==z&&0===z.length)return[(0,n.jsx)(s.Button,{onClick:ec,type:"primary",children:o("data-importer.mapping.autofill-suggestions.ok")},"ok")];let e=null!==z&&z.length>0&&z.every(e=>q.has(e.id)),t=(null==z?void 0:z.some(e=>q.has(e.id)))===!0;return(0,n.jsxs)(s.Flex,{style:{width:"100%"},children:[(0,n.jsxs)(s.Flex,{align:"center",gap:"small",style:{flex:1},children:[(0,n.jsx)(s.Checkbox,{checked:e,indeterminate:t&&!e,onChange:ep}),(0,n.jsx)("span",{children:o("data-importer.mapping.autofill-suggestions.selected",{count:q.size})})]}),k&&(0,n.jsx)(s.Spin,{size:"small",style:{marginInlineEnd:8},type:"classic"}),(0,n.jsxs)(s.Flex,{align:"center",gap:"small",children:[(0,n.jsx)(s.Button,{onClick:ec,type:"default",children:o("data-importer.mapping.autofill-suggestions.reject-all")}),(0,n.jsx)(s.Button,{disabled:0===q.size,onClick:eu,type:"primary",children:o("data-importer.mapping.autofill-suggestions.apply")})]})]})},[o,z,q,k,ep,ec,eu]);return(0,n.jsxs)(s.Content,{loading:!b,children:[(0,n.jsx)(rS,{value:Q,children:(0,n.jsxs)(s.Flex,{className:a.mappingLayout,children:[(0,n.jsx)("div",{className:a.mappingLayoutLeft,children:(0,n.jsx)(tR,{activeFilter:E,configName:t,hasPreviewError:C,onAddMappingFromSource:em,onSetFilter:B,sourceRows:S})}),(0,n.jsx)(s.Flex,{align:"center",className:a.mappingLayoutCenter,vertical:!0,children:(0,n.jsx)(s.Flex,{align:"center",className:a.mappingLayoutCenterArrow,justify:"center",children:(0,n.jsx)(rM,{})})}),(0,n.jsx)("div",{className:a.mappingLayoutRight,children:(0,n.jsx)(P.FieldWidthProvider,{fieldWidthValues:{small:9999,medium:9999,large:9999},children:(0,n.jsx)(rF,{activeFilter:E,activeFilterLabel:K,expandAllPending:R,expandedKeys:L,getMappingIdByIndex:eh,onAddItem:ea,onAddMappingForFilter:eg,onCollapseAll:J,onInsertItem:en,onNewKey:ee,onOpenAutofillSuggestions:eo,onRemoveItem:et,onToggleKey:Z})})})]})}),(0,n.jsx)(s.Modal,{footer:ef,onCancel:ec,open:null!==z,styles:{body:{padding:0,paddingBlock:0,paddingInline:0,maxHeight:"60vh",overflowY:"auto"},footer:{padding:"12px 16px",borderTop:null!==z&&z.length>0?`1px solid ${d.colorPrimaryBorder}`:"none"}},title:o("data-importer.mapping.autofill-suggestions.title"),width:1100,children:null!==z&&(0,n.jsx)(rz,{hasPrevRow:N>0,isLoadingPreviewRow:k,onNextRow:es,onPrevRow:el,onToggle:ed,previewRow:ei,selectedIds:q,suggestions:z})})]})});rq.displayName="MappingStep";let rW=(0,p.createStyles)(e=>{let{css:t,token:r}=e;return{loggingGroups:t`
      width: 100%;
    `,loggingGroup:t`
      width: 100%;
    `,loggingGroupTitle:t`
      margin-bottom: ${r.paddingXS}px;
      font-size: ${r.fontSize}px;
      font-weight: 600;
      color: ${r.colorTextHeading};
    `,loggingItem:t`
      margin-bottom: ${r.paddingXS}px;
    `,loggingItemLast:t`
      margin-bottom: 0;
    `}}),rX=e=>{let{columnHeaderOptions:t}=e,{t:r}=(0,l.useTranslation)(),{styles:a,cx:o}=rW(),d=s.Form.useFormInstance(),c=[{value:"sequential",label:r("data-importer.processing.execution-type.sequential")},{value:"parallel",label:r("data-importer.processing.execution-type.parallel")}],p=[{value:"delete",label:r("data-importer.processing.cleanup.strategy.delete")},{value:"unpublish",label:r("data-importer.processing.cleanup.strategy.unpublish")}],u=void 0!==rh(["processingConfig","doDeltaCheck"]),m=void 0!==rh(["processingConfig","cleanup","doCleanup"]),g=void 0!==rh(["processingConfig","cleanup","strategy"]),h=s.Form.useWatch(["processingConfig","logging","disableInfoLogs"]),f=s.Form.useWatch(["processingConfig","logging","disableErrorLogs"]);return(0,i.useEffect)(()=>{!0===h&&d.setFieldValue(["processingConfig","logging","disableInfoFileObjects"],!0)},[h,d]),(0,i.useEffect)(()=>{!0===f&&d.setFieldValue(["processingConfig","logging","disableErrorFileObjects"],!0)},[f,d]),(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(M,{children:r("data-importer.processing.title")}),(0,n.jsxs)(O,{title:r("data-importer.processing.execution.title"),children:[(0,n.jsx)(s.Form.Item,{label:r("data-importer.processing.execution-type"),name:["processingConfig","executionType"],tooltip:r("data-importer.processing.execution-type.tooltip"),children:(0,n.jsx)(s.Select,{filterOption:E,options:c,showSearch:!0})}),(0,n.jsx)(s.Form.Item,{name:["processingConfig","doArchiveImportFile"],valuePropName:"checked",children:(0,n.jsx)(s.Switch,{labelRight:r("data-importer.processing.archive-import-file")})}),(0,n.jsx)(s.Form.Item,{name:["processingConfig","disableVersioning"],valuePropName:"checked",children:(0,n.jsx)(s.Switch,{labelRight:r("data-importer.processing.disable-versioning")})})]}),(0,n.jsxs)(O,{title:r("data-importer.processing.id-delta.title"),children:[(0,n.jsx)(s.Form.Item,{label:r("data-importer.processing.id-data-index"),name:["processingConfig","idDataIndex"],tooltip:r("data-importer.processing.id-data-index.tooltip"),children:(0,n.jsx)(s.Select,{allowClear:!0,filterOption:E,options:t,placeholder:r("data-importer.processing.id-data-index-placeholder"),showSearch:!0})}),(0,n.jsxs)(s.Form.Conditional,{condition:e=>{var t;return!!(null==(t=e.processingConfig)?void 0:t.idDataIndex)||u||m||g},children:[(0,n.jsx)(s.Form.Item,{name:["processingConfig","doDeltaCheck"],valuePropName:"checked",children:(0,n.jsx)(s.Switch,{labelRight:r("data-importer.processing.delta-check")})}),(0,n.jsx)(s.Form.Item,{name:["processingConfig","cleanup","doCleanup"],valuePropName:"checked",children:(0,n.jsx)(s.Switch,{labelRight:r("data-importer.processing.cleanup.do-cleanup")})}),(0,n.jsx)(s.Form.Conditional,{condition:e=>{var t,r;return!!(null==(r=e.processingConfig)||null==(t=r.cleanup)?void 0:t.doCleanup)||g},children:(0,n.jsx)(O,{theme:"fieldset",title:r("data-importer.processing.cleanup.title"),children:(0,n.jsx)(s.Form.Item,{label:r("data-importer.processing.cleanup.strategy"),name:["processingConfig","cleanup","strategy"],tooltip:r("data-importer.processing.cleanup.strategy.tooltip"),children:(0,n.jsx)(s.Select,{filterOption:E,options:p,showSearch:!0})})})})]})]}),(0,n.jsx)(O,{title:r("data-importer.processing.logging.title"),children:(0,n.jsxs)(s.Flex,{className:a.loggingGroups,gap:"small",vertical:!0,children:[(0,n.jsxs)("div",{className:a.loggingGroup,children:[(0,n.jsx)("div",{className:a.loggingGroupTitle,children:r("data-importer.processing.logging.info.title")}),(0,n.jsx)(s.Form.Item,{className:a.loggingItem,name:["processingConfig","logging","disableInfoLogs"],valuePropName:"checked",children:(0,n.jsx)(s.Switch,{labelRight:r("data-importer.processing.logging.info.disable-logs")})}),(0,n.jsx)(s.Form.Item,{className:o(a.loggingItem,a.loggingItemLast),name:["processingConfig","logging","disableInfoFileObjects"],valuePropName:"checked",children:(0,n.jsx)(s.Switch,{disabled:!0===h,labelRight:r("data-importer.processing.logging.info.disable-file-objects")})})]}),(0,n.jsxs)("div",{className:a.loggingGroup,children:[(0,n.jsx)("div",{className:a.loggingGroupTitle,children:r("data-importer.processing.logging.error.title")}),(0,n.jsx)(s.Form.Item,{className:a.loggingItem,name:["processingConfig","logging","disableErrorLogs"],valuePropName:"checked",children:(0,n.jsx)(s.Switch,{labelRight:r("data-importer.processing.logging.error.disable-logs")})}),(0,n.jsx)(s.Form.Item,{className:o(a.loggingItem,a.loggingItemLast),name:["processingConfig","logging","disableErrorFileObjects"],valuePropName:"checked",children:(0,n.jsx)(s.Switch,{disabled:!0===f,labelRight:r("data-importer.processing.logging.error.disable-file-objects")})})]})]})})]})},rV=(0,p.createStyles)(e=>{let{css:t,token:r}=e;return{tabLayout:t`
      height: 100%;
      min-height: 0;
    `,stepContent:t`
      flex: 1;
      min-height: 0;
      overflow-y: auto;
      padding: ${r.paddingXS}px ${r.paddingSM}px;
    `,stepContentHidden:t`
      display: none;
    `,stepContentMapping:t`
      flex: 1;
      height: 0;
      overflow: auto;
    `,stepContentMappingHidden:t`
      display: none;
    `}}),r_=function(e,t){let r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:0,a=s.Form.useFormInstance(),{data:n}=tu({name:e}),o=tj(),l=s.Form.useWatch(["loaderConfig","type"]),d=s.Form.useWatch(["interpreterConfig","type"]),c=(0,i.useMemo)(()=>{if(void 0===n||void 0===l)return;let t=j(a.getFieldsValue(!0),n.configuration??{});return{name:e,bundleDataImporterCopyPreviewParameters:{previewScope:o,currentConfig:{loaderConfig:t.loaderConfig,interpreterConfig:t.interpreterConfig}}}},[e,n,a,l,d,o]),{data:p,refetch:u}=tt(c,{skip:void 0===c||!t}),m=(0,i.useRef)(r);return(0,i.useEffect)(()=>{t&&void 0!==c&&r!==m.current&&(m.current=r,u().catch(()=>void 0))},[t,r,c,u]),(0,i.useMemo)(()=>((null==p?void 0:p.columnHeaders)??(null==n?void 0:n.columnHeaders)??[]).map(e=>({value:"string"==typeof e?e:e.dataIndex??"",label:"string"==typeof e?e:e.label??e.dataIndex??""})),[null==p?void 0:p.columnHeaders,null==n?void 0:n.columnHeaders])},rG=e=>{let{configName:t,activeStep:r,onStepChange:a}=e,{t:o}=(0,l.useTranslation)(),{styles:d}=rV(),[c,p]=(0,i.useState)(0),u=r??c,[m,g]=(0,i.useState)(0),h=r_(t,2===u||4===u,m),f=(0,i.useMemo)(()=>[{title:o("data-importer.data-setup.steps.data-source.title")},{title:o("data-importer.data-setup.steps.preview-import.title")},{title:o("data-importer.data-setup.steps.resolver.title")},{title:o("data-importer.data-setup.steps.mapping.title")},{title:o("data-importer.data-setup.steps.processing-settings.title")}],[o]),x=3===u;return(0,n.jsxs)(s.Flex,{className:d.tabLayout,vertical:!0,children:[(0,n.jsx)(s.Box,{margin:{x:"small"},children:(0,n.jsx)(s.Steps,{current:u,items:f,onChange:e=>{p(e),null==a||a(e)},size:"small",type:"navigation"})}),(0,n.jsx)("div",{className:$()(d.stepContentMapping,!x&&d.stepContentMappingHidden),children:(0,n.jsx)(rq,{configName:t,isActive:x})}),(0,n.jsx)("div",{className:$()(d.stepContent,0!==u&&d.stepContentHidden),children:(0,n.jsx)(eY,{configName:t})}),(0,n.jsx)("div",{className:$()(d.stepContent,1!==u&&d.stepContentHidden),children:(0,n.jsx)(tw,{configName:t,isActive:1===u,onPreviewDataChange:()=>{g(e=>e+1)}})}),(0,n.jsx)("div",{className:$()(d.stepContent,2!==u&&d.stepContentHidden),children:(0,n.jsx)(t$,{columnHeaderOptions:h,configName:t,isActive:2===u})}),(0,n.jsx)("div",{className:$()(d.stepContent,4!==u&&d.stepContentHidden),children:(0,n.jsx)(rX,{columnHeaderOptions:h})})]})};var rU=r(6514),rK=r(8221),rQ=r.n(rK);let rY=()=>{let{t:e}=(0,l.useTranslation)(),t=s.Form.useFormInstance(),r=s.Form.useWatch(["executionConfig","cronDefinition"])??"",a=s.Form.useWatch(["loaderConfig","type"]),[o,d]=(0,i.useState)(r),[c,p]=(0,i.useState)(!1),u=(0,i.useCallback)(rQ()(e=>{d(e),p(!1)},500),[]);(0,i.useEffect)(()=>()=>{u.cancel()},[u]),(0,i.useEffect)(()=>{r.trim().length>0&&p(!0),u(r)},[r,u]);let m=0===o.trim().length,{data:g,isFetching:h}=tc({cronExpression:o},{skip:m}),f=(c||h)&&r.trim().length>0;(0,i.useEffect)(()=>{c||h||t.validateFields([["executionConfig","cronDefinition"]],{dirty:!1}).catch(()=>{})},[g,h,c,m]);let{t:x}=(0,l.useTranslation)(),v=(0,i.useMemo)(()=>({async validator(e,t){void 0===t||0===t.trim().length?await Promise.resolve():c||h||void 0===g?await Promise.reject(Error("")):g.isValid?await Promise.resolve():await Promise.reject(Error(g.message))}}),[c,h,g,x]);return(0,n.jsx)(s.Form.Item,{hasFeedback:!f&&r.trim().length>0,label:(0,n.jsxs)(s.Flex,{align:"center",gap:8,children:[(0,n.jsx)("span",{children:e("data-importer.execution.cron-definition")}),(0,n.jsx)(s.Button,{href:"https://crontab.guru/",icon:(0,n.jsx)(s.Icon,{value:"share-nodes"}),rel:"noopener noreferrer",target:"_blank",type:"link",children:e("data-importer.execution.cron-generator")})]}),name:["executionConfig","cronDefinition"],rules:[v],validateStatus:f?"":void 0,children:(0,n.jsx)(s.Input,{disabled:"push"===a,onBlur:()=>{u.flush()},placeholder:"0 2 * * *",suffix:f?(0,n.jsx)(rU.A,{spin:!0}):(0,n.jsx)("span",{})})})},rJ=e=>{let{isDirty:t,isStarting:r,onStart:a,label:i}=e,{t:o}=(0,l.useTranslation)(),d="push"===s.Form.useWatch(["loaderConfig","type"]),c=d||t||r,p=t?o("data-importer.execution.start-import.tooltip-dirty"):d?o("data-importer.execution.start-import.tooltip-push"):void 0;return(0,n.jsx)(s.Tooltip,{title:p,children:(0,n.jsx)("span",{children:(0,n.jsx)(s.Button,{disabled:c,loading:r&&!d,onClick:a,type:"primary",children:i})})})},rZ=(0,p.createStyles)(e=>{let{token:t,css:r}=e;return{progressLabel:r`
      font-size: 12px;
      font-weight: 400;
      line-height: 22px;
      color: ${t.colorText};
      margin: 0;
    `,progressWrapper:r`
      width: 100%;

      /* antd Progress root is inline-flex by default — override to fill full width */
      .ant-progress {
        display: block;
        width: 100%;
        margin-bottom: 0;
      }

      /* Ensure the inner bar line fills the wrapper */
      .ant-progress-inner {
        width: 100% !important;
      }

      /* Pad the inner text so it sits 8px from the left edge */
      .ant-progress-text {
        padding-inline-start: ${t.paddingXS}px;
      }
    `,colorFill:t.colorFill,colorBgLayout:t.colorBgLayout}}),r0=e=>{let{configName:t,isDirty:r}=e,{t:a}=(0,l.useTranslation)(),o=(0,s.useMessage)(),{styles:d}=rZ(),[p,{isLoading:u}]=tf(),[m,{isLoading:g}]=tx(),{data:h,refetch:f}=th({name:t},{pollingInterval:5e3}),[x,v]=(0,i.useState)(!1),[y,b]=(0,i.useState)(null),[j,S]=(0,i.useState)(!1),[C,I]=(0,i.useState)(!1);(0,i.useEffect)(()=>{(null==h?void 0:h.isRunning)===!0&&(v(!1),b(null),I(!1))},[null==h?void 0:h.isRunning]),(0,i.useEffect)(()=>{(null==h?void 0:h.isRunning)===!1&&(S(!1),(h.processedItems??0)>0&&I(!0))},[null==h?void 0:h.isRunning]);let w=!j&&(x||((null==h?void 0:h.isRunning)??!1)),T=(null==y?void 0:y.progress)??(null==h?void 0:h.progress)??0,D=(null==y?void 0:y.processedItems)??(null==h?void 0:h.processedItems)??0,F=(null==y?void 0:y.totalItems)??(null==h?void 0:h.totalItems)??0,N=async()=>{let e=await p({name:t});if("error"in e){void 0!==e.error&&(0,c.trackError)(new c.ApiError(e.error)),o.error(a("data-importer.execution.start-import.error"));return}e.data.success?(o.success(a("data-importer.execution.start-import.success")),b({processedItems:0,totalItems:(null==h?void 0:h.totalItems)??0,progress:0}),v(!0),I(!1)):o.error(a("data-importer.execution.start-import.error")),f()},k=async()=>{let e=await m({name:t});if("error"in e){void 0!==e.error&&(0,c.trackError)(new c.ApiError(e.error)),o.error(a("data-importer.execution.cancel.error"));return}o.success(a("data-importer.execution.cancel.success")),S(!0),v(!1),b(null),I(!1),f()};return(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(O,{title:a("data-importer.execution.manual-execution"),children:(0,n.jsx)(rJ,{isDirty:r,isStarting:u,label:a("data-importer.execution.start-import"),onStart:()=>{N()}})}),(0,n.jsx)(O,{noWidthLimit:!0,title:a("data-importer.execution.status.title"),children:w?(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)("p",{className:d.progressLabel,children:a("data-importer.execution.status.current-progress")}),(0,n.jsx)("div",{className:d.progressWrapper,children:(0,n.jsx)(s.Progress,{format:()=>a("data-importer.execution.status.processing",{processedItems:D,totalItems:F}),percent:Math.round(100*T),percentPosition:{align:"start",type:"inner"},size:[-1,32],status:"active",strokeColor:d.colorFill,trailColor:"rgba(0, 0, 0, 0.06)"})}),(0,n.jsx)(s.Button,{loading:g,onClick:()=>{k()},children:a("data-importer.execution.status.cancel")})]}):(0,n.jsx)(s.Text,{children:a(C?"data-importer.execution.status.finished":"data-importer.execution.status.not-running")})})]})},r1=e=>{let{configName:t,isDirty:r,showRuntime:a=!0}=e,{t:i}=(0,l.useTranslation)(),o=[{value:"recurring",label:i("data-importer.execution.schedule-type.recurring")},{value:"job",label:i("data-importer.execution.schedule-type.job")}];return(0,n.jsxs)(n.Fragment,{children:[a&&(0,n.jsx)(r0,{configName:t,isDirty:r}),(0,n.jsxs)(O,{title:i("data-importer.execution.settings.title"),children:[(0,n.jsx)(s.Form.Item,{initialValue:"recurring",label:i("data-importer.execution.schedule-type"),name:["executionConfig","scheduleType"],children:(0,n.jsx)(s.Select,{options:o})}),(0,n.jsx)(s.Form.Conditional,{condition:e=>{var t;return((null==(t=e.executionConfig)?void 0:t.scheduleType)??"recurring")==="recurring"},children:(0,n.jsx)(O,{theme:"fieldset",title:i("data-importer.execution.schedule-type.recurring"),children:(0,n.jsx)(rY,{})})}),(0,n.jsx)(s.Form.Conditional,{condition:e=>{var t;return(null==(t=e.executionConfig)?void 0:t.scheduleType)==="job"},children:(0,n.jsx)(s.Form.Item,{label:i("data-importer.execution.scheduled-at"),name:["executionConfig","scheduledAt"],children:(0,n.jsx)(s.DatePicker,{outputFormat:"YYYY-MM-DD HH:mm",outputType:"dateString",showTime:{format:"HH:mm"}})})})]})]})};var r2=r(969),r3=r(1119);let r5=(0,p.createStyles)(e=>{let{css:t}=e;return{fullWidth:t`
      width: 100%;
    `}}),r9="YYYY-MM-DD HH:mm",r6=e=>{let{children:t}=e,[r,a]=(0,i.useState)("filter"),o=(0,i.useMemo)(()=>({entries:[],buttons:[],sizing:"default",highlights:[],activeTab:r,setEntries:()=>{},setButtons:()=>{},setSizing:()=>{},setHighlights:()=>{},setActiveTab:a,addEntry:()=>{},removeEntry:()=>{},addButton:()=>{},removeButton:()=>{},toggleHighlight:()=>{},openTab:e=>{a(e)},closeTab:()=>{a("")},toggleTab:e=>{a(t=>t===e?"":e)}}),[r]);return(0,n.jsx)(s.SidebarContext.Provider,{value:o,children:t})},r4=[{key:"filter",icon:(0,n.jsx)(s.Icon,{options:{width:"16px",height:"16px"},value:"filter"}),component:(0,n.jsx)(()=>{let{t:e}=(0,l.useTranslation)(),{styles:t}=r5(),[r]=s.Form.useForm(),{dateFrom:a,setDateFrom:i,dateTo:o,setDateTo:d,relatedObjectId:c,setRelatedObjectId:p,message:u,setMessage:m,pid:g,setPid:h,resetFilters:f,updateFilters:x,isLoading:v}=(0,r2.useFilter)();return(0,n.jsx)(s.ContentLayout,{renderToolbar:(0,n.jsxs)(s.Toolbar,{theme:"secondary",children:[(0,n.jsx)(s.IconTextButton,{disabled:v,icon:{value:"close"},onClick:()=>{f(),r.resetFields()},type:"link",children:e("sidebar.clear-all-filters")}),(0,n.jsx)(s.Button,{disabled:v,loading:v,onClick:x,type:"primary",children:e("button.apply")})]}),children:(0,n.jsx)(s.Content,{padded:!0,children:(0,n.jsx)(s.Form,{form:r,layout:"vertical",children:(0,n.jsxs)(s.Space,{className:t.fullWidth,direction:"vertical",size:"none",children:[(0,n.jsx)(s.Title,{children:e("application-logger.sidebar.search-parameter")}),(0,n.jsx)(s.Form.Item,{label:e("application-logger.filter.date-from"),name:"dateFrom",children:(0,n.jsx)(s.DatePicker,{className:"w-full",format:r9,onChange:e=>{i(e)},outputType:"dateString",showTime:{format:"HH:mm"},value:a})}),(0,n.jsx)(s.Form.Item,{label:e("application-logger.filter.date-to"),name:"dateTo",children:(0,n.jsx)(s.DatePicker,{className:"w-full",format:r9,onChange:e=>{d(e)},outputType:"dateString",showTime:{format:"HH:mm"},value:o})}),(0,n.jsx)(s.Form.Item,{label:e("application-logger.filter.priority"),name:"priority",children:(0,n.jsx)(r2.PrioritySelect,{})}),(0,n.jsx)(s.Form.Item,{label:e("application-logger.filter.message"),name:"message",children:(0,n.jsx)(s.Input,{onChange:e=>{let t=e.target.value;m(""===t?null:t)},value:u??void 0})}),(0,n.jsx)(s.Form.Item,{label:e("application-logger.filter.related-object-id"),name:"relatedObjectId",children:(0,n.jsx)(s.Input,{min:"0",onChange:e=>{let t=e.target.value;p(""===t?null:Number.parseInt(t))},step:"1",type:"number",value:c??void 0})}),(0,n.jsx)(s.Form.Item,{label:e("application-logger.filter.pid"),name:"pid",children:(0,n.jsx)(s.Input,{min:"0",onChange:e=>{let t=e.target.value;h(""===t?null:Number.parseInt(t))},step:"1",type:"number",value:g??void 0})})]})})})})},{})}],r7=e=>{let{configName:t}=e,{t:r}=(0,l.useTranslation)(),a=(0,l.useAppDispatch)(),[o,d]=(0,i.useState)(1),[c,p]=(0,i.useState)(20),[u,m]=(0,i.useState)([]),{columnFilters:g,setIsLoading:h}=(0,r2.useFilter)(),f=[...g,{key:"component",type:"equals",filterValue:"DATA-IMPORTER "+t}],{data:v,isFetching:y}=(0,r2.useBundleApplicationLoggerGetCollectionQuery)({body:{filters:{page:o,pageSize:c,columnFilters:f,sortFilter:(0,r2.mapSortingToSortFilter)(u)}}}),b=(null==v?void 0:v.totalItems)??0,j=(0,i.useCallback)(()=>{a(r2.api.util.invalidateTags(eZ.invalidatingTags.APPLICATION_LOGGER()))},[a]),{refreshInterval:S,setRefreshInterval:C}=(e=>{let[t,r]=(0,i.useState)(void 0),a=(0,i.useCallback)(e,[e]);return(0,i.useEffect)(()=>{if((0,r3.isNil)(t))return;let e=setInterval(()=>{a()},1e3*Number.parseInt(t));return()=>{clearInterval(e)}},[t,a]),{refreshInterval:t,setRefreshInterval:r}})(j);(0,i.useEffect)(()=>{h(y)},[y]);let I=(0,i.useRef)(null),w=(0,x.useElementVisible)(I,!0),T=(0,i.useRef)(!0);return(0,i.useEffect)(()=>{if(w){if(T.current){T.current=!1;return}j()}},[w,j]),(0,n.jsx)(r6,{children:(0,n.jsx)("div",{ref:I,style:{height:"100%"},children:(0,n.jsx)(s.ContentLayout,{className:"h-full",renderSidebar:(0,n.jsx)(s.Sidebar,{entries:r4}),renderToolbar:(0,n.jsxs)(s.Toolbar,{justify:"space-between",theme:"secondary",children:[(0,n.jsxs)(s.Flex,{align:"center",gap:8,children:[!(0,r3.isNil)(S)&&(0,n.jsx)("span",{children:r("application-logger.refresh-interval")}),(0,n.jsx)(s.CreatableSelect,{allowClear:!0,inputType:"number",minWidth:200,numberInputProps:{min:1},onChange:C,onCreateOption:e=>({value:e,label:r("application-logger.refresh-interval.seconds",{seconds:e})}),options:[{value:"3",label:r("application-logger.refresh-interval.seconds",{seconds:3})},{value:"5",label:r("application-logger.refresh-interval.seconds",{seconds:5})},{value:"10",label:r("application-logger.refresh-interval.seconds",{seconds:10})},{value:"30",label:r("application-logger.refresh-interval.seconds",{seconds:30})},{value:"60",label:r("application-logger.refresh-interval.seconds",{seconds:60})}],placeholder:r("application-logger.refresh-interval.select"),validate:e=>!Number.isNaN(Number.parseInt(e))&&Number.parseInt(e)>0,value:S})]}),(0,n.jsxs)(s.Flex,{children:[(0,n.jsx)(s.IconButton,{disabled:y,icon:{value:"refresh"},onClick:j}),b>0&&(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(s.Divider,{size:"small",type:"vertical"}),(0,n.jsx)(s.Pagination,{current:o,defaultPageSize:c,onChange:(e,t)=>{d(e),p(t)},showSizeChanger:!0,showTotal:e=>r("pagination.show-total",{total:e}),total:b})]})]})]}),children:(0,n.jsx)(s.Content,{padded:!0,children:(0,n.jsx)(r2.ApplicationLoggerTable,{isLoading:y,items:(null==v?void 0:v.items)??[],onSortingChange:e=>{m(e),d(1)},sorting:u})})})})})},r8=e=>{let{configName:t}=e;return(0,n.jsx)(r2.FilterProvider,{children:(0,n.jsx)(r7,{configName:t})})},ae=()=>void 0,at=e=>{let{configName:t,configuration:r,isWriteable:a,onSave:i,isLoading:o=!1,modificationDate:p,onChange:m=ae,requestId:g,renderToolbar:h,showRuntime:f=!0,activeTab:x,onTabChange:v,activeStep:y,onStepChange:b}=e,{t:S}=(0,l.useTranslation)(),{styles:C}=u(),{form:I,isDirty:w,initialValues:D,handleSave:N,handleValuesChange:k}=(0,d.useDetailView)({configName:t,configData:r,modificationDate:p,isLoading:o,requestId:g,isWriteable:a,transformToForm:T,transformToBackend:j,onSave:i,onChange:m}),$=[{key:"general",label:S("data-importer.tabs.general"),children:(0,n.jsx)(d.GeneralTab,{adapterTypeLabel:S("data-importer.adapter.dataImporterDataObject")})},{key:"data-setup",label:S("data-importer.tabs.data-setup"),fullHeight:!0,children:(0,n.jsx)(rG,{activeStep:y,configName:t,onStepChange:b})},{key:"execution",label:S("data-importer.tabs.execution"),children:(0,n.jsx)(r1,{configName:t,isDirty:w,showRuntime:f})},...f&&(0,c.isBundleActive)("PimcoreApplicationLoggerBundle")?[{key:"import-logs",label:S("data-importer.tabs.import-logs"),fullHeight:!0,children:(0,n.jsx)(r8,{configName:t})}]:[],{key:"permissions",label:S("data-importer.tabs.permissions"),children:(0,n.jsx)(d.PermissionsTab,{isWriteable:a})}].map(e=>({...e,children:!0===e.fullHeight?e.children:(0,n.jsx)(s.Content,{padded:!0,children:e.children})}));return(0,n.jsx)(F,{readOnly:!a,children:(0,n.jsx)(s.ContentLayout,{renderToolbar:null==h?void 0:h({isDirty:w,onSave:N}),children:(0,n.jsx)(s.Content,{loading:o,overflow:{x:"auto",y:"hidden"},children:!o&&(0,n.jsx)("div",{className:C.formWrapper,children:(0,n.jsx)(s.FormKit,{formProps:{form:I,initialValues:D,layout:"vertical",onValuesChange:k,disabled:!a},wrapInPanel:!1,children:(0,n.jsx)(s.Tabs,{activeKey:x,defaultActiveKey:"general",fullHeight:!0,items:$,noTabBarMargin:!0,onChange:v,type:"card"})},g??"")})})})})},ar="mapping",aa=(e,t)=>JSON.stringify(e??null)===JSON.stringify(t??null),an=(e,t)=>("history"===t?e.base:e.current)??{},ai=e=>e.map(e=>e.row),ao=e=>`${String(e.label??"")}|${JSON.stringify(e.dataSourceIndex??null)}`,al=e=>{var t,r;let a=(null==(t=e.dataTarget)?void 0:t.settings)??{},n=a.fieldName;if("string"==typeof n&&""!==n)return`${JSON.stringify(e.dataSourceIndex??null)}|${(null==(r=e.dataTarget)?void 0:r.type)??""}:${n}:${String(a.language??"")}`},as=e=>{if("string"==typeof e.label&&""!==e.label)return e.label;let t=e.dataSourceIndex;return Array.isArray(t)?t.map(String).join(", "):"string"==typeof t?t:"—"},ad=e=>{var t,r,a;let n=null==(r=e.dataTarget)||null==(t=r.settings)?void 0:t.fieldName,i=(null==(a=e.dataTarget)?void 0:a.type)??"";return"string"==typeof n&&""!==n?`${n} (${i})`:i},ac=e=>"string"==typeof e.mappingId&&""!==e.mappingId?e.mappingId:void 0;function ap(e){var t,r;let a=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"review",n=null==e||null==(t=e.slots)?void 0:t[ar];if(null==n)return[];let i=(null==(r=n.proposed)?void 0:r.mappingConfig)??[],o=an(n,a).mappingConfig??[];if(!Array.isArray(i)||!Array.isArray(o))return[];let l=new Map,s=new Map,d=new Map;o.forEach((e,t)=>{let r=ac(e);void 0!==r&&l.set(r,t),s.has(ao(e))||s.set(ao(e),t);let a=al(e);void 0===a||d.has(a)||d.set(a,t)});let c=new Set,p=i.map((e,t)=>{let r,a,n=ac(e),i=(r=ac(e),a=al(e),(void 0!==r?l.get(r):void 0)??s.get(ao(e))??(void 0!==a?d.get(a):void 0)),p=n??`#${t}`,u=ad(e);if(void 0===i||c.has(i))return{key:p,label:as(e),target:u,status:"added",row:e};c.add(i);let m=o[i],g=e=>{let{mappingId:t,...r}=e;return r};return{key:p,label:as(e),target:u,currentTarget:ad(m),status:aa(g(m),g(e))?"unchanged":"changed",row:e}});return o.forEach((e,t)=>{c.has(t)||p.splice(Math.min(t,p.length),0,{key:ac(e)??`current#${t}`,label:as(e),target:ad(e),status:"removed",row:e})}),p}let au=["active","description","group","name"],am=new Set(["general.name","general.type","general.path"]),ag={general:"data-importer.review.section.general",dataSource:"data-importer.review.section.data-source",resolver:"data-importer.review.section.resolver",processing:"data-importer.review.section.processing",execution:"data-importer.review.section.execution",permissions:"data-importer.review.section.permissions"},ah={general:{tab:"general"},dataSource:{tab:"data-setup",step:0},resolver:{tab:"data-setup",step:2},mapping:{tab:"data-setup",step:3},processing:{tab:"data-setup",step:4},execution:{tab:"execution"},permissions:{tab:"permissions"}},af={"loaderConfig.type":"data-importer.data-source.type-label","interpreterConfig.type":"data-importer.file-format.title","resolverConfig.dataObjectClassId":"data-importer.resolver.class","resolverConfig.loadingStrategy.type":"data-importer.resolver.loading-strategy","resolverConfig.createLocationStrategy.type":"data-importer.resolver.create-location-strategy","resolverConfig.locationUpdateStrategy.type":"data-importer.resolver.location-update-strategy","resolverConfig.publishingStrategy.type":"data-importer.resolver.publishing-strategy","processingConfig.executionType":"data-importer.processing.execution-type","processingConfig.idDataIndex":"data-importer.processing.id-data-index","processingConfig.doDeltaCheck":"data-importer.processing.delta-check","processingConfig.doDeltaCheckCheck":"data-importer.processing.delta-check","processingConfig.doArchiveImportFile":"data-importer.processing.archive-import-file","processingConfig.disableVersioning":"data-importer.processing.disable-versioning","processingConfig.cleanup.doCleanup":"data-importer.processing.cleanup.do-cleanup","processingConfig.cleanup.strategy":"data-importer.processing.cleanup.strategy","processingConfig.logging.disableInfoLogs":"data-importer.processing.logging.info.disable-logs","processingConfig.logging.disableInfoFileObjects":"data-importer.processing.logging.info.disable-file-objects","processingConfig.logging.disableErrorLogs":"data-importer.processing.logging.error.disable-logs","processingConfig.logging.disableErrorFileObjects":"data-importer.processing.logging.error.disable-file-objects","executionConfig.scheduleType":"data-importer.execution.schedule-type","executionConfig.cronDefinition":"data-importer.execution.cron-definition","executionConfig.scheduledAt":"data-importer.execution.scheduled-at"},ax={loadingStrategy:"data-importer.resolver.loading-strategy",createLocationStrategy:"data-importer.resolver.create-location-strategy",locationUpdateStrategy:"data-importer.resolver.location-update-strategy",publishingStrategy:"data-importer.resolver.publishing-strategy"},av=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),ay=e=>{let t=e.replace(/([a-z0-9])([A-Z])/g,"$1 $2").replace(/[_-]+/g," ").trim();return t.charAt(0).toUpperCase()+t.slice(1)},ab=(e,t)=>{let r=e(t);return r===t?void 0:r},aj=(0,p.createStyles)(e=>{let{token:t,css:r}=e;return{card:r`
    background: ${t.colorBgContainer};
    border: 1px solid ${t.colorBorderSecondary};
    border-radius: ${t.borderRadiusLG}px;
    box-shadow: ${t.boxShadowTertiary};
  `,head:r`
    display: flex;
    flex-direction: column;
    gap: ${t.marginXXS}px;
    padding: ${t.padding}px ${t.padding}px ${t.paddingSM}px;
    border-bottom: 1px solid ${t.colorSplit};
  `,identity:r`
    display: flex;
    align-items: center;
    gap: ${t.marginXS}px;
  `,name:r`
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-weight: ${t.fontWeightStrong};
    color: ${t.colorText};
  `,pill:r`
    flex: none;
    display: inline-flex;
    align-items: center;
    gap: ${t.marginXXS}px;
    height: ${t.controlHeightSM-2}px;
    padding: 0 ${t.paddingXS}px;
    border-radius: ${t.borderRadiusSM}px;
    background: ${t.colorFillTertiary};
    color: ${t.colorTextSecondary};
    font-size: ${t.fontSizeSM}px;
    line-height: 1;
  `,dot:r`
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: ${t.colorTextQuaternary};
  `,dotOn:r`
    background: ${t.colorSuccess};
  `,description:r`
    font-size: ${t.fontSizeSM}px;
    line-height: ${t.lineHeightSM};
    color: ${t.colorTextSecondary};
    overflow-wrap: anywhere;
  `,spine:r`
    display: grid;
    grid-template-columns: ${t.marginXS}px minmax(0, 1fr);
    column-gap: ${t.marginSM}px;
    padding: ${t.padding}px;
  `,mark:r`
    display: flex;
    flex-direction: column;
    align-items: center;
    padding-top: ${t.marginXXS}px;
  `,node:r`
    flex: none;
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: ${t.colorPrimary};
  `,nodeMuted:r`
    background: ${t.colorBgContainer};
    box-shadow: inset 0 0 0 1px ${t.colorPrimaryBorder};
  `,line:r`
    flex: 1;
    width: 1px;
    margin: ${t.marginXXS}px 0;
    background: ${t.colorPrimaryBorder};
  `,entry:r`
    min-width: 0;
    padding-bottom: ${t.padding}px;
  `,entryLast:r`
    min-width: 0;
  `,role:r`
    font-size: ${t.fontSizeSM-2}px;
    font-weight: ${t.fontWeightStrong};
    letter-spacing: .07em;
    text-transform: uppercase;
    color: ${t.colorTextTertiary};
    line-height: ${t.lineHeightSM};
  `,section:r`
    display: inline-flex;
    align-items: center;
    gap: ${t.marginXXS}px;
    max-width: 100%;
    margin: 0 0 ${t.marginXXS}px;
    padding: 0;
    border: none;
    background: none;
    font: inherit;
    font-size: ${t.fontSizeSM-2}px;
    font-weight: ${t.fontWeightStrong};
    letter-spacing: .07em;
    text-transform: uppercase;
    line-height: ${t.lineHeightSM};
    color: ${t.colorPrimary};
    cursor: pointer;

    &:hover {
      color: ${t.colorPrimaryHover};
    }
  `,value:r`
    font-weight: ${t.fontWeightStrong};
    color: ${t.colorText};
    font-variant-numeric: tabular-nums;
    overflow-wrap: anywhere;
  `,note:r`
    font-size: ${t.fontSizeSM-1}px;
    line-height: ${t.lineHeightSM};
    color: ${t.colorTextTertiary};
    overflow-wrap: anywhere;
  `,field:r`
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: ${t.marginXS}px;
    min-height: ${t.controlHeightSM}px;
  `,fieldLabel:r`
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-weight: ${t.fontWeightStrong};
    color: ${t.colorText};
  `,foot:r`
    display: flex;
    flex-direction: column;
    gap: 2px;
    padding: ${t.paddingSM}px ${t.padding}px;
    border-top: 1px solid ${t.colorSplit};
    font-variant-numeric: tabular-nums;
  `,footLead:r`
    font-size: ${t.fontSizeSM}px;
    line-height: ${t.lineHeightSM};
    color: ${t.colorTextSecondary};

    b {
      color: ${t.colorText};
    }
  `,footGroups:r`
    font-size: ${t.fontSizeSM-1}px;
    line-height: ${t.lineHeightSM};
    color: ${t.colorTextTertiary};
  `}}),aS=e=>{let{name:t,description:r,tags:a,nodes:i,footer:l}=e,{styles:s,cx:d}=aj();return(0,n.jsxs)("div",{className:s.card,children:[(0,n.jsxs)("div",{className:s.head,children:[(0,n.jsxs)("div",{className:s.identity,children:[(0,n.jsx)("span",{className:s.name,children:t}),a]}),void 0!==r&&(0,n.jsx)("div",{className:s.description,children:r})]}),(0,n.jsx)("div",{className:s.spine,children:i.map((e,t)=>(0,n.jsxs)(o().Fragment,{children:[(0,n.jsxs)("div",{className:s.mark,children:[(0,n.jsx)("span",{className:d(s.node,!0===e.muted&&s.nodeMuted)}),t<i.length-1&&(0,n.jsx)("span",{className:s.line})]}),(0,n.jsx)("div",{className:t===i.length-1?s.entryLast:s.entry,children:e.body})]},e.key))}),l]})},aC=e=>{let{active:t,label:r}=e,{styles:a,cx:i}=aj();return(0,n.jsxs)("span",{className:a.pill,children:[(0,n.jsx)("span",{className:i(a.dot,t&&a.dotOn)}),r]})},aI="data-importer.review",aw={width:12,height:12},aT=e=>{var t,r;let{configuration:a,count:i,groups:o,mappings:d,activeSection:c,labelFor:p,onJump:u}=e,{t:m}=(0,l.useTranslation)(),{styles:g}=aj(),h=(e,t,r)=>(0,n.jsxs)(n.Fragment,{children:[(0,n.jsxs)("button",{className:g.section,onClick:()=>{u(e)},title:m(`${aI}.open-section`),type:"button",children:[(0,n.jsx)("span",{children:t}),(0,n.jsx)(s.Icon,{options:aw,value:"arrow-narrow-right"})]}),r]}),f=o.map(e=>({key:e.section,muted:c!==e.section,body:h(e.section,m(e.label),e.changes.map(e=>(0,n.jsxs)("div",{className:g.field,title:e.address,children:[(0,n.jsx)("span",{className:g.fieldLabel,children:p(e)}),(0,n.jsx)(rx,{status:e.status})]},e.address)))})),x=0===d.length?null:{key:"mapping",muted:"mapping"!==c,body:h("mapping",m(`${aI}.mappings`),d.map(e=>(0,n.jsxs)("div",{className:g.field,children:[(0,n.jsx)("span",{className:g.fieldLabel,children:e.label}),"unchanged"!==e.status&&(0,n.jsx)(rx,{status:e.status})]},e.key)))},v=o.findIndex(e=>"resolver"===e.section),y=null===x?f:-1===v?[...f,x]:[...f.slice(0,v+1),x,...f.slice(v+1)];return(0,n.jsx)(aS,{description:"string"==typeof(null==(t=a.general)?void 0:t.description)&&""!==a.general.description?a.general.description:void 0,name:"string"==typeof(null==(r=a.general)?void 0:r.name)?a.general.name:"",nodes:y,tags:(0,n.jsx)(s.Tag,{color:"gold",style:{marginInlineEnd:0},children:m(`${aI}.changes`,{count:i})})})},aD="data-importer.review.outline",aF=" \xb7 ",aN={csv:"import-csv",json:"json",xml:"code",xlsx:"table",sql:"table"},ak=(e,t,r)=>void 0===r||""===r?void 0:ab(e,`${t}.${r}`)??ay(r),a$=e=>e.filter(e=>void 0!==e&&""!==e),aL=e=>"string"==typeof e&&""!==e?e:void 0,aM=[{section:"general",keys:["general"],skip:new Set(["name","type","path","modificationDate","createDate","writeable"])},{section:"dataSource",keys:["loaderConfig","interpreterConfig"]},{section:"resolver",keys:["resolverConfig"]},{section:"processing",keys:["processingConfig"]},{section:"execution",keys:["executionConfig"]},{section:"permissions",keys:["permissions"]}],aP="data-importer.review.outline",aR=e=>{let{brief:t}=e,{t:r}=(0,l.useTranslation)(),{styles:a}=aj(),i=t.stops.map(e=>({key:e.key,body:(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)("div",{className:a.role,children:r(e.role)}),(0,n.jsx)("div",{className:a.value,children:e.value}),void 0!==e.note&&(0,n.jsx)("div",{className:a.note,children:e.note})]})})),d=0===t.groups.length?void 0:(0,n.jsxs)("div",{className:a.foot,children:[(0,n.jsx)("div",{className:a.footLead,children:r(`${aP}.settings`,{count:t.total,sections:t.groups.length}).split("**").map((e,t)=>t%2==1?(0,n.jsx)("b",{children:e},`b${t}`):(0,n.jsx)(o().Fragment,{children:e},`t${t}`))}),(0,n.jsx)("div",{className:a.footGroups,children:t.groups.map(e=>`${r(e.label)} ${e.count}`).join(" \xb7 ")})]});return(0,n.jsx)(aS,{description:t.description,footer:d,name:t.name,nodes:i,tags:(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(s.Tag,{color:"green",style:{marginInlineEnd:0},children:r(`${aP}.new`)}),(0,n.jsx)(aC,{active:t.active,label:r(`${aP}.${t.active?"active":"inactive"}`)})]})})},aA="data-importer.review",aO={merged:"success",discarded:"error",refined:"processing"},aE=e=>{let{state:t,resolvedAt:r,styles:a}=e,{t:i}=(0,l.useTranslation)(),o=null!=r&&Number.isFinite(r)&&r>0?new Date(r).toLocaleString():null;return(0,n.jsxs)("div",{className:a.history,children:[(0,n.jsxs)("div",{className:a.historyState,children:[(0,n.jsx)(s.Tag,{color:aO[t]??"default",children:i(`${aA}.state.${t}`,t)}),null!==o&&(0,n.jsx)("span",{children:i(`${aA}.resolved-at`,{when:o,interpolation:{escapeValue:!1}})})]}),(0,n.jsx)("div",{className:a.note,children:i(`${aA}.history-notice`)})]})},aB=(0,p.createStyles)(e=>{let{token:t,css:r}=e;return{layout:r`
    display: flex;
    align-items: stretch;
    gap: ${t.marginLG}px;
    height: 70vh;
    min-height: 420px;
  `,rail:r`
    width: 272px;
    flex: 0 0 272px;
    min-height: 0;
    display: flex;
    flex-direction: column;
    border-right: 1px solid ${t.colorBorderSecondary};
  `,list:r`
    flex: 1;
    min-height: 0;
    overflow-y: auto;
    overflow-x: hidden;
    padding-right: ${t.padding}px;
    display: flex;
    flex-direction: column;
    gap: ${t.marginMD}px;
  `,summary:r`
    padding: ${t.paddingXS}px 0 ${t.paddingXXS}px;
    font-size: ${t.fontSizeSM}px;
    font-weight: ${t.fontWeightStrong};
    letter-spacing: .08em;
    text-transform: uppercase;
    color: ${t.colorTextTertiary};
  `,history:r`
    display: flex;
    flex-direction: column;
    gap: ${t.marginXXS}px;
    padding: ${t.paddingXS}px ${t.padding}px ${t.paddingSM}px 0;
    border-bottom: 1px solid ${t.colorBorderSecondary};
    margin-bottom: ${t.marginXS}px;
  `,historyState:r`
    display: flex;
    align-items: center;
    gap: ${t.marginXS}px;
    color: ${t.colorTextSecondary};
  `,group:r`
    display: flex;
    flex-direction: column;
  `,headline:r`
    display: inline-flex;
    align-items: center;
    gap: ${t.marginXS}px;
    min-height: ${t.controlHeight}px;
    border: none;
    background: none;
    padding: 0;
    margin: 0;
    font: inherit;
    font-weight: ${t.fontWeightStrong};
    color: ${t.colorText};
    cursor: pointer;

    &:hover {
      color: ${t.colorPrimary};
    }
  `,headlineActive:r`
    display: inline-flex;
    align-items: center;
    gap: ${t.marginXS}px;
    min-height: ${t.controlHeight}px;
    border: none;
    background: none;
    padding: 0;
    margin: 0;
    font: inherit;
    font-weight: ${t.fontWeightStrong};
    color: ${t.colorPrimary};
    cursor: pointer;
  `,items:r`
    list-style: none;
    margin: 0;
    padding: 0;
  `,item:r`
    display: flex;
    align-items: center;
    gap: ${t.marginXS}px;
    min-height: ${t.controlHeightSM}px;
    padding: ${t.paddingXXS}px 0;
    border-bottom: 1px solid ${t.colorSplit};
    color: ${t.colorText};

    &:last-child {
      border-bottom: none;
    }
  `,itemLabel:r`
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  `,brief:r`
    display: flex;
    flex-direction: column;
    gap: ${t.marginSM}px;
    margin-right: ${t.margin}px;
  `,briefFlow:r`
    display: flex;
    flex-direction: column;
    padding: ${t.paddingSM}px;
    border: 1px solid ${t.colorBorderSecondary};
    border-radius: ${t.borderRadiusLG}px;
    background: ${t.colorFillQuaternary};
  `,briefStop:r`
    display: flex;
    align-items: center;
    gap: ${t.marginSM}px;
    min-width: 0;
  `,briefIcon:r`
    flex: 0 0 auto;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    background: ${t.colorBgContainer};
    border: 1px solid ${t.colorBorderSecondary};
    color: ${t.colorPrimary};
  `,briefText:r`
    display: flex;
    flex-direction: column;
    min-width: 0;
    line-height: ${t.lineHeightSM};
  `,briefLabel:r`
    font-weight: ${t.fontWeightStrong};
    color: ${t.colorText};
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  `,briefNote:r`
    font-size: ${t.fontSizeSM}px;
    color: ${t.colorTextSecondary};
  `,briefConnector:r`
    width: 1px;
    height: ${t.marginSM}px;
    margin: ${t.marginXXS}px 0 ${t.marginXXS}px 14px;
    background: ${t.colorBorder};
  `,briefTags:r`
    display: flex;
    flex-wrap: wrap;
    gap: ${t.marginXXS}px;
  `,note:r`
    font-size: ${t.fontSizeSM}px;
    color: ${t.colorTextTertiary};
  `,state:r`
    padding: ${t.paddingLG}px;
    color: ${t.colorTextSecondary};
  `,editor:r`
    flex: 1;
    min-width: 0;
    overflow: auto;
  `}}),az=e=>{let{subjectRef:t,changeSetId:r,contextRef:a,mode:o="review",state:d,resolvedAt:c,onStatsChange:p}=e,{t:u}=(0,l.useTranslation)(),{styles:m}=aB(),{data:g,isLoading:h,error:f}=function(e,t){let[r,a]=(0,i.useState)({isLoading:!0});return(0,i.useEffect)(()=>{if(void 0===e||""===e)return void a({isLoading:!1,error:Error("no change set")});let r=!1,n=void 0!==t&&""!==t?`?contextRef=${encodeURIComponent(t)}`:"";return a({isLoading:!0}),fetch(`/pimcore-studio/api/bundle/change-control/change-sets/${encodeURIComponent(e)}/review${n}`,{headers:{Accept:"application/json"},credentials:"same-origin"}).then(async e=>{if(!e.ok)throw Error(`review request failed: ${e.status}`);return await e.json()}).then(e=>{r||a({data:e,isLoading:!1})}).catch(e=>{r||a({isLoading:!1,error:e})}),()=>{r=!0}},[e,t]),r}(r,a),x="history"===o,{data:v,isLoading:y,isError:b}=tu({name:t}),j=null==v?void 0:v.configuration,S=(0,l.useAppDispatch)(),C=(0,i.useMemo)(()=>(function(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"review";if(null==e)return[];let r=[];for(let[a,n]of Object.entries(e.slots??{})){if(a===ar)continue;let e=an(n,t);for(let[t,i]of Object.entries(n.proposed??{})){if(am.has(t))continue;let n=e[t];aa(n,i)||r.push({address:t,formPath:function(e){let t=e.split(".");return"general"===t[0]?t.length>1&&au.includes(t[1])?t.slice(1).join("."):void 0:e}(t),label:t.split(".").pop()??t,section:a,status:void 0===n?"added":"changed",current:n,proposed:i})}}return r})(g,o),[g,o]),I=(0,i.useMemo)(()=>ap(g,o),[g,o]),w=(0,i.useMemo)(()=>(function(e,t){let r=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"review",a=structuredClone(t??{});if(null==e)return a;for(let[t,n]of Object.entries(e.slots??{})){let i=n.proposed??{};if(t===ar){void 0!==i.mappingConfig&&(a.mappingConfig=ai(ap(e,r)));continue}for(let[e,t]of Object.entries(i))!function(e,t,r){let a=t.split("."),n=e;a.forEach((e,t)=>{if(t===a.length-1){n[e]=r;return}("object"!=typeof n[e]||null===n[e])&&(n[e]={}),n=n[e]})}(a,e,t)}return a})(g,j,o),[g,j,o]),T=(0,i.useMemo)(()=>(function(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"review",r=Object.values((null==e?void 0:e.slots)??{});return 0!==r.length&&r.every(e=>0===Object.keys(an(e,t)).length)})(g,o),[g,o]),D=(0,i.useMemo)(()=>(function(e){let t=new Map;for(let r of e){let e=t.get(r.section)??[];e.push(r),t.set(r.section,e)}let r=[...Object.keys(ag),...t.keys()],a=new Set,n=[];for(let e of r){if(a.has(e))continue;a.add(e);let r=t.get(e);void 0!==r&&0!==r.length&&n.push({section:e,label:ag[e]??e,changes:r})}return n})(C),[C]),F=(0,i.useMemo)(()=>I.filter(e=>"unchanged"!==e.status),[I]),N=(0,i.useMemo)(()=>{var e,t,r;let a,n;return T?(a=[function(e,t){let r=e.loaderConfig,a=e.interpreterConfig,n=a$([ak(t,"data-importer.loader",null==r?void 0:r.type),ak(t,"data-importer.interpreter",null==a?void 0:a.type)]).join(aF);if(""!==n)return{key:"read",icon:aN[(null==a?void 0:a.type)??""]??"import",role:`${aD}.read`,value:n,note:function(e,t){if(void 0===t)return;let r=e=>aL(t[e]);switch(e){case"asset":return r("assetPath");case"http":return r("url");case"sftp":return a$([r("host"),r("remotePath")]).join(":");case"sql":return r("from");case"push":return r("endpoint");default:return}}(null==r?void 0:r.type,null==r?void 0:r.settings)}}(w,u),function(e,t){var r;let a=(null==(r=e.mappingConfig)?void 0:r.length)??0;if(0!==a)return{key:"map",icon:"many-to-many-relation",role:`${aD}.map`,value:t(`${aD}.mappings`,{count:a})}}(w,u),function(e,t){var r,a,n,i;if(void 0===e)return;let o=aL(e.dataObjectClassId),l="dataObject"===e.elementType&&void 0!==o?t(`${aD}.data-objects`,{class:o}):o??ak(t,"data-importer.resolver.element",e.elementType);if(void 0===l||""===l)return;let s=ak(t,"data-importer.resolver.location-strategy",null==(r=e.createLocationStrategy)?void 0:r.type),d=a$([void 0===s?void 0:a$([s,aL(null==(n=e.createLocationStrategy)||null==(a=n.settings)?void 0:a.path)]).join(" "),ak(t,"data-importer.resolver.publishing-strategy",null==(i=e.publishingStrategy)?void 0:i.type)]).join(aF);return{key:"write",icon:"data-object",role:`${aD}.write`,value:l,note:""===d?void 0:d}}(w.resolverConfig,u),function(e,t,r){var a;let n=aL(null==t?void 0:t.cronDefinition)??((null==t?void 0:t.scheduleType)==="job"?aL(t.scheduledAt):void 0)??ab(r,"data-importer.execution.manual-execution")??ay("manualExecution"),i=ak(r,"data-importer.processing.execution-type",null==e?void 0:e.executionType)??n;if(""===i)return;let o=(null==e?void 0:e.doDeltaCheck)===!0||(null==e?void 0:e.doDeltaCheckCheck)===!0,l=(null==e||null==(a=e.cleanup)?void 0:a.doCleanup)===!0?a$([ab(r,"data-importer.processing.cleanup.title")??ay("cleanup"),ak(r,"data-importer.processing.cleanup.strategy",e.cleanup.strategy)]).join(": "):void 0,s=a$([i===n?void 0:n,o?ab(r,"data-importer.processing.delta-check")??ay("deltaCheck"):void 0,l]).join(aF);return{key:"run",icon:"play",role:`${aD}.run`,value:i,note:""===s?void 0:s}}(w.processingConfig,w.executionConfig,u)].filter(e=>void 0!==e),n=aM.map(e=>{let{section:t,keys:r,skip:a}=e;return{section:t,label:ag[t]??t,count:r.reduce((e,t)=>e+function e(t,r){return Array.isArray(t)?t.length:"object"!=typeof t||null===t?+(void 0!==t&&""!==t&&!1!==t):Object.entries(t).filter(e=>{let[t]=e;return(null==r?void 0:r.has(t))!==!0}).reduce((t,r)=>{let[,a]=r;return t+e(a)},0)}(w[t],a),0)}}).filter(e=>e.count>0),{name:aL(null==(e=w.general)?void 0:e.name)??"",active:(null==(t=w.general)?void 0:t.active)===!0,description:aL(null==(r=w.general)?void 0:r.description),stops:a,groups:n,total:n.reduce((e,t)=>e+t.count,0)}):void 0},[T,w,u]);(0,i.useEffect)(()=>{b&&void 0!==g&&S(tp.util.upsertQueryData("bundleDataImporterConfigGet",{name:t},{name:t,configuration:w,userPermissions:{update:!1,delete:!1},modificationDate:0}))},[b,g,w,t,S]);let[k,$]=(0,i.useState)("general"),[L,M]=(0,i.useState)(void 0),P=(0,i.useRef)(null),R=(0,i.useRef)(!1),A=(0,i.useRef)(0),O=(0,i.useCallback)(function(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:0,t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:++A.current;if(t!==A.current)return;let r=P.current,a=null==r?void 0:r.querySelector(".ant-tabs-tabpane-active"),n=(null==a?[]:Array.from(a.querySelectorAll(".pimcore-form-item-annotated, [data-review-mark]"))).find(e=>e.getClientRects().length>0);if(null!==r&&void 0!==n){let e=r.getBoundingClientRect(),t=n.getBoundingClientRect();if(t.top>=e.top&&t.bottom<=e.bottom)return;n.scrollIntoView({block:"center"})}e<24&&window.setTimeout(()=>{O(e+1,t)},250)},[]);(0,i.useEffect)(()=>{if(!R.current)return;R.current=!1;let e=++A.current,t=window.setTimeout(()=>{O(0,e)},250);return()=>{window.clearTimeout(t)}},[k,L,O]),(0,i.useEffect)(()=>{void 0!==g&&(null==p||p(C.length+F.length))},[g,C.length,F.length,p]);let E=(0,i.useMemo)(()=>{let e;return T?{}:{...function(e){let t={};for(let r of e)void 0!==r.formPath&&(t[r.formPath]={status:r.status});return t}(C),...(e={},ap(g,o).forEach((t,r)=>{"unchanged"!==t.status&&(e[["mappingConfig",r].map(String).join(".")]={status:t.status})}),e)}},[T,C,g,o]),B=(0,i.useCallback)(e=>{let t=ah[e];if(void 0!==t){if(t.tab===k&&(t.step??L)===L)return void O();R.current=!0,$(t.tab),M(t.step)}},[k,L,O]),z=(0,i.useCallback)(e=>(function(e,t,r){var a,n;let i=af[e];if(void 0!==i)return ab(r,i)??ay(e.split(".").pop()??e);let o=e.split("."),l=o[o.length-1];if("loaderConfig"===o[0]&&"settings"===o[1]){let e=(null==t||null==(a=t.loaderConfig)?void 0:a.type)??"";return ab(r,`data-importer.loader.${e}.${av(l)}`)??ay(l)}if("interpreterConfig"===o[0]&&"settings"===o[1]){let e=(null==t||null==(n=t.interpreterConfig)?void 0:n.type)??"";return ab(r,`data-importer.interpreter.${e}.${av(l)}`)??ay(l)}if("resolverConfig"===o[0]&&"settings"===o[2]&&void 0!==ax[o[1]]){let e=ab(r,ax[o[1]])??ay(o[1]);return`${e} \xb7 ${ay(l)}`}return ay(l)})(e.address,w,u),[w,u]),H=(0,i.useMemo)(()=>{var e;return null==(e=Object.entries(ah).find(e=>{let[,t]=e;return t.tab===k&&(void 0===t.step||t.step===L)}))?void 0:e[0]},[k,L]);if(null!=f)return(0,n.jsx)("div",{className:m.state,children:u("data-importer.review.load-failed")});if(h||y||void 0===g)return(0,n.jsx)(s.Content,{loading:!0});let q=(0,n.jsx)(tb,{scope:r,children:(0,n.jsx)(at,{activeStep:L,activeTab:k,configName:t,configuration:w,isWriteable:!1,onSave:async()=>({}),onStepChange:M,onTabChange:$,showRuntime:!1})});return(0,n.jsxs)("div",{className:m.layout,children:[(0,n.jsxs)("aside",{className:m.rail,children:[x&&void 0!==d&&(0,n.jsx)(aE,{resolvedAt:c,state:d,styles:m}),void 0!==N?(0,n.jsx)("div",{className:m.list,children:(0,n.jsx)(aR,{brief:N,styles:m})}):(0,n.jsx)("div",{className:m.list,children:(0,n.jsx)(aT,{activeSection:H,configuration:w,count:C.length+F.length,groups:D,labelFor:z,mappings:F,onJump:B,styles:m})})]}),(0,n.jsx)("div",{className:m.editor,ref:P,children:null!==rm?(0,n.jsx)(rm,{annotations:E,children:q}):q})]})};var aH=r(1635);class aq extends P.DynamicTypeAbstract{}aq=(0,aH.Cg)([(0,l.injectable)()],aq);class aW extends P.DynamicTypeRegistryAbstract{getAllTypes(){return this.getDynamicTypes()}}aW=(0,aH.Cg)([(0,l.injectable)()],aW);let aX=(0,p.createStyles)(e=>{let{css:t}=e;return{label:t`
      font-size: 11px;
      white-space: nowrap;
    `,formItem:t`
      margin-bottom: 6px;
    `,formItemSwitch:t`
      margin-bottom: 0 !important;
      .ant-form-item-row {
        row-gap: 0;
      }
    `,formItemLast:t`
      margin-bottom: 0 !important;
      .ant-form-item-row {
        row-gap: 0;
      }
    `,noSettings:t`
      font-size: 11px;
    `}}),aV=e=>{let{children:t}=e,{styles:r}=aX();return(0,n.jsx)(P.FieldWidthProvider,{children:(0,n.jsx)(s.Form,{colon:!1,layout:"vertical",children:t(r)})})},a_=e=>{let{settings:t,onChange:r}=e;return(0,n.jsx)(aV,{children:e=>(0,n.jsx)(s.Form.Item,{className:e.formItemLast,label:(0,n.jsx)("span",{className:e.label,children:"Mode"}),children:(0,n.jsx)(s.Select,{onChange:e=>{r({...t,mode:e})},options:[{value:"both",label:"Both"},{value:"left",label:"Left"},{value:"right",label:"Right"}],value:t.mode??"both"})})})};class aG extends aq{renderSettings(e,t){return(0,n.jsx)(a_,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="trim",this.label="Trim",this.group="dataManipulation"}}aG=(0,aH.Cg)([(0,l.injectable)()],aG);let aU=e=>{let{settings:t,onChange:r}=e;return(0,n.jsx)(aV,{children:e=>(0,n.jsx)(s.Form.Item,{className:e.formItemLast,label:(0,n.jsx)("span",{className:e.label,children:"Glue"}),children:(0,n.jsx)(s.Input,{onChange:e=>{var a;a=e.target.value,r({...t,glue:a})},value:t.glue??" "})})})};class aK extends aq{renderSettings(e,t){return(0,n.jsx)(aU,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="combine",this.label="Combine",this.group="dataManipulation"}}aK=(0,aH.Cg)([(0,l.injectable)()],aK);let aQ=e=>{let{settings:t,onChange:r}=e,a=(e,a)=>{r({...t,[e]:a})};return(0,n.jsx)(aV,{children:e=>(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(s.Form.Item,{className:e.formItem,label:(0,n.jsx)("span",{className:e.label,children:"Mode"}),children:(0,n.jsx)(s.Select,{onChange:e=>{a("mode",e)},options:[{value:"append",label:"Append"},{value:"prepend",label:"Prepend"}],value:t.mode??"append"})}),(0,n.jsx)(s.Form.Item,{className:e.formItem,label:(0,n.jsx)("span",{className:e.label,children:"Text"}),children:(0,n.jsx)(s.Input,{onChange:e=>{a("text",e.target.value)},value:t.text??""})}),(0,n.jsx)(s.Form.Item,{className:e.formItemLast,children:(0,n.jsx)(s.Switch,{checked:t.alwaysAdd??!1,labelRight:"Always add",onChange:e=>{a("alwaysAdd",e)},size:"small"})})]})})};class aY extends aq{renderSettings(e,t){return(0,n.jsx)(aQ,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="staticText",this.label="Static Text",this.group="dataManipulation"}}aY=(0,aH.Cg)([(0,l.injectable)()],aY);let aJ=e=>{let{settings:t,onChange:r}=e,a=(e,a)=>{r({...t,[e]:a})};return(0,n.jsx)(aV,{children:e=>(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(s.Form.Item,{className:e.formItem,label:(0,n.jsx)("span",{className:e.label,children:"Search"}),children:(0,n.jsx)(s.Input,{onChange:e=>{a("search",e.target.value)},value:t.search??""})}),(0,n.jsx)(s.Form.Item,{className:e.formItemLast,label:(0,n.jsx)("span",{className:e.label,children:"Replace"}),children:(0,n.jsx)(s.Input,{onChange:e=>{a("replace",e.target.value)},value:t.replace??""})})]})})};class aZ extends aq{renderSettings(e,t){return(0,n.jsx)(aJ,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="stringReplace",this.label="String Replace",this.group="dataManipulation"}}aZ=(0,aH.Cg)([(0,l.injectable)()],aZ);let a0=e=>{let{settings:t,onChange:r}=e;return(0,n.jsx)(aV,{children:e=>(0,n.jsx)(s.Form.Item,{className:e.formItemLast,label:(0,n.jsx)("span",{className:e.label,children:"Format"}),children:(0,n.jsx)(s.Input,{onChange:e=>{var a;a=e.target.value,r({...t,format:a})},placeholder:"Y-m-d",value:t.format??"Y-m-d"})})})};class a1 extends aq{renderSettings(e,t){return(0,n.jsx)(a0,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="date",this.label="Date",this.group="dataTypes"}}a1=(0,aH.Cg)([(0,l.injectable)()],a1);let a2=e=>{let{settings:t,onChange:r}=e;return(0,n.jsx)(aV,{children:e=>(0,n.jsx)(s.Form.Item,{className:e.formItemLast,children:(0,n.jsx)(s.Switch,{checked:t.returnNullIfEmpty??!1,labelRight:"Return null if empty",onChange:e=>{r({...t,returnNullIfEmpty:e})},size:"small"})})})};class a3 extends aq{renderSettings(e,t){return(0,n.jsx)(a2,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="numeric",this.label="Numeric",this.group="dataTypes"}}a3=(0,aH.Cg)([(0,l.injectable)()],a3);let a5=e=>{let{settings:t,onChange:r}=e,a=(e,a)=>{r({...t,[e]:a})};return(0,n.jsx)(aV,{children:e=>(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(s.Form.Item,{className:e.formItem,label:(0,n.jsx)("span",{className:e.label,children:"Delimiter"}),children:(0,n.jsx)(s.Input,{onChange:e=>{a("delimiter",e.target.value)},value:t.delimiter??""})}),(0,n.jsx)(s.Form.Item,{className:e.formItemLast,children:(0,n.jsx)(s.Switch,{checked:t.keepSubArrays??!1,labelRight:"Keep sub-arrays",onChange:e=>{a("keepSubArrays",e)},size:"small"})})]})})};class a9 extends aq{renderSettings(e,t){return(0,n.jsx)(a5,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="explode",this.label="Explode",this.group="dataManipulation"}}a9=(0,aH.Cg)([(0,l.injectable)()],a9);let a6=e=>{let{settings:t,onChange:r}=e,a=(e,a)=>{r({...t,[e]:a})};return(0,n.jsx)(aV,{children:e=>(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(s.Form.Item,{className:e.formItem,label:(0,n.jsx)("span",{className:e.label,children:"Original"}),children:(0,n.jsx)(s.Input,{onChange:e=>{a("original",e.target.value)},value:t.original??""})}),(0,n.jsx)(s.Form.Item,{className:e.formItemLast,label:(0,n.jsx)("span",{className:e.label,children:"Converted"}),children:(0,n.jsx)(s.Input,{onChange:e=>{a("converted",e.target.value)},value:t.converted??""})})]})})};class a4 extends aq{renderSettings(e,t){return(0,n.jsx)(a6,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="conditionalConversion",this.label="Conditional Conversion",this.group="dataManipulation"}}a4=(0,aH.Cg)([(0,l.injectable)()],a4);let a7=e=>{let{settings:t,onChange:r}=e,a=(e,a)=>{r({...t,[e]:a})};return(0,n.jsx)(aV,{children:e=>(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(s.Form.Item,{className:e.formItem,label:(0,n.jsx)("span",{className:e.label,children:"Attribute"}),children:(0,n.jsx)(s.Input,{onChange:e=>{a("attribute",e.target.value)},value:t.attribute??""})}),(0,n.jsx)(s.Form.Item,{className:e.formItemLast,label:(0,n.jsx)("span",{className:e.label,children:"Forward parameter"}),children:(0,n.jsx)(s.Input,{onChange:e=>{a("forward_parameter",e.target.value)},value:t.forward_parameter??""})})]})})};class a8 extends aq{renderSettings(e,t){return(0,n.jsx)(a7,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="objectField",this.label="Object Field",this.group="dataManipulation"}}a8=(0,aH.Cg)([(0,l.injectable)()],a8);let ne=e=>{let{settings:t,onChange:r}=e;return(0,n.jsx)(aV,{children:e=>(0,n.jsx)(s.Form.Item,{className:e.formItemLast,label:(0,n.jsx)("span",{className:e.label,children:"Load strategy"}),children:(0,n.jsx)(s.Select,{onChange:e=>{r({...t,loadStrategy:e})},options:[{value:"path",label:"By path"},{value:"id",label:"By ID"}],value:t.loadStrategy??"path"})})})};class nt extends aq{renderSettings(e,t){return(0,n.jsx)(ne,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="loadAsset",this.label="Load Asset",this.group="loadImport"}}nt=(0,aH.Cg)([(0,l.injectable)()],nt);let nr=new Set(["id","path","key"]),na=e=>{let{settings:t,onChange:r}=e,a=(e,a)=>{r({...t,[e]:a})},o=(0,c.useSettings)(),l=(0,i.useMemo)(()=>(o.validLanguages??[]).map(e=>({value:e,label:e})),[o.validLanguages]),{data:d,isLoading:p}=(0,tT.useClassDefinitionCollectionQuery)(),u=((null==d?void 0:d.items)??[]).map(e=>({value:e.id,label:e.name})),m=t.loadStrategy??"id",g="attribute"===m,h=t.attributeDataObjectClassId??"",f=t.attributeName,{data:x,isLoading:v}=ts({classId:h,systemRead:!0},{skip:""===h||!g}),y=(0,i.useMemo)(()=>((null==x?void 0:x.attributes)??[]).map(e=>({key:e.key??e.name??"",title:e.title??e.name??e.key??"",localized:!!e.localized})),[x]),b=y.map(e=>({value:e.key,label:e.title})),j=y.find(e=>e.key===f),S=(null==j?void 0:j.localized)??!1,C=g&&null!=f&&""!==f&&!nr.has(f);return(0,n.jsx)(aV,{children:e=>(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(s.Form.Item,{className:e.formItem,label:(0,n.jsx)("span",{className:e.label,children:"Load strategy"}),children:(0,n.jsx)(s.Select,{onChange:e=>{a("loadStrategy",e),"attribute"!==e&&r({...t,loadStrategy:e,attributeDataObjectClassId:void 0,attributeName:void 0,loadUnpublished:void 0})},options:[{value:"id",label:"By ID"},{value:"path",label:"By Path"},{value:"attribute",label:"By Attribute"}],value:m})}),g&&(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(s.Form.Item,{className:e.formItem,label:(0,n.jsx)("span",{className:e.label,children:"Class"}),children:(0,n.jsx)(s.Select,{loadingSkeleton:p,onChange:e=>{r({...t,attributeDataObjectClassId:e,attributeName:void 0})},options:u,value:""!==h?h:void 0})}),(0,n.jsx)(s.Form.Item,{className:e.formItem,label:(0,n.jsx)("span",{className:e.label,children:"Attribute name"}),children:(0,n.jsx)(s.Select,{loadingSkeleton:v,onChange:e=>{a("attributeName",e)},options:b,value:f})}),C&&(0,n.jsx)(s.Form.Item,{className:e.formItemSwitch,children:(0,n.jsx)(s.Switch,{checked:!!t.partialMatch,labelRight:"Accept partial match",onChange:e=>{a("partialMatch",e)},size:"small"})}),S&&(0,n.jsx)(s.Form.Item,{className:e.formItem,label:(0,n.jsx)("span",{className:e.label,children:"Language"}),children:(0,n.jsx)(s.Select,{onChange:e=>{a("attributeLanguage",e)},options:l,value:t.attributeLanguage})}),(0,n.jsx)(s.Form.Item,{className:e.formItemLast,children:(0,n.jsx)(s.Switch,{checked:!!t.loadUnpublished,labelRight:"Load unpublished",onChange:e=>{a("loadUnpublished",e)},size:"small"})})]}),g?null:(0,n.jsx)("div",{style:{height:0}})]})})};class nn extends aq{renderSettings(e,t){return(0,n.jsx)(na,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="loadDataObject",this.label="Load Data Object",this.group="loadImport"}}nn=(0,aH.Cg)([(0,l.injectable)()],nn);let ni=e=>{let{settings:t,onChange:r}=e,a=(e,a)=>{r({...t,[e]:a})},o=t.unitSourceSelect??"id",{data:l,isLoading:d}=td(),c=(0,i.useMemo)(()=>((null==l?void 0:l.unitList)??[]).map(e=>({value:e.unitId??"",label:e.abbreviation??e.unitId??""})),[l]);return(0,n.jsx)(aV,{children:e=>(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(s.Form.Item,{className:e.formItem,label:(0,n.jsx)("span",{className:e.label,children:"Unit source"}),children:(0,n.jsx)(s.Select,{onChange:e=>{r({...t,unitSourceSelect:e,staticUnitSelect:void 0})},options:[{value:"id",label:"By Unit ID"},{value:"abbr",label:"By Abbreviation"},{value:"static",label:"Static"}],value:o})}),"static"===o&&(0,n.jsx)(s.Form.Item,{className:e.formItem,label:(0,n.jsx)("span",{className:e.label,children:"Unit"}),children:(0,n.jsx)(s.Select,{loadingSkeleton:d,onChange:e=>{a("staticUnitSelect",e)},options:c,showSearch:!0,value:t.staticUnitSelect})}),(0,n.jsx)(s.Form.Item,{className:e.formItemLast,children:(0,n.jsx)(s.Switch,{checked:!!t.unitNullIfNoValueCheckbox,labelRight:"Null if no value",onChange:e=>{a("unitNullIfNoValueCheckbox",e)},size:"small"})})]})})};class no extends aq{renderSettings(e,t){return(0,n.jsx)(ni,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="quantityValue",this.label="Quantity Value",this.group="dataTypes"}}no=(0,aH.Cg)([(0,l.injectable)()],no);let nl=e=>{let{settings:t,onChange:r}=e,a=(e,a)=>{r({...t,[e]:a})};return(0,n.jsx)(aV,{children:e=>(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(s.Form.Item,{className:e.formItem,label:(0,n.jsx)("span",{className:e.label,children:"Parent folder"}),children:(0,n.jsx)(s.ManyToOneRelationPath,{allowPathTextInput:!0,allowToClearRelation:!0,allowedAssetTypes:["folder"],assetsAllowed:!0,onChange:e=>{a("parentFolder",e??"/")},value:t.parentFolder??"/"})}),(0,n.jsx)(s.Form.Item,{className:e.formItemSwitch,children:(0,n.jsx)(s.Switch,{checked:!1!==t.useExisting,labelRight:"Use existing",onChange:e=>{a("useExisting",e)},size:"small"})}),(0,n.jsx)(s.Form.Item,{className:e.formItemSwitch,children:(0,n.jsx)(s.Switch,{checked:!0===t.overwriteExisting,labelRight:"Overwrite existing",onChange:e=>{a("overwriteExisting",e)},size:"small"})}),(0,n.jsx)(s.Form.Item,{className:e.formItemLast,label:(0,n.jsx)("span",{className:e.label,children:"Preg match"}),children:(0,n.jsx)(s.Input,{onChange:e=>{a("pregMatch",e.target.value)},value:t.pregMatch??""})})]})})};class ns extends aq{renderSettings(e,t){return(0,n.jsx)(nl,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="importAsset",this.label="Import Asset",this.group="loadImport"}}ns=(0,aH.Cg)([(0,l.injectable)()],ns);let nd=()=>{let{styles:e}=aX();return(0,n.jsx)(s.Text,{className:e.noSettings,type:"secondary",children:"No additional settings"})};function nc(e,t,r){class a extends aq{renderSettings(){return(0,n.jsx)(nd,{})}constructor(...a){super(...a),this.id=e,this.label=t,this.group=r}}return(0,aH.Cg)([(0,l.injectable)()],a)}let np=nc("flattenArray","Flatten Array","dataManipulation"),nu=nc("reduceArrayKeyValuePairs","Reduce Array Key-Value Pairs","dataManipulation"),nm=nc("htmlDecode","HTML Decode","dataManipulation"),ng=nc("boolean","Boolean","dataTypes"),nh=nc("asArray","As Array","dataTypes"),nf=nc("asColor","As Color","dataTypes"),nx=nc("asCountries","As Countries","dataTypes"),nv=nc("gallery","Gallery","dataTypes"),ny=nc("imageAdvanced","Image Advanced","dataTypes"),nb=nc("quantityValueArray","Quantity Value Array","dataTypes"),nj=nc("inputQuantityValue","Input Quantity Value","dataTypes"),nS=nc("inputQuantityValueArray","Input Quantity Value Array","dataTypes"),nC=nc("asGeobounds","As Geobounds","dataTypes"),nI=nc("asGeopoint","As Geopoint","dataTypes"),nw=nc("asGeopolygon","As Geopolygon","dataTypes"),nT=nc("asGeopolyline","As Geopolyline","dataTypes");class nD extends P.DynamicTypeRegistryAbstract{}nD=(0,aH.Cg)([(0,l.injectable)()],nD);class nF extends P.DynamicTypeAbstract{}nF=(0,aH.Cg)([(0,l.injectable)()],nF);let nN=()=>{let{t:e}=(0,l.useTranslation)(),t=t=>({async validator(r){let a=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"";a.length<=1?await Promise.resolve():await Promise.reject(Error(e("data-importer.interpreter.csv.single-char-only",{field:t})))}});return(0,n.jsxs)(s.FormKit.Panel,{children:[(0,n.jsx)(s.Form.Item,{name:["interpreterConfig","settings","skipFirstRow"],valuePropName:"checked",children:(0,n.jsx)(s.Switch,{labelRight:e("data-importer.interpreter.csv.skip-first-row")})}),(0,n.jsx)(s.Form.Item,{name:["interpreterConfig","settings","saveHeaderName"],valuePropName:"checked",children:(0,n.jsx)(s.Switch,{labelRight:e("data-importer.interpreter.csv.save-header-name")})}),(0,n.jsx)(s.Form.Item,{initialValue:",",label:e("data-importer.interpreter.csv.delimiter"),name:["interpreterConfig","settings","delimiter"],required:!0,rules:[{required:!0,message:e("data-importer.interpreter.csv.required",{field:e("data-importer.interpreter.csv.delimiter")})},t(e("data-importer.interpreter.csv.delimiter"))],children:(0,n.jsx)(s.Input,{})}),(0,n.jsx)(s.Form.Item,{initialValue:'"',label:e("data-importer.interpreter.csv.enclosure"),name:["interpreterConfig","settings","enclosure"],required:!0,rules:[{required:!0,message:e("data-importer.interpreter.csv.required",{field:e("data-importer.interpreter.csv.enclosure")})},t(e("data-importer.interpreter.csv.enclosure"))],children:(0,n.jsx)(s.Input,{})}),(0,n.jsx)(s.Form.Item,{initialValue:"\\",label:e("data-importer.interpreter.csv.escape"),name:["interpreterConfig","settings","escape"],required:!0,rules:[t(e("data-importer.interpreter.csv.escape"))],children:(0,n.jsx)(s.Input,{})})]})};class nk extends nF{renderSettings(){return(0,n.jsx)(nN,{})}constructor(...e){super(...e),this.id="csv",this.label="data-importer.interpreter.csv"}}nk=(0,aH.Cg)([(0,l.injectable)()],nk);let n$=()=>{let{t:e}=(0,l.useTranslation)();return(0,n.jsx)(s.Form.Item,{label:e("data-importer.interpreter.json.path"),name:["interpreterConfig","settings","path"],children:(0,n.jsx)(s.Input,{placeholder:"data[*]"})})};class nL extends nF{renderSettings(){return(0,n.jsx)(n$,{})}constructor(...e){super(...e),this.id="json",this.label="data-importer.interpreter.json"}}nL=(0,aH.Cg)([(0,l.injectable)()],nL);let nM=()=>{let{t:e}=(0,l.useTranslation)();return(0,n.jsx)(s.Alert,{message:e("data-importer.interpreter.sql.info"),type:"info"})};class nP extends nF{renderSettings(){return(0,n.jsx)(nM,{})}constructor(...e){super(...e),this.id="sql",this.label="data-importer.interpreter.sql"}}nP=(0,aH.Cg)([(0,l.injectable)()],nP);let nR=(0,p.createStyles)(e=>{let{css:t}=e;return{monoTextArea:t`
      font-family: monospace;
    `}}),nA=()=>{let{t:e}=(0,l.useTranslation)(),{styles:t}=nR();return(0,n.jsxs)(s.FormKit.Panel,{children:[(0,n.jsx)(s.Form.Item,{initialValue:"/root/item",label:e("data-importer.interpreter.xml.xpath"),name:["interpreterConfig","settings","xpath"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.interpreter.xml.xpath")})}],children:(0,n.jsx)(s.Input,{})}),(0,n.jsx)(s.Form.Item,{label:e("data-importer.interpreter.xml.schema"),name:["interpreterConfig","settings","schema"],children:(0,n.jsx)(s.TextArea,{className:t.monoTextArea,rows:6})})]})};class nO extends nF{renderSettings(){return(0,n.jsx)(nA,{})}constructor(...e){super(...e),this.id="xml",this.label="data-importer.interpreter.xml"}}nO=(0,aH.Cg)([(0,l.injectable)()],nO);let nE=()=>{let{t:e}=(0,l.useTranslation)();return(0,n.jsxs)(s.FormKit.Panel,{children:[(0,n.jsx)(s.Form.Item,{name:["interpreterConfig","settings","skipFirstRow"],valuePropName:"checked",children:(0,n.jsx)(s.Switch,{labelRight:e("data-importer.interpreter.xlsx.skip-first-row")})}),(0,n.jsx)(s.Form.Item,{initialValue:"Sheet1",label:e("data-importer.interpreter.xlsx.sheet-name"),name:["interpreterConfig","settings","sheetName"],children:(0,n.jsx)(s.Input,{})})]})};class nB extends nF{renderSettings(){return(0,n.jsx)(nE,{})}constructor(...e){super(...e),this.id="xlsx",this.label="data-importer.interpreter.xlsx"}}nB=(0,aH.Cg)([(0,l.injectable)()],nB);class nz extends P.DynamicTypeRegistryAbstract{}nz=(0,aH.Cg)([(0,l.injectable)()],nz);class nH extends P.DynamicTypeAbstract{}nH=(0,aH.Cg)([(0,l.injectable)()],nH);let nq=()=>{let{t:e}=(0,l.useTranslation)();return(0,n.jsx)(s.Form.Item,{label:e("data-importer.loader.asset.asset-path"),name:["loaderConfig","settings","assetPath"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.asset.asset-path")})}],children:(0,n.jsx)(s.ManyToOneRelationPath,{allowPathTextInput:!0,allowedAssetTypes:["text","document","unknown"],assetsAllowed:!0})})};class nW extends nH{renderSettings(e){return(0,n.jsx)(nq,{})}constructor(...e){super(...e),this.id="asset",this.label="data-importer.loader.asset"}}nW=(0,aH.Cg)([(0,l.injectable)()],nW);let nX=e=>{let{configName:t}=e,{t:r}=(0,l.useTranslation)(),a=s.Form.useFormInstance(),[o,d]=(0,i.useState)(!1),{data:c,isFetching:p,isLoading:u,isError:m,refetch:g}=tg({name:t}),h=`${(0,eZ.getPrefix)()}/bundle/data-importer/config/${t}/upload-import-file`;(0,i.useEffect)(()=>{let e=(null==c?void 0:c.filePath)??"";(a.getFieldValue(["loaderConfig","settings","uploadFilePath"])??"")!==e&&a.setFieldValue(["loaderConfig","settings","uploadFilePath"],e,{triggerChange:!1})},[null==c?void 0:c.filePath,a]);let f=(null==c?void 0:c.exists)===!0,x=u||p&&void 0===c,v=(null==c?void 0:c.message)??r(f?"data-importer.loader.upload.file-uploaded":"data-importer.loader.upload.no-file");return(0,n.jsxs)(s.Space,{direction:"vertical",size:"small",children:[x?(0,n.jsx)(s.Spin,{type:"classic"}):(0,n.jsx)(s.Alert,{message:v,type:m?"error":f?"success":"warning"}),(0,n.jsx)(s.Form.Item,{hidden:!0,name:["loaderConfig","settings","uploadFilePath"],children:(0,n.jsx)(s.Input,{})}),(0,n.jsx)(s.Button,{onClick:()=>{d(!0)},type:"primary",children:r("data-importer.loader.upload.open-upload")}),(0,n.jsx)(s.ImportModal,{action:h,onOpenChange:d,onUploadSuccess:()=>{g()},open:o,title:r("data-importer.loader.upload.modal-title")})]})};class nV extends nH{renderSettings(e){return(0,n.jsx)(nX,{configName:e})}constructor(...e){super(...e),this.id="upload",this.label="data-importer.loader.upload"}}nV=(0,aH.Cg)([(0,l.injectable)()],nV);let n_=()=>{let{t:e}=(0,l.useTranslation)();return(0,n.jsxs)(s.FormKit.Panel,{children:[(0,n.jsx)(s.Form.Item,{label:e("data-importer.loader.http.schema"),name:["loaderConfig","settings","schema"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.http.schema")})}],children:(0,n.jsx)(s.Select,{filterOption:E,options:[{value:"https://",label:"HTTPS"},{value:"http://",label:"HTTP"}],showSearch:!0})}),(0,n.jsx)(s.Form.Item,{label:e("data-importer.loader.http.url"),name:["loaderConfig","settings","url"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.http.url")})}],children:(0,n.jsx)(s.Input,{placeholder:"example.com/data.csv"})})]})};class nG extends nH{renderSettings(e){return(0,n.jsx)(n_,{})}constructor(...e){super(...e),this.id="http",this.label="data-importer.loader.http"}}nG=(0,aH.Cg)([(0,l.injectable)()],nG);let nU=()=>{let{t:e}=(0,l.useTranslation)();return(0,n.jsxs)(s.FormKit.Panel,{children:[(0,n.jsx)(s.Form.Item,{label:e("data-importer.loader.sftp.host"),name:["loaderConfig","settings","host"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.sftp.host")})}],children:(0,n.jsx)(s.Input,{placeholder:"example.com"})}),(0,n.jsx)(s.Form.Item,{initialValue:22,label:e("data-importer.loader.sftp.port"),name:["loaderConfig","settings","port"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.sftp.port")})}],children:(0,n.jsx)(s.InputNumber,{max:65535,min:1})}),(0,n.jsx)(s.Form.Item,{label:e("data-importer.loader.sftp.username"),name:["loaderConfig","settings","username"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.sftp.username")})}],children:(0,n.jsx)(s.Input,{})}),(0,n.jsx)(s.Form.Item,{label:e("data-importer.loader.sftp.password"),name:["loaderConfig","settings","password"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.sftp.password")})}],children:(0,n.jsx)(s.InputPassword,{})}),(0,n.jsx)(s.Form.Item,{label:e("data-importer.loader.sftp.remote-path"),name:["loaderConfig","settings","remotePath"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.sftp.remote-path")})}],children:(0,n.jsx)(s.Input,{placeholder:"/path/to/file.csv"})})]})};class nK extends nH{renderSettings(e){return(0,n.jsx)(nU,{})}constructor(...e){super(...e),this.id="sftp",this.label="data-importer.loader.sftp"}}nK=(0,aH.Cg)([(0,l.injectable)()],nK);let nQ=(0,p.createStyles)(e=>{let{css:t}=e;return{fullWidth:t`
      width: 100%;
    `}}),nY=()=>{let{t:e}=(0,l.useTranslation)(),{styles:t}=nQ(),r=s.Form.useFormInstance(),a=s.Form.useWatch(["name"]),i=`${window.location.protocol}//${window.location.host}/pimcore-datahub-import/${a??""}/push`;return(0,n.jsxs)(s.FormKit.Panel,{children:[(0,n.jsx)(s.Form.Item,{label:e("data-importer.loader.push.api-key"),required:!0,children:(0,n.jsxs)(s.Compact,{className:t.fullWidth,children:[(0,n.jsx)(s.Form.Item,{name:["loaderConfig","settings","apiKey"],noStyle:!0,rules:[{required:!0,message:e("data-importer.loader.push.api-key-required")},{min:16,message:e("data-importer.loader.push.api-key-min-length")}],children:(0,n.jsx)(s.Input,{})}),(0,n.jsx)(s.Button,{htmlType:"button",icon:(0,n.jsx)(s.Icon,{value:"reload"}),onClick:()=>{let e=(0,tq.v4)();r.setFieldValue(["loaderConfig","settings","apiKey"],e,{triggerChange:!0})},type:"default",children:e("data-importer.loader.push.api-key.generate")})]})}),(0,n.jsx)(s.Form.Item,{name:["loaderConfig","settings","ignoreNotEmptyQueue"],valuePropName:"checked",children:(0,n.jsx)(s.Switch,{labelRight:e("data-importer.loader.push.ignore-not-empty-queue")})}),(0,n.jsx)(s.Form.Item,{label:e("data-importer.loader.push.endpoint"),children:(0,n.jsx)(s.Alert,{message:i,type:"info"})})]})};class nJ extends nH{renderSettings(e){return(0,n.jsx)(nY,{})}constructor(...e){super(...e),this.id="push",this.label="data-importer.loader.push"}}nJ=(0,aH.Cg)([(0,l.injectable)()],nJ);let nZ=()=>{let{t:e}=(0,l.useTranslation)(),{data:t,isLoading:r}=tv(),a=(null==t?void 0:t.connections.map(e=>({value:e.value??"",label:e.name??""})))??[];return(0,n.jsxs)(s.FormKit.Panel,{children:[(0,n.jsx)(s.Form.Item,{label:e("data-importer.loader.sql.connection"),name:["loaderConfig","settings","connection"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.sql.connection")})}],children:(0,n.jsx)(s.Select,{filterOption:E,loadingSkeleton:r,options:a,showSearch:!0})}),(0,n.jsx)(s.Form.Item,{label:e("data-importer.loader.sql.select"),name:["loaderConfig","settings","select"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.sql.select")})}],children:(0,n.jsx)(s.TextArea,{placeholder:"a, b, c",rows:4})}),(0,n.jsx)(s.Form.Item,{label:e("data-importer.loader.sql.from"),name:["loaderConfig","settings","from"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.sql.from")})}],children:(0,n.jsx)(s.TextArea,{placeholder:"table_name INNER JOIN other_table ON condition",rows:4})}),(0,n.jsx)(s.Form.Item,{label:e("data-importer.loader.sql.where"),name:["loaderConfig","settings","where"],children:(0,n.jsx)(s.TextArea,{placeholder:"column = 'value'",rows:4})}),(0,n.jsx)(s.Form.Item,{label:e("data-importer.loader.sql.group-by"),name:["loaderConfig","settings","groupBy"],children:(0,n.jsx)(s.TextArea,{placeholder:"column1, column2",rows:4})})]})};class n0 extends nH{renderSettings(e){return(0,n.jsx)(nZ,{})}constructor(...e){super(...e),this.id="sql",this.label="data-importer.loader.sql"}}n0=(0,aH.Cg)([(0,l.injectable)()],n0);class n1 extends P.DynamicTypeRegistryAbstract{}n1=(0,aH.Cg)([(0,l.injectable)()],n1);class n2 extends P.DynamicTypeAbstract{getTypeErrorMessage(e){}getDefaultSettings(e){return e}}n2=(0,aH.Cg)([(0,l.injectable)()],n2);let n3=e=>{let{showOverwriteMode:t=!1,settings:r,onChange:a}=e,{t:o}=(0,l.useTranslation)(),{styles:d}=re();return(0,i.useEffect)(()=>{(null==r?void 0:r.writeIfTargetIsNotEmpty)!==!0&&((null==r?void 0:r.overwriteMode)!==void 0||(null==r?void 0:r.writeIfSourceIsEmpty)===!0)&&a({...r,overwriteMode:void 0,writeIfSourceIsEmpty:!1})},[null==r?void 0:r.writeIfTargetIsNotEmpty,null==r?void 0:r.overwriteMode,null==r?void 0:r.writeIfSourceIsEmpty]),(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)("div",{className:d.overwriteLabel,children:o("data-importer.mapping.advanced-modal.step-target.overwrite")}),(0,n.jsx)(s.Switch,{checked:(null==r?void 0:r.writeIfTargetIsNotEmpty)??!0,labelRight:(0,n.jsx)("span",{className:d.switchLabel,children:o("data-importer.mapping.advanced-modal.write-if-target-not-empty")}),onChange:e=>{a({...r,writeIfTargetIsNotEmpty:e,writeIfSourceIsEmpty:e})},size:"small",tooltip:o("data-importer.mapping.advanced-modal.step-target.write-if-target-not-empty.tooltip")}),t&&(0,n.jsxs)("div",{children:[(0,n.jsx)("div",{className:d.fieldLabel,children:o("data-importer.mapping.advanced-modal.step-target.overwrite-mode")}),(0,n.jsx)("div",{className:d.selectSkeletonWrapper,children:(0,n.jsx)(s.Select,{className:d.selectFull,onChange:e=>{a({...r,overwriteMode:e})},options:[{value:"replace",label:o("data-importer.mapping.advanced-modal.step-target.overwrite-mode.replace")},{value:"merge",label:o("data-importer.mapping.advanced-modal.step-target.overwrite-mode.merge")}],value:null==r?void 0:r.overwriteMode})})]}),(0,n.jsx)(s.Switch,{checked:(null==r?void 0:r.writeIfSourceIsEmpty)??!0,disabled:!((null==r?void 0:r.writeIfTargetIsNotEmpty)??!0),labelRight:(0,n.jsx)("span",{className:d.switchLabel,children:o("data-importer.mapping.advanced-modal.write-if-source-empty")}),onChange:e=>{a({...r,writeIfSourceIsEmpty:e})},size:"small",tooltip:o("data-importer.mapping.advanced-modal.step-target.write-if-source-empty.tooltip")})]})};function n5(e){let{options:t,isLoading:r,value:a,onChange:i}=e,{t:o}=(0,l.useTranslation)(),{styles:d}=re();return(0,n.jsxs)("div",{children:[(0,n.jsx)("div",{className:d.fieldLabel,children:o("data-importer.mapping.advanced-modal.step-target.field-name")}),(0,n.jsx)("div",{className:d.selectSkeletonWrapper,children:(0,n.jsx)(s.Select,{className:d.selectFull,loadingSkeleton:r,onChange:i,options:t,showSearch:!0,value:a})})]})}function n9(e){let{value:t,onChange:r}=e,{t:a}=(0,l.useTranslation)(),{styles:o}=re(),d=function(){let{validLanguages:e}=(0,c.useSettings)();return(0,i.useMemo)(()=>(e??[]).map(e=>({value:e,label:e})),[e])}();return(0,n.jsxs)("div",{children:[(0,n.jsx)("div",{className:o.fieldLabel,children:a("data-importer.mapping.item.data-target.language-placeholder")}),(0,n.jsx)("div",{className:o.selectSkeletonWrapper,children:(0,n.jsx)(s.Select,{className:o.selectFull,onChange:r,options:d,showSearch:!0,value:t})})]})}function n6(e){let{isLocalized:t,settings:r,onChange:a,classFieldOptions:i}=e;return(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(n5,{onChange:e=>{a({...r,fieldName:e})},options:i,value:null==r?void 0:r.fieldName}),t&&(0,n.jsx)(n9,{onChange:e=>{a({...r,language:e})},value:null==r?void 0:r.language}),(0,n.jsx)(n3,{onChange:a,settings:r})]})}class n4 extends n2{supportsType(e){return!0}getDefaultSettings(e){return{...e,overwriteMode:void 0,keyId:void 0,fieldName:null==e?void 0:e.fieldName,language:null==e?void 0:e.language,writeIfTargetIsNotEmpty:(null==e?void 0:e.writeIfTargetIsNotEmpty)??!0,writeIfSourceIsEmpty:(null==e?void 0:e.writeIfSourceIsEmpty)??!0}}renderSettings(e){return(0,n.jsx)(n6,{...e})}constructor(...e){super(...e),this.id="direct",this.label="data-importer.mapping.item.data-target.type.direct"}}let n7=(0,p.createStyles)(e=>{let{css:t,token:r}=e;return{toolbar:t`
      margin-bottom: ${r.paddingSM}px;
    `,search:t`
      width: 320px;
      max-width: 100%;
    `,paginationRow:t`
      margin-top: ${r.paddingSM}px;
    `,footer:t`
      margin-top: ${r.paddingSM}px;
    `}}),n8=(0,eJ.createColumnHelper)(),ie=e=>{let{open:t,classId:r,fieldName:a,transformationResultType:o,onClose:d,onSelect:c}=e,{t:p}=(0,l.useTranslation)(),{styles:u}=n7(),m=(0,l.useAppDispatch)(),[g,h]=(0,i.useState)(""),[f,x]=(0,i.useState)(1),[v,y]=(0,i.useState)(10),[b,j]=(0,i.useState)(null);(0,i.useEffect)(()=>{t&&(h(""),x(1),j(null))},[t]);let{data:S,isFetching:C}=e3({classId:r,fieldName:a,transformationResultType:o,start:(f-1)*v,limit:v,searchfilter:""===g?void 0:g},{skip:!t}),I=(null==S?void 0:S.data)??[],w=(null==S?void 0:S.total)??0,T=(0,i.useMemo)(()=>[n8.accessor("groupName",{header:p("classification-store.column.group")}),n8.accessor("keyName",{header:p("classification-store.column.name")}),n8.accessor("keyDescription",{header:p("classification-store.column.description")})],[p]),D=null===b?{}:{[b]:!0};return(0,n.jsxs)(s.Modal,{footer:null,onCancel:d,open:t,size:"XL",title:p("data-importer.mapping.advanced-modal.step-target.classification-store-key-modal.title"),children:[(0,n.jsxs)(s.Flex,{align:"center",className:u.toolbar,gap:"small",justify:"space-between",children:[(0,n.jsx)(s.Text,{children:p("data-importer.mapping.advanced-modal.step-target.classification-store-key-modal.description")}),(0,n.jsx)(s.SearchInput,{className:u.search,onChange:e=>{h(e.target.value),x(1)},placeholder:p("data-importer.mapping.advanced-modal.step-source.search-placeholder"),value:g,withClear:!0,withPrefix:!0})]}),(0,n.jsx)(s.Grid,{autoWidth:!0,columns:T,data:I,enableMultipleRowSelection:!1,enableRowSelection:!0,isLoading:C,onSelectedRowsChange:e=>{let t="function"==typeof e?e(D):e;j(Object.keys(t).find(e=>t[e])??null)},selectedRows:D,setRowId:(e,t)=>e.id??String(t)}),(0,n.jsx)(s.Flex,{className:u.paginationRow,justify:"flex-end",children:(0,n.jsx)(s.Pagination,{current:f,defaultPageSize:v,onChange:(e,t)=>{x(e),y(t)},showSizeChanger:!0,showTotal:e=>p("pagination.show-total",{total:e}),total:w})}),(0,n.jsxs)(s.Flex,{className:u.footer,gap:"extra-small",justify:"flex-end",children:[(0,n.jsx)(s.Button,{onClick:d,type:"default",children:p("cancel")}),(0,n.jsx)(s.Button,{disabled:null===b,onClick:()=>{if(null!==b){let e=I.find(e=>e.id===b);void 0!==e&&m(tp.util.upsertQueryData("bundleDataImporterClassificationstoreLoadKeyName",{keyId:b},{keyId:b,groupName:e.groupName,keyName:e.keyName})),c(b)}},type:"primary",children:p("common.apply-selection")})]})]})};function it(e){let{classId:t,fieldName:r,transformationResultType:a,keyId:o,onChange:d}=e,{t:c}=(0,l.useTranslation)(),{styles:p}=re(),[u,m]=(0,i.useState)(!1),{data:g}=e2({keyId:o??""},{skip:void 0===o||""===o}),h=(0,i.useMemo)(()=>void 0===o||""===o?c("data-importer.mapping.advanced-modal.step-target.classification-store-key-placeholder"):(null==g?void 0:g.groupName)!==void 0&&(null==g?void 0:g.keyName)!==void 0?c("data-importer.mapping.advanced-modal.step-target.classification-store-key-in-group",{key:g.keyName,group:g.groupName}):o,[o,null==g?void 0:g.groupName,null==g?void 0:g.keyName,c]);return(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(ie,{classId:t,fieldName:r,onClose:()=>{m(!1)},onSelect:e=>{d(e),m(!1)},open:u,transformationResultType:a??""}),(0,n.jsxs)("div",{children:[(0,n.jsx)("div",{className:p.fieldLabel,children:c("data-importer.mapping.advanced-modal.step-target.classification-store-key")}),(0,n.jsxs)(s.Flex,{align:"center",gap:"extra-small",children:[(0,n.jsx)(s.Input,{className:p.classificationStoreKeyInput,readOnly:!0,value:h}),(0,n.jsx)(s.Button,{onClick:()=>{m(!0)},type:"default",children:c("search")})]})]})]})}function ir(e){let{classId:t,settings:r,transformationResultType:a,onChange:n}=e,{data:o,isFetching:l}=e1({classId:t??""},{skip:void 0===t}),s=(0,i.useMemo)(()=>((null==o?void 0:o.attributes)??[]).filter(e=>void 0!==e.key).map(e=>({key:e.key??"",title:e.title??e.name??e.key??"",localized:e.localized??!1})),[null==o?void 0:o.attributes]),d=(0,i.useMemo)(()=>{var e;return(null==(e=s.find(e=>e.key===(null==r?void 0:r.fieldName)))?void 0:e.localized)??!1},[s,null==r?void 0:r.fieldName]),c=(0,i.useMemo)(()=>s.map(e=>({value:e.key,label:e.title})),[s]),p=(0,i.useRef)(a);return(0,i.useEffect)(()=>{p.current!==a&&(p.current=a,(null==r?void 0:r.keyId)!==void 0&&n({...r,keyId:void 0}))},[a,null==r?void 0:r.keyId]),{attributes:s,options:c,isFetching:l,isLocalized:d}}function ia(e){let{classId:t,settings:r,transformationResultType:a,onChange:i}=e,{options:o,isLocalized:l,isFetching:s}=ir(e),d=null==r?void 0:r.fieldName;return(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(n5,{isLoading:s,onChange:e=>{i({...r,fieldName:e})},options:o,value:null==r?void 0:r.fieldName}),void 0!==d&&""!==d&&(0,n.jsx)(it,{classId:t??"",fieldName:d,keyId:null==r?void 0:r.keyId,onChange:e=>{i({...r,keyId:e})},transformationResultType:a}),l&&(0,n.jsx)(n9,{onChange:e=>{i({...r,language:e})},value:null==r?void 0:r.language})]})}class ii extends n2{supportsType(e){return!0}getDefaultSettings(e){return{...e,overwriteMode:void 0,keyId:null==e?void 0:e.keyId,fieldName:void 0,language:void 0}}renderSettings(e){return(0,n.jsx)(ia,{...e})}constructor(...e){super(...e),this.id="classificationstore",this.label="data-importer.mapping.item.data-target.type.classificationstore"}}function io(e){let{settings:t,onChange:r}=e,{options:a,isLocalized:i,isFetching:o}=ir(e);return(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(n5,{isLoading:o,onChange:e=>{r({...t,fieldName:e})},options:a,value:null==t?void 0:t.fieldName}),i&&(0,n.jsx)(n9,{onChange:e=>{r({...t,language:e})},value:null==t?void 0:t.language})]})}class il extends n2{supportsType(e){return["array","quantityValueArray","inputQuantityValueArray","dateArray"].includes(e??"")}getTypeErrorMessage(e){return e("data-importer.mapping.advanced-modal.step-target.type-error.classificationstoreBatch")}getDefaultSettings(e){return{...e,overwriteMode:void 0,keyId:null==e?void 0:e.keyId,fieldName:void 0,language:void 0}}renderSettings(e){return(0,n.jsx)(io,{...e})}constructor(...e){super(...e),this.id="classificationstoreBatch",this.label="data-importer.mapping.item.data-target.type.classificationstoreBatch"}}function is(e){let{isLocalized:t,settings:r,onChange:a,classFieldOptions:i}=e;return(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(n5,{onChange:e=>{a({...r,fieldName:e})},options:i,value:null==r?void 0:r.fieldName}),t&&(0,n.jsx)(n9,{onChange:e=>{a({...r,language:e})},value:null==r?void 0:r.language}),(0,n.jsx)(n3,{onChange:a,settings:r,showOverwriteMode:(null==r?void 0:r.writeIfTargetIsNotEmpty)??!0})]})}class id extends n2{supportsType(e){return["advancedDataObjectArray","dataObjectArray","assetArray","advancedAssetArray"].includes(e??"")}getTypeErrorMessage(e){return e("data-importer.mapping.advanced-modal.step-target.type-error.manyToManyRelation")}getDefaultSettings(e){return{...e,overwriteMode:null==e?void 0:e.overwriteMode,keyId:void 0,fieldName:null==e?void 0:e.fieldName,language:null==e?void 0:e.language,writeIfTargetIsNotEmpty:(null==e?void 0:e.writeIfTargetIsNotEmpty)??!0,writeIfSourceIsEmpty:(null==e?void 0:e.writeIfSourceIsEmpty)??!0}}renderSettings(e){return(0,n.jsx)(is,{...e})}constructor(...e){super(...e),this.id="manyToManyRelation",this.label="data-importer.mapping.item.data-target.type.manyToManyRelation"}}class ic extends P.DynamicTypeRegistryAbstract{getDynamicTypesForGroup(e){return this.getDynamicTypes().filter(t=>t.group===e)}}ic=(0,aH.Cg)([(0,l.injectable)()],ic);class ip extends P.DynamicTypeAbstract{}ip=(0,aH.Cg)([(0,l.injectable)()],ip);class iu extends ip{renderSettings(){return null}constructor(...e){super(...e),this.id="loading.notLoad",this.type="notLoad",this.label="data-importer.resolver.loading-strategy.notLoad",this.group="loading"}}function im(e){let{columnHeaderOptions:t}=e,{t:r}=(0,l.useTranslation)();return(0,n.jsx)(O,{theme:"fieldset",title:r("data-importer.resolver.loading-strategy.id"),children:(0,n.jsx)(s.Form.Item,{label:r("data-importer.resolver.loading-strategy.data-source-index"),name:["resolverConfig","loadingStrategy","settings","dataSourceIndex"],children:(0,n.jsx)(s.Select,{filterOption:E,options:t,placeholder:r("data-importer.resolver.loading-strategy.data-source-index-placeholder"),showSearch:!0})})})}iu=(0,aH.Cg)([(0,l.injectable)()],iu);class ig extends ip{renderSettings(e){return(0,n.jsx)(im,{...e})}constructor(...e){super(...e),this.id="loading.id",this.type="id",this.label="data-importer.resolver.loading-strategy.id",this.group="loading"}}function ih(e){let{columnHeaderOptions:t}=e,{t:r}=(0,l.useTranslation)();return(0,n.jsx)(O,{theme:"fieldset",title:r("data-importer.resolver.loading-strategy.path"),children:(0,n.jsx)(s.Form.Item,{label:r("data-importer.resolver.loading-strategy.data-source-index"),name:["resolverConfig","loadingStrategy","settings","dataSourceIndex"],children:(0,n.jsx)(s.Select,{filterOption:E,options:t,placeholder:r("data-importer.resolver.loading-strategy.data-source-index-placeholder"),showSearch:!0})})})}ig=(0,aH.Cg)([(0,l.injectable)()],ig);class ix extends ip{renderSettings(e){return(0,n.jsx)(ih,{...e})}constructor(...e){super(...e),this.id="loading.path",this.type="path",this.label="data-importer.resolver.loading-strategy.path",this.group="loading"}}function iv(e){let{columnHeaderOptions:t,languageOptions:r=[]}=e,{t:a}=(0,l.useTranslation)(),o=s.Form.useWatch(["resolverConfig","dataObjectClassId"]),d=s.Form.useWatch(["resolverConfig","loadingStrategy","settings","attributeName"]),{data:c,isLoading:p}=ts({classId:o??""},{skip:void 0===o||""===o}),u=(0,i.useMemo)(()=>((null==c?void 0:c.attributes)??[]).map(ri),[c]),m=(0,i.useMemo)(()=>u.map(e=>({value:e.key,label:e.title})),[u]),g=(0,i.useMemo)(()=>{var e;return(null==(e=u.find(e=>e.key===d))?void 0:e.localized)??!1},[u,d]);return(0,n.jsxs)(O,{theme:"fieldset",title:a("data-importer.resolver.loading-strategy.attribute"),children:[(0,n.jsx)(s.Form.Item,{label:a("data-importer.resolver.loading-strategy.data-source-index"),name:["resolverConfig","loadingStrategy","settings","dataSourceIndex"],children:(0,n.jsx)(s.Select,{filterOption:E,options:t,placeholder:a("data-importer.resolver.loading-strategy.data-source-index-placeholder"),showSearch:!0})}),(0,n.jsx)(s.Form.Item,{label:a("data-importer.resolver.loading-strategy.attribute-name"),name:["resolverConfig","loadingStrategy","settings","attributeName"],children:(0,n.jsx)(s.Select,{filterOption:E,loadingSkeleton:p,options:m,placeholder:a("data-importer.resolver.loading-strategy.attribute-name-placeholder"),showSearch:!0})}),g&&(0,n.jsx)(s.Form.Item,{label:a("data-importer.resolver.loading-strategy.language"),name:["resolverConfig","loadingStrategy","settings","language"],children:(0,n.jsx)(s.Select,{filterOption:E,options:r,placeholder:a("data-importer.resolver.loading-strategy.language-placeholder"),showSearch:!0})}),(0,n.jsx)(s.Form.Item,{name:["resolverConfig","loadingStrategy","settings","includeUnpublished"],valuePropName:"checked",children:(0,n.jsx)(s.Switch,{labelRight:a("data-importer.resolver.loading-strategy.include-unpublished"),size:"small"})})]})}ix=(0,aH.Cg)([(0,l.injectable)()],ix);class iy extends ip{renderSettings(e){return(0,n.jsx)(iv,{...e})}constructor(...e){super(...e),this.id="loading.attribute",this.type="attribute",this.label="data-importer.resolver.loading-strategy.attribute",this.group="loading"}}function ib(){let{t:e}=(0,l.useTranslation)();return(0,n.jsx)(O,{theme:"fieldset",title:e("data-importer.resolver.location-strategy.staticPath"),children:(0,n.jsx)(s.Form.Item,{label:e("data-importer.resolver.location-strategy.path"),name:["resolverConfig","createLocationStrategy","settings","path"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.resolver.location-strategy.path")})}],children:(0,n.jsx)(s.ManyToOneRelationPath,{allowPathTextInput:!0,allowedDataObjectTypes:["folder"],dataObjectsAllowed:!0})})})}iy=(0,aH.Cg)([(0,l.injectable)()],iy);class ij extends ip{renderSettings(){return(0,n.jsx)(ib,{})}constructor(...e){super(...e),this.id="createLocation.staticPath",this.type="staticPath",this.label="data-importer.resolver.location-strategy.staticPath",this.group="createLocation"}}function iS(e){let{columnHeaderOptions:t}=e,{t:r}=(0,l.useTranslation)();return(0,n.jsxs)(O,{theme:"fieldset",title:r("data-importer.resolver.location-strategy.findOrCreateFolder"),children:[(0,n.jsx)(s.Form.Item,{label:r("data-importer.resolver.location-strategy.data-source-index"),name:["resolverConfig","createLocationStrategy","settings","dataSourceIndex"],children:(0,n.jsx)(s.Select,{filterOption:E,options:t,placeholder:r("data-importer.resolver.location-strategy.data-source-index-placeholder"),showSearch:!0})}),(0,n.jsx)(s.Form.Item,{label:r("data-importer.resolver.location-strategy.fallback-path"),name:["resolverConfig","createLocationStrategy","settings","fallbackPath"],tooltip:r("data-importer.resolver.location-strategy.fallback-path.tooltip"),children:(0,n.jsx)(s.Input,{placeholder:r("data-importer.resolver.location-strategy.fallback-path-placeholder")})})]})}ij=(0,aH.Cg)([(0,l.injectable)()],ij);class iC extends ip{renderSettings(e){return(0,n.jsx)(iS,{...e})}constructor(...e){super(...e),this.id="createLocation.findOrCreateFolder",this.type="findOrCreateFolder",this.label="data-importer.resolver.location-strategy.findOrCreateFolder",this.group="createLocation"}}function iI(e){var t;let{columnHeaderOptions:r,classOptions:a,isLoadingClasses:o,languageOptions:d=[]}=e,{t:c}=(0,l.useTranslation)(),p=s.Form.useWatch(["resolverConfig","createLocationStrategy","settings","findStrategy"]),u=s.Form.useWatch(["resolverConfig","createLocationStrategy","settings","attributeDataObjectClassId"]),m=s.Form.useWatch(["resolverConfig","createLocationStrategy","settings","attributeName"]),g=[{value:"id",label:c("data-importer.resolver.location-strategy.find-strategy.id")},{value:"path",label:c("data-importer.resolver.location-strategy.find-strategy.path")},{value:"attribute",label:c("data-importer.resolver.location-strategy.find-strategy.attribute")}],{data:h,isLoading:f}=ts({classId:u??"",systemRead:!0},{skip:void 0===u||""===u||"attribute"!==p}),x=(0,i.useMemo)(()=>((null==h?void 0:h.attributes)??[]).map(ri),[h]),v=x.map(e=>({value:e.key,label:e.title})),y=(null==(t=x.find(e=>e.key===m))?void 0:t.localized)??!1;return(0,n.jsxs)(O,{theme:"fieldset",title:c("data-importer.resolver.location-strategy.findParent"),children:[(0,n.jsx)(s.Form.Item,{label:c("data-importer.resolver.location-strategy.find-strategy"),name:["resolverConfig","createLocationStrategy","settings","findStrategy"],children:(0,n.jsx)(s.Select,{filterOption:E,options:g,showSearch:!0})}),"attribute"===p&&(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(s.Form.Item,{label:c("data-importer.resolver.location-strategy.attribute-class"),name:["resolverConfig","createLocationStrategy","settings","attributeDataObjectClassId"],children:(0,n.jsx)(s.Select,{filterOption:E,loadingSkeleton:o,options:a,showSearch:!0})}),(0,n.jsx)(s.Form.Item,{label:c("data-importer.resolver.location-strategy.attribute-name"),name:["resolverConfig","createLocationStrategy","settings","attributeName"],children:(0,n.jsx)(s.Select,{filterOption:E,loadingSkeleton:f,options:v,showSearch:!0})}),y&&(0,n.jsx)(s.Form.Item,{label:c("data-importer.resolver.location-strategy.attribute-language"),name:["resolverConfig","createLocationStrategy","settings","attributeLanguage"],children:(0,n.jsx)(s.Select,{filterOption:E,options:d,showSearch:!0})})]}),(0,n.jsx)(s.Form.Item,{label:c("data-importer.resolver.location-strategy.data-source-index"),name:["resolverConfig","createLocationStrategy","settings","dataSourceIndex"],children:(0,n.jsx)(s.Select,{filterOption:E,options:r,placeholder:c("data-importer.resolver.location-strategy.data-source-index-placeholder"),showSearch:!0})}),(0,n.jsx)(s.Form.Item,{label:c("data-importer.resolver.location-strategy.fallback-path"),name:["resolverConfig","createLocationStrategy","settings","fallbackPath"],tooltip:c("data-importer.resolver.location-strategy.fallback-path.tooltip"),children:(0,n.jsx)(s.Input,{placeholder:c("data-importer.resolver.location-strategy.fallback-path-placeholder")})}),(0,n.jsx)(s.Form.Item,{name:["resolverConfig","createLocationStrategy","settings","asVariant"],valuePropName:"checked",children:(0,n.jsx)(s.Switch,{labelRight:c("data-importer.resolver.location-strategy.as-variant"),size:"small"})})]})}iC=(0,aH.Cg)([(0,l.injectable)()],iC);class iw extends ip{renderSettings(e){return(0,n.jsx)(iI,{...e})}constructor(...e){super(...e),this.id="createLocation.findParent",this.type="findParent",this.label="data-importer.resolver.location-strategy.findParent",this.group="createLocation"}}iw=(0,aH.Cg)([(0,l.injectable)()],iw);class iT extends ip{renderSettings(){return null}constructor(...e){super(...e),this.id="createLocation.doNotCreate",this.type="doNotCreate",this.label="data-importer.resolver.location-strategy.doNotCreate",this.group="createLocation"}}iT=(0,aH.Cg)([(0,l.injectable)()],iT);class iD extends ip{renderSettings(){return null}constructor(...e){super(...e),this.id="updateLocation.noChange",this.type="noChange",this.label="data-importer.resolver.location-strategy.noChange",this.group="updateLocation"}}function iF(){let{t:e}=(0,l.useTranslation)();return(0,n.jsx)(O,{theme:"fieldset",title:e("data-importer.resolver.location-strategy.staticPath"),children:(0,n.jsx)(s.Form.Item,{label:e("data-importer.resolver.location-strategy.path"),name:["resolverConfig","locationUpdateStrategy","settings","path"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.resolver.location-strategy.path")})}],children:(0,n.jsx)(s.ManyToOneRelationPath,{allowPathTextInput:!0,allowedDataObjectTypes:["folder"],dataObjectsAllowed:!0})})})}iD=(0,aH.Cg)([(0,l.injectable)()],iD);class iN extends ip{renderSettings(){return(0,n.jsx)(iF,{})}constructor(...e){super(...e),this.id="updateLocation.staticPath",this.type="staticPath",this.label="data-importer.resolver.location-strategy.staticPath",this.group="updateLocation"}}function ik(e){let{columnHeaderOptions:t}=e,{t:r}=(0,l.useTranslation)();return(0,n.jsxs)(O,{theme:"fieldset",title:r("data-importer.resolver.location-strategy.findOrCreateFolder"),children:[(0,n.jsx)(s.Form.Item,{label:r("data-importer.resolver.location-strategy.data-source-index"),name:["resolverConfig","locationUpdateStrategy","settings","dataSourceIndex"],children:(0,n.jsx)(s.Select,{filterOption:E,options:t,placeholder:r("data-importer.resolver.location-strategy.data-source-index-placeholder"),showSearch:!0})}),(0,n.jsx)(s.Form.Item,{label:r("data-importer.resolver.location-strategy.fallback-path"),name:["resolverConfig","locationUpdateStrategy","settings","fallbackPath"],tooltip:r("data-importer.resolver.location-strategy.fallback-path.tooltip"),children:(0,n.jsx)(s.Input,{placeholder:r("data-importer.resolver.location-strategy.fallback-path-placeholder")})})]})}iN=(0,aH.Cg)([(0,l.injectable)()],iN);class i$ extends ip{renderSettings(e){return(0,n.jsx)(ik,{...e})}constructor(...e){super(...e),this.id="updateLocation.findOrCreateFolder",this.type="findOrCreateFolder",this.label="data-importer.resolver.location-strategy.findOrCreateFolder",this.group="updateLocation"}}function iL(e){var t;let{columnHeaderOptions:r,classOptions:a,languageOptions:o=[]}=e,{t:d}=(0,l.useTranslation)(),c=s.Form.useWatch(["resolverConfig","locationUpdateStrategy","settings","findStrategy"]),p=s.Form.useWatch(["resolverConfig","locationUpdateStrategy","settings","attributeDataObjectClassId"]),u=s.Form.useWatch(["resolverConfig","locationUpdateStrategy","settings","attributeName"]),{data:m}=ts({classId:p??"",systemRead:!0},{skip:void 0===p||""===p||"attribute"!==c}),g=(0,i.useMemo)(()=>((null==m?void 0:m.attributes)??[]).map(ri),[m]),h=g.map(e=>({value:e.key,label:e.title})),f=(null==(t=g.find(e=>e.key===u))?void 0:t.localized)??!1,x=[{value:"id",label:d("data-importer.resolver.location-strategy.find-strategy.id")},{value:"path",label:d("data-importer.resolver.location-strategy.find-strategy.path")},{value:"attribute",label:d("data-importer.resolver.location-strategy.find-strategy.attribute")}];return(0,n.jsxs)(O,{theme:"fieldset",title:d("data-importer.resolver.location-strategy.findParent"),children:[(0,n.jsx)(s.Form.Item,{label:d("data-importer.resolver.location-strategy.find-strategy"),name:["resolverConfig","locationUpdateStrategy","settings","findStrategy"],children:(0,n.jsx)(s.Select,{filterOption:E,options:x,showSearch:!0})}),"attribute"===c&&(0,n.jsxs)(n.Fragment,{children:[(0,n.jsx)(s.Form.Item,{label:d("data-importer.resolver.location-strategy.attribute-class"),name:["resolverConfig","locationUpdateStrategy","settings","attributeDataObjectClassId"],children:(0,n.jsx)(s.Select,{filterOption:E,options:a,showSearch:!0})}),(0,n.jsx)(s.Form.Item,{label:d("data-importer.resolver.location-strategy.attribute-name"),name:["resolverConfig","locationUpdateStrategy","settings","attributeName"],children:(0,n.jsx)(s.Select,{filterOption:E,options:h,showSearch:!0})}),f&&(0,n.jsx)(s.Form.Item,{label:d("data-importer.resolver.location-strategy.attribute-language"),name:["resolverConfig","locationUpdateStrategy","settings","attributeLanguage"],children:(0,n.jsx)(s.Select,{filterOption:E,options:o,showSearch:!0})})]}),(0,n.jsx)(s.Form.Item,{label:d("data-importer.resolver.location-strategy.data-source-index"),name:["resolverConfig","locationUpdateStrategy","settings","dataSourceIndex"],children:(0,n.jsx)(s.Select,{filterOption:E,options:r,placeholder:d("data-importer.resolver.location-strategy.data-source-index-placeholder"),showSearch:!0})}),(0,n.jsx)(s.Form.Item,{label:d("data-importer.resolver.location-strategy.fallback-path"),name:["resolverConfig","locationUpdateStrategy","settings","fallbackPath"],tooltip:d("data-importer.resolver.location-strategy.fallback-path.tooltip"),children:(0,n.jsx)(s.Input,{placeholder:d("data-importer.resolver.location-strategy.fallback-path-placeholder")})}),(0,n.jsx)(s.Form.Item,{name:["resolverConfig","locationUpdateStrategy","settings","asVariant"],valuePropName:"checked",children:(0,n.jsx)(s.Switch,{labelRight:d("data-importer.resolver.location-strategy.as-variant"),size:"small"})})]})}i$=(0,aH.Cg)([(0,l.injectable)()],i$);class iM extends ip{renderSettings(e){return(0,n.jsx)(iL,{...e})}constructor(...e){super(...e),this.id="updateLocation.findParent",this.type="findParent",this.label="data-importer.resolver.location-strategy.findParent",this.group="updateLocation"}}iM=(0,aH.Cg)([(0,l.injectable)()],iM);class iP extends ip{renderSettings(){return null}constructor(...e){super(...e),this.id="publishing.noChangeUnpublishNew",this.type="noChangeUnpublishNew",this.label="data-importer.resolver.publishing-strategy.noChangeUnpublishNew",this.group="publishing"}}iP=(0,aH.Cg)([(0,l.injectable)()],iP);class iR extends ip{renderSettings(){return null}constructor(...e){super(...e),this.id="publishing.noChangePublishNew",this.type="noChangePublishNew",this.label="data-importer.resolver.publishing-strategy.noChangePublishNew",this.group="publishing"}}iR=(0,aH.Cg)([(0,l.injectable)()],iR);class iA extends ip{renderSettings(){return null}constructor(...e){super(...e),this.id="publishing.alwaysPublish",this.type="alwaysPublish",this.label="data-importer.resolver.publishing-strategy.alwaysPublish",this.group="publishing"}}function iO(e){let{columnHeaderOptions:t}=e,{t:r}=(0,l.useTranslation)();return(0,n.jsx)(O,{theme:"fieldset",title:r("data-importer.resolver.publishing-strategy.attributeBased"),children:(0,n.jsx)(s.Form.Item,{label:r("data-importer.resolver.publishing-strategy.data-source-index"),name:["resolverConfig","publishingStrategy","settings","dataSourceIndex"],children:(0,n.jsx)(s.Select,{filterOption:E,options:t,placeholder:r("data-importer.resolver.publishing-strategy.data-source-index-placeholder"),showSearch:!0})})})}iA=(0,aH.Cg)([(0,l.injectable)()],iA);class iE extends ip{renderSettings(e){return(0,n.jsx)(iO,{...e})}constructor(...e){super(...e),this.id="publishing.attributeBased",this.type="attributeBased",this.label="data-importer.resolver.publishing-strategy.attributeBased",this.group="publishing"}}iE=(0,aH.Cg)([(0,l.injectable)()],iE);let iB={onInit:()=>{a.container.get(d.bundleServiceIds["DataHub/DynamicTypes/Adapter/Registry"]).registerDynamicType(a.container.get(B)),a.container.bind(z).to(nD).inSingletonScope(),a.container.bind(H).to(nk).inSingletonScope(),a.container.bind(q).to(nL).inSingletonScope(),a.container.bind(V).to(nO).inSingletonScope(),a.container.bind(X).to(nB).inSingletonScope(),a.container.bind(W).to(nP).inSingletonScope();let e=a.container.get(z);e.registerDynamicType(a.container.get(H)),e.registerDynamicType(a.container.get(q)),e.registerDynamicType(a.container.get(V)),e.registerDynamicType(a.container.get(X)),e.registerDynamicType(a.container.get(W)),a.container.bind(_).to(nz).inSingletonScope(),a.container.bind(G).to(nW).inSingletonScope(),a.container.bind(U).to(nV).inSingletonScope(),a.container.bind(K).to(nG).inSingletonScope(),a.container.bind(Q).to(nK).inSingletonScope(),a.container.bind(Y).to(nJ).inSingletonScope(),a.container.bind(J).to(n0).inSingletonScope();let t=a.container.get(_);t.registerDynamicType(a.container.get(G)),t.registerDynamicType(a.container.get(U)),t.registerDynamicType(a.container.get(K)),t.registerDynamicType(a.container.get(Q)),t.registerDynamicType(a.container.get(Y)),t.registerDynamicType(a.container.get(J)),a.container.bind(Z).to(ic).inSingletonScope(),a.container.bind(ee).to(iu).inSingletonScope(),a.container.bind(et).to(ig).inSingletonScope(),a.container.bind(er).to(ix).inSingletonScope(),a.container.bind(ea).to(iy).inSingletonScope(),a.container.bind(en).to(ij).inSingletonScope(),a.container.bind(ei).to(iC).inSingletonScope(),a.container.bind(eo).to(iw).inSingletonScope(),a.container.bind(el).to(iT).inSingletonScope(),a.container.bind(es).to(iD).inSingletonScope(),a.container.bind(ed).to(iN).inSingletonScope(),a.container.bind(ec).to(i$).inSingletonScope(),a.container.bind(ep).to(iM).inSingletonScope(),a.container.bind(eu).to(iP).inSingletonScope(),a.container.bind(em).to(iR).inSingletonScope(),a.container.bind(eg).to(iA).inSingletonScope(),a.container.bind(eh).to(iE).inSingletonScope();let r=a.container.get(Z);for(let e of[ee,et,er,ea,en,ei,eo,el,es,ed,ec,ep,eu,em,eg,eh])r.registerDynamicType(a.container.get(e));a.container.bind(ef).to(aW).inSingletonScope(),a.container.bind(ex).to(aG).inSingletonScope(),a.container.bind(ev).to(aK).inSingletonScope(),a.container.bind(ey).to(aY).inSingletonScope(),a.container.bind(eb).to(aZ).inSingletonScope(),a.container.bind(ej).to(a1).inSingletonScope(),a.container.bind(eS).to(a3).inSingletonScope(),a.container.bind(eC).to(a9).inSingletonScope(),a.container.bind(eI).to(a4).inSingletonScope(),a.container.bind(ew).to(a8).inSingletonScope(),a.container.bind(eT).to(nt).inSingletonScope(),a.container.bind(eX).to(nn).inSingletonScope(),a.container.bind(eD).to(np).inSingletonScope(),a.container.bind(eF).to(nu).inSingletonScope(),a.container.bind(eN).to(nm).inSingletonScope(),a.container.bind(ek).to(ng).inSingletonScope(),a.container.bind(e$).to(nh).inSingletonScope(),a.container.bind(eL).to(nf).inSingletonScope(),a.container.bind(eM).to(nx).inSingletonScope(),a.container.bind(eP).to(nv).inSingletonScope(),a.container.bind(eR).to(ny).inSingletonScope(),a.container.bind(eA).to(no).inSingletonScope(),a.container.bind(eO).to(nb).inSingletonScope(),a.container.bind(eE).to(nj).inSingletonScope(),a.container.bind(eB).to(nS).inSingletonScope(),a.container.bind(ez).to(nC).inSingletonScope(),a.container.bind(eH).to(nI).inSingletonScope(),a.container.bind(eq).to(nw).inSingletonScope(),a.container.bind(eW).to(nT).inSingletonScope(),a.container.bind(eV).to(ns).inSingletonScope();let n=a.container.get(ef);for(let e of[ex,ev,ey,eb,ej,eS,eC,eI,ew,eT,eD,eF,eN,ek,e$,eL,eM,eP,eR,eA,eO,eE,eB,ez,eH,eq,eW,eX,eV])n.registerDynamicType(a.container.get(e));a.container.bind(e_).to(n1).inSingletonScope(),a.container.bind(eG).to(n4).inSingletonScope(),a.container.bind(eU).to(ii).inSingletonScope(),a.container.bind(eK).to(il).inSingletonScope(),a.container.bind(eQ).to(id).inSingletonScope();let i=a.container.get(e_);i.registerDynamicType(a.container.get(eG)),i.registerDynamicType(a.container.get(eU)),i.registerDynamicType(a.container.get(eK)),i.registerDynamicType(a.container.get(eQ)),setTimeout(()=>{let e;try{e=a.container.get("ChangeControl/Review/SurfaceRegistry")}catch{return}"function"==typeof(null==e?void 0:e.register)&&e.register("data-importer-config",az)},0)}},iz=e=>{let{configName:t,onChange:r,onDelete:a}=e,{data:o,error:l,isLoading:s,isFetching:p,refetch:u,requestId:m}=tu({name:t},{refetchOnMountOrArgChange:!0}),[g,{isLoading:h}]=tm();(0,i.useEffect)(()=>{(0,r3.isNil)(l)||(0,d.trackConfigError)(l)},[l]);let f=s||p,x=(0,i.useMemo)(()=>(null==o?void 0:o.configuration)??{},[null==o?void 0:o.configuration]),v=(null==o?void 0:o.userPermissions)??{},y=(null==x?void 0:x.general)??{},b=!0===v.update&&!1!==y.writeable,j=!0===v.delete&&!1!==y.writeable,S=!1!==y.writeable&&!0!==v.update?"data-hub.config.no-update-permission":"config_not_writeable",C=async(e,r)=>{var a;let n=await g({name:t,bundleDataImporterConfigurationSaveParameters:{configuration:e,modificationDate:r}});if("error"in n)throw new c.ApiError(n.error??{});return{modificationDate:null==(a=n.data)?void 0:a.modificationDate}};return(0,n.jsx)(at,{configName:t,configuration:x,isLoading:f,isWriteable:b,modificationDate:null==o?void 0:o.modificationDate,onChange:r,onSave:C,renderToolbar:e=>{let{isDirty:r,onSave:i}=e;return(0,n.jsx)(d.ConfigToolbar,{canDelete:j,configName:t,isDirty:r,isLoading:f,isSaving:h,isWriteable:b,onDelete:a,onRefresh:u,onSave:i,saveDisabledTooltipKey:S})},requestId:m})};class iH extends d.DynamicTypeDataHubAdapterAbstract{getIcon(){return{type:"name",value:"data-objects-importer",colorToken:"colorCodingPurple3"}}renderDetailView(e){return(0,n.jsx)(iz,{...e})}constructor(...e){super(...e),this.id="dataImporterDataObject"}}iH=(0,aH.Cg)([(0,l.injectable)()],iH),void 0!==(e=r.hmd(e)).hot&&e.hot.accept();let iq={name:"data-importer-plugin",onInit:e=>{let{container:t}=e;t.bind(String(B)).to(iH).inSingletonScope()},onStartup:e=>{let{moduleSystem:t}=e;t.registerModule(iB),console.log("Hello from data importer bundle.")}}}}]);