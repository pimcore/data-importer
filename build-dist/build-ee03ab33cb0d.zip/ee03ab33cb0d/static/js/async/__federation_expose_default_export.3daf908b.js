/*! For license information please see __federation_expose_default_export.3daf908b.js.LICENSE.txt */
"use strict";(self["chunk_pimcore_dataimporter_bundle "]=self["chunk_pimcore_dataimporter_bundle "]||[]).push([["525"],{8778(e,t,a){a.r(t),a.d(t,{DataImporterPlugin:()=>nq});var r=a(2977),i=a(4848),n=a(5446),o=a.n(n),l=a(4781),s=a(2696),d=a(3729),c=a(2703),p=a(8096);let u=(0,p.createStyles)(e=>{let{css:t}=e;return{formWrapper:t`
    display: contents;

    > form {
      display: flex;
      flex-direction: column;
      flex: 1;
      min-height: 0;
    }
  `}});var m=a(4353),g=a.n(m),h=a(445),f=a.n(h),x=a(8267);g().extend(f());let v="DD-MM-YYYY HH:mm";function y(e){return{id:e.id,name:e.name,read:e.read??!1,update:e.update??!1,delete:e.delete??!1}}function b(e){return{id:e.id,name:e.name??"",read:e.read??!1,update:e.update??!1,delete:e.delete??!1}}function j(e,t){var a;let r=S(e.loaderConfig,t.loaderConfig),i=S(e.interpreterConfig,t.interpreterConfig),n=function(e){if((null==e?void 0:e.type)===void 0)return e;let t=(null==e?void 0:e.settings)??{};if("asset"===e.type)return{...e,settings:{assetPath:C(t.assetPath)}};if("upload"===e.type)return{...e,settings:{uploadFilePath:C(t.uploadFilePath)}};if("http"===e.type){let a=C(t.schema),r=C(t.url).replace(/^\s*[a-z][a-z0-9+.-]*:\/\//i,"");return{...e,settings:{schema:a,url:r}}}return"sftp"===e.type?{...e,settings:{host:C(t.host),port:C(t.port),username:C(t.username),password:C(t.password),remotePath:C(t.remotePath)}}:"push"===e.type?{...e,settings:{apiKey:C(t.apiKey),ignoreNotEmptyQueue:I(t.ignoreNotEmptyQueue)}}:"sql"===e.type?{...e,settings:{connection:C(t.connection),select:C(t.select),from:C(t.from),where:C(t.where),groupBy:C(t.groupBy)}}:e}(r),o=function(e){if((null==e?void 0:e.type)===void 0)return e;let t=e.settings??{};return"csv"===e.type?{...e,settings:{skipFirstRow:I(t.skipFirstRow),saveHeaderName:I(t.saveHeaderName),delimiter:C(t.delimiter),enclosure:C(t.enclosure),escape:C(t.escape)}}:"json"===e.type?{...e,settings:{path:C(t.path)}}:"xml"===e.type?{...e,settings:{xpath:C(t.xpath),schema:C(t.schema)}}:"xlsx"===e.type?{...e,settings:{skipFirstRow:I(t.skipFirstRow),sheetName:C(t.sheetName)}}:"sql"===e.type?{...e,settings:{}}:e}(i);return{...t,general:{...t.general,active:e.active,description:e.description,group:e.group},loaderConfig:n,interpreterConfig:o,resolverConfig:e.resolverConfig??t.resolverConfig,mappingConfig:e.mappingConfig??t.mappingConfig,processingConfig:e.processingConfig??t.processingConfig,executionConfig:void 0!==e.executionConfig?{...e.executionConfig,scheduledAt:function(e){if(void 0===e||""===e)return;let t=g()(e);return t.isValid()?t.format(v):e}(e.executionConfig.scheduledAt)}:t.executionConfig,permissions:{role:((null==(a=e.permissions)?void 0:a.roles)??[]).map(y),user:((null==a?void 0:a.users)??[]).map(y)}}}function S(e,t){return void 0===e?t:void 0===e.type||""===e.type?t??e:{...t,...e,settings:{...null==t?void 0:t.settings,...e.settings}}}function C(e){return null==e?"":String(e)}function I(e){return"boolean"==typeof e?e:"1"===e||1===e||"true"===e}function w(e){return Array.isArray(e)?void 0:e}function T(e,t){var a,r,i,n;let o=(function(e){if(Array.isArray(e))return e;if(null===e||"object"!=typeof e)return[];let t=[];for(let a of Object.values(e))for(let e of Array.isArray(a)?a:[a])"object"==typeof e&&null!==e&&t.push(e);return t})(e.mappingConfig).map(e=>({...{...e,mappingId:e.mappingId??(0,x.uuid)()}}));return{active:(null==(a=e.general)?void 0:a.active)??!1,name:t,description:(null==(r=e.general)?void 0:r.description)??"",group:(null==(i=e.general)?void 0:i.group)??"",loaderConfig:w(e.loaderConfig),interpreterConfig:w(e.interpreterConfig),resolverConfig:function(e){let t=w(e);if(void 0!==t)return{...t,loadingStrategy:w(t.loadingStrategy),createLocationStrategy:w(t.createLocationStrategy),locationUpdateStrategy:w(t.locationUpdateStrategy),publishingStrategy:w(t.publishingStrategy)}}(e.resolverConfig),mappingConfig:o,processingConfig:w(e.processingConfig),executionConfig:function(e){let t=w(e);if(void 0!==t)return{...t,scheduledAt:function(e){if(void 0===e||""===e)return;let t=g()(e,v,!0);return t.isValid()?t.format("YYYY-MM-DD HH:mm"):e}("string"==typeof t.scheduledAt&&""!==t.scheduledAt?t.scheduledAt:void 0)}}(e.executionConfig),permissions:{roles:((null==(n=e.permissions)?void 0:n.role)??[]).map(b),users:((null==n?void 0:n.user)??[]).map(b)}}}let D=(0,n.createContext)({readOnly:!1}),N=e=>{let{readOnly:t,children:a}=e,r=(0,n.useMemo)(()=>({readOnly:t}),[t]);return(0,i.jsx)(D.Provider,{value:r,children:a})},F=()=>(0,n.useContext)(D).readOnly;var k=a(1943),$=a.n(k);let L=(0,p.createStyles)(e=>{let{css:t,token:a}=e;return{stepHeading:t`
      color: ${a.colorPrimary};
      font-size: 14px;
      font-weight: ${a.fontWeightStrong};
      height: 32px;
      line-height: 32px;
      margin: 0;
      padding-left: ${a.paddingXXS}px;
    `}}),M=e=>{let{children:t}=e,{styles:a}=L();return(0,i.jsx)("div",{className:a.stepHeading,children:t})};var P=a(3842);let R=(0,p.createStyles)((e,t)=>{let{css:a}=e;return{container:a`
      max-width: ${t}px;
      width: 100%;
    `}}),A=e=>{let{children:t}=e,{medium:a}=(0,P.useFieldWidth)(),{styles:r}=R(a);return(0,i.jsx)("div",{className:r.container,children:t})},O=e=>{let{children:t,theme:a="card-with-highlight",contentPadding:r="extra-small",noWidthLimit:n=!1,...o}=e;if("card-with-highlight"===a){let e=(0,i.jsx)(s.Space,{className:"w-full",direction:"vertical",size:"extra-small",children:t});return(0,i.jsx)(s.FormKit.Panel,{...o,contentPadding:r,theme:a,children:n?e:(0,i.jsx)(A,{children:e})})}let l=(0,i.jsx)(s.FormKit.Panel,{...o,contentPadding:r,theme:a,children:t});return n?l:(0,i.jsx)(A,{children:l})},E=(e,t)=>String((null==t?void 0:t.label)??"").toLowerCase().includes(e.toLowerCase()),B="DataImporter/DynamicTypes/Adapter/DataImporterDataObject",z="DataImporter/DynamicTypes/Interpreter/Registry",H="DataImporter/DynamicTypes/Interpreter/Csv",q="DataImporter/DynamicTypes/Interpreter/Json",W="DataImporter/DynamicTypes/Interpreter/Sql",V="DataImporter/DynamicTypes/Interpreter/Xlsx",X="DataImporter/DynamicTypes/Interpreter/Xml",_="DataImporter/DynamicTypes/Loader/Registry",G="DataImporter/DynamicTypes/Loader/Asset",U="DataImporter/DynamicTypes/Loader/Upload",K="DataImporter/DynamicTypes/Loader/Http",Q="DataImporter/DynamicTypes/Loader/Sftp",Y="DataImporter/DynamicTypes/Loader/Push",J="DataImporter/DynamicTypes/Loader/Sql",Z="DataImporter/DynamicTypes/Resolver/Registry",ee="DataImporter/DynamicTypes/Resolver/Loading/NotLoad",et="DataImporter/DynamicTypes/Resolver/Loading/Id",ea="DataImporter/DynamicTypes/Resolver/Loading/Path",er="DataImporter/DynamicTypes/Resolver/Loading/Attribute",ei="DataImporter/DynamicTypes/Resolver/Location/Creation/StaticPath",en="DataImporter/DynamicTypes/Resolver/Location/Creation/FindOrCreateFolder",eo="DataImporter/DynamicTypes/Resolver/Location/Creation/FindParent",el="DataImporter/DynamicTypes/Resolver/Location/Creation/DoNotCreate",es="DataImporter/DynamicTypes/Resolver/Location/Update/NoChange",ed="DataImporter/DynamicTypes/Resolver/Location/Update/StaticPath",ec="DataImporter/DynamicTypes/Resolver/Location/Update/FindOrCreateFolder",ep="DataImporter/DynamicTypes/Resolver/Location/Update/FindParent",eu="DataImporter/DynamicTypes/Resolver/Publishing/NoChangeUnpublishNew",em="DataImporter/DynamicTypes/Resolver/Publishing/NoChangePublishNew",eg="DataImporter/DynamicTypes/Resolver/Publishing/AlwaysPublish",eh="DataImporter/DynamicTypes/Resolver/Publishing/AttributeBased",ef="DataImporter/DynamicTypes/Transformer/Registry",ex="DataImporter/DynamicTypes/Transformer/Trim",ev="DataImporter/DynamicTypes/Transformer/Combine",ey="DataImporter/DynamicTypes/Transformer/StaticText",eb="DataImporter/DynamicTypes/Transformer/StringReplace",ej="DataImporter/DynamicTypes/Transformer/Date",eS="DataImporter/DynamicTypes/Transformer/Numeric",eC="DataImporter/DynamicTypes/Transformer/Explode",eI="DataImporter/DynamicTypes/Transformer/ConditionalConversion",ew="DataImporter/DynamicTypes/Transformer/ObjectField",eT="DataImporter/DynamicTypes/Transformer/LoadAsset",eD="DataImporter/DynamicTypes/Transformer/FlattenArray",eN="DataImporter/DynamicTypes/Transformer/ReduceArrayKeyValuePairs",eF="DataImporter/DynamicTypes/Transformer/HtmlDecode",ek="DataImporter/DynamicTypes/Transformer/Boolean",e$="DataImporter/DynamicTypes/Transformer/AsArray",eL="DataImporter/DynamicTypes/Transformer/AsColor",eM="DataImporter/DynamicTypes/Transformer/AsCountries",eP="DataImporter/DynamicTypes/Transformer/Gallery",eR="DataImporter/DynamicTypes/Transformer/ImageAdvanced",eA="DataImporter/DynamicTypes/Transformer/QuantityValue",eO="DataImporter/DynamicTypes/Transformer/QuantityValueArray",eE="DataImporter/DynamicTypes/Transformer/InputQuantityValue",eB="DataImporter/DynamicTypes/Transformer/InputQuantityValueArray",ez="DataImporter/DynamicTypes/Transformer/AsGeobounds",eH="DataImporter/DynamicTypes/Transformer/AsGeopoint",eq="DataImporter/DynamicTypes/Transformer/AsGeopolygon",eW="DataImporter/DynamicTypes/Transformer/AsGeopolyline",eV="DataImporter/DynamicTypes/Transformer/LoadDataObject",eX="DataImporter/DynamicTypes/Transformer/ImportAsset",e_="DataImporter/DynamicTypes/DataTarget/Registry",eG="DataImporter/DynamicTypes/DataTarget/Direct",eU="DataImporter/DynamicTypes/DataTarget/Classificationstore",eK="DataImporter/DynamicTypes/DataTarget/ClassificationStoreBatch",eQ="DataImporter/DynamicTypes/DataTarget/ManyToManyRelation",eY=e=>{let{configName:t}=e,{t:a}=(0,l.useTranslation)(),o=(0,n.useMemo)(()=>r.container.get(_),[]),d=(0,n.useMemo)(()=>r.container.get(z),[]),c=(0,n.useMemo)(()=>o.getDynamicTypes(),[o]),p=(0,n.useMemo)(()=>d.getDynamicTypes(),[d]),u=(0,n.useMemo)(()=>c.map(e=>{let{id:t,label:r}=e;return{value:t,label:a(r)}}),[c,a]),m=(0,n.useMemo)(()=>p.map(e=>{let{id:t,label:r}=e;return{value:t,label:a(r)}}),[p,a]);return(0,i.jsxs)(P.FieldWidthProvider,{fieldWidthValues:{medium:900},children:[(0,i.jsx)(M,{children:a("data-importer.data-source.title")}),(0,i.jsxs)(O,{children:[(0,i.jsx)(s.Form.Item,{label:a("data-importer.data-source.type-label"),name:["loaderConfig","type"],required:!0,children:(0,i.jsx)(s.Select,{filterOption:E,options:u,showSearch:!0})}),c.map(e=>(0,i.jsx)(s.Form.Conditional,{condition:t=>{var a;return(null==(a=t.loaderConfig)?void 0:a.type)===e.id},children:(0,i.jsx)(O,{theme:"fieldset",title:a(e.label),children:e.renderSettings(t)})},e.id))]}),(0,i.jsxs)(O,{title:a("data-importer.file-format.title"),children:[(0,i.jsx)(s.Form.Item,{label:a("data-importer.file-format.title"),name:["interpreterConfig","type"],required:!0,children:(0,i.jsx)(s.Select,{filterOption:E,options:m,showSearch:!0})}),p.map(e=>(0,i.jsx)(s.Form.Conditional,{condition:t=>{var a;return(null==(a=t.interpreterConfig)?void 0:a.type)===e.id},children:(0,i.jsx)(O,{border:!0,theme:"fieldset",title:a(e.label),children:e.renderSettings()})},e.id))]})]})};var eJ=a(7984),eZ=a(1436);let e0=eZ.api.enhanceEndpoints({addTagTypes:["Bundle Data Importer"]}).injectEndpoints({endpoints:e=>({bundleDataImporterClassificationstoreLoadAttributes:e.query({query:e=>({url:"/pimcore-studio/api/bundle/data-importer/classificationstore/attributes",params:{classId:e.classId}}),providesTags:["Bundle Data Importer"]}),bundleDataImporterClassificationstoreLoadKeyName:e.query({query:e=>({url:"/pimcore-studio/api/bundle/data-importer/classificationstore/key-name",params:{keyId:e.keyId}}),providesTags:["Bundle Data Importer"]}),bundleDataImporterClassificationstoreLoadKeys:e.query({query:e=>({url:"/pimcore-studio/api/bundle/data-importer/classificationstore/keys",params:{classId:e.classId,fieldName:e.fieldName,transformationResultType:e.transformationResultType,sort:e.sort,start:e.start,limit:e.limit,searchfilter:e.searchfilter,filter:e.filter}}),providesTags:["Bundle Data Importer"]}),bundleDataImporterConfigCalculateTransformationResultType:e.query({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/transformation-result-type`,method:"POST",body:e.bundleDataImporterCalculateTransformationResultTypeParameters}),providesTags:["Bundle Data Importer"]}),bundleDataImporterConfigCancelExecution:e.mutation({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/cancel-execution`,method:"PUT"}),invalidatesTags:["Bundle Data Importer"]}),bundleDataImporterConfigCheckImportProgress:e.query({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/check-import-progress`}),providesTags:["Bundle Data Importer"]}),bundleDataImporterConfigCopyPreview:e.mutation({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/copy-preview`,method:"POST",body:e.bundleDataImporterCopyPreviewParameters}),invalidatesTags:["Bundle Data Importer"]}),bundleDataImporterConfigGet:e.query({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}`}),providesTags:["Bundle Data Importer"]}),bundleDataImporterConfigSave:e.mutation({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}`,method:"PUT",body:e.bundleDataImporterConfigurationSaveParameters}),invalidatesTags:["Bundle Data Importer"]}),bundleDataImporterConfigHasImportFileUploaded:e.query({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/has-import-file-uploaded`}),providesTags:["Bundle Data Importer"]}),bundleDataImporterConfigLoadColumnHeaders:e.query({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/column-headers`,method:"POST",body:e.bundleDataImporterCopyPreviewParameters}),providesTags:["Bundle Data Importer"]}),bundleDataImporterConfigLoadPreview:e.query({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/load-preview`,method:"POST",body:e.bundleDataImporterLoadPreviewParameters}),providesTags:["Bundle Data Importer"]}),bundleDataImporterConfigLoadTransformationResult:e.query({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/transformation-result`,method:"POST",body:e.bundleDataImporterLoadPreviewParameters}),providesTags:["Bundle Data Importer"]}),bundleDataImporterConfigStartImport:e.mutation({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/start-import`,method:"PUT"}),invalidatesTags:["Bundle Data Importer"]}),bundleDataImporterConfigUploadImportFile:e.mutation({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/upload-import-file`,method:"POST",body:e.body}),invalidatesTags:["Bundle Data Importer"]}),bundleDataImporterConfigUploadPreview:e.mutation({query:e=>({url:`/pimcore-studio/api/bundle/data-importer/config/${e.name}/upload-preview`,method:"POST",body:e.body}),invalidatesTags:["Bundle Data Importer"]}),bundleDataImporterConnectionList:e.query({query:()=>({url:"/pimcore-studio/api/bundle/data-importer/connection/list"}),providesTags:["Bundle Data Importer"]}),bundleDataImporterDataTypeLoadClassAttributes:e.query({query:e=>({url:"/pimcore-studio/api/bundle/data-importer/data-type/class-attributes",params:{classId:e.classId,loadAdvancedRelations:e.loadAdvancedRelations,systemRead:e.systemRead,systemWrite:e.systemWrite,transformationResultType:e.transformationResultType}}),providesTags:["Bundle Data Importer"]}),bundleDataImporterDataTypeLoadUnitData:e.query({query:()=>({url:"/pimcore-studio/api/bundle/data-importer/data-type/unit-data"}),providesTags:["Bundle Data Importer"]}),bundleDataImporterUtilityCheckCrontab:e.query({query:e=>({url:"/pimcore-studio/api/bundle/data-importer/utility/check-crontab",params:{cronExpression:e.cronExpression}}),providesTags:["Bundle Data Importer"]})}),overrideExisting:!1}),{useBundleDataImporterClassificationstoreLoadAttributesQuery:e1,useBundleDataImporterClassificationstoreLoadKeyNameQuery:e2,useBundleDataImporterClassificationstoreLoadKeysQuery:e3,useBundleDataImporterConfigCalculateTransformationResultTypeQuery:e5,useBundleDataImporterConfigCancelExecutionMutation:e9,useBundleDataImporterConfigCheckImportProgressQuery:e6,useBundleDataImporterConfigCopyPreviewMutation:e4,useBundleDataImporterConfigGetQuery:e8,useBundleDataImporterConfigSaveMutation:e7,useBundleDataImporterConfigHasImportFileUploadedQuery:te,useBundleDataImporterConfigLoadColumnHeadersQuery:tt,useBundleDataImporterConfigLoadPreviewQuery:ta,useBundleDataImporterConfigLoadTransformationResultQuery:tr,useBundleDataImporterConfigStartImportMutation:ti,useBundleDataImporterConfigUploadImportFileMutation:tn,useBundleDataImporterConfigUploadPreviewMutation:to,useBundleDataImporterConnectionListQuery:tl,useBundleDataImporterDataTypeLoadClassAttributesQuery:ts,useBundleDataImporterDataTypeLoadUnitDataQuery:td,useBundleDataImporterUtilityCheckCrontabQuery:tc}=e0,tp=e0.enhanceEndpoints({addTagTypes:["DataHubConfigs"],endpoints:{bundleDataImporterClassificationstoreLoadAttributes:{providesTags:[]},bundleDataImporterClassificationstoreLoadKeyName:{providesTags:[]},bundleDataImporterClassificationstoreLoadKeys:{providesTags:[]},bundleDataImporterConfigCancelExecution:{invalidatesTags:[]},bundleDataImporterConfigCheckImportProgress:{providesTags:[]},bundleDataImporterConfigCalculateTransformationResultType:{providesTags:[]},bundleDataImporterConfigCopyPreview:{invalidatesTags:[]},bundleDataImporterConfigLoadColumnHeaders:{providesTags:[]},bundleDataImporterConfigLoadPreview:{providesTags:[]},bundleDataImporterConfigLoadTransformationResult:{providesTags:[]},bundleDataImporterConfigGet:{providesTags:[]},bundleDataImporterConfigSave:{invalidatesTags:["DataHubConfigs"]},bundleDataImporterConfigHasImportFileUploaded:{providesTags:[]},bundleDataImporterConfigUploadImportFile:{invalidatesTags:[]},bundleDataImporterConfigUploadPreview:{invalidatesTags:[]},bundleDataImporterConfigStartImport:{invalidatesTags:[]},bundleDataImporterConnectionList:{providesTags:[]},bundleDataImporterDataTypeLoadClassAttributes:{providesTags:[]},bundleDataImporterDataTypeLoadUnitData:{providesTags:[]},bundleDataImporterUtilityCheckCrontab:{providesTags:[]}}}),{useBundleDataImporterConfigGetQuery:tu,useBundleDataImporterConfigSaveMutation:tm,useBundleDataImporterConfigHasImportFileUploadedQuery:tg,useBundleDataImporterConfigCheckImportProgressQuery:th,useBundleDataImporterConfigStartImportMutation:tf,useBundleDataImporterConfigCancelExecutionMutation:tx,useBundleDataImporterConnectionListQuery:tv}=tp,ty=(0,n.createContext)(void 0),tb=e=>{let{scope:t,children:a}=e,r=(0,n.useMemo)(()=>t,[t]);return(0,i.jsx)(ty.Provider,{value:r,children:a})},tj=()=>(0,n.useContext)(ty);function tS(e){let{configName:t,enabled:a,getCurrentConfig:r,forceRefreshToken:i}=e,o=tj(),[l,s]=(0,n.useState)(void 0),[d,c]=(0,n.useState)(0),[p,u]=(0,n.useState)(!1),{data:m,isLoading:g,isFetching:h,isError:f,error:x,refetch:v}=ta(l,{skip:!a||void 0===l,refetchOnMountOrArgChange:!1}),y=(0,n.useCallback)((e,a)=>{let i=null==r?void 0:r();c(e),s({name:t,bundleDataImporterLoadPreviewParameters:{recordNumber:e,...void 0!==i&&{currentConfig:i},...void 0!==o&&{previewScope:o}}}),(null==a?void 0:a.forceRefetch)===!0&&u(!0)},[t,r,o]);(0,n.useEffect)(()=>{a&&void 0===l&&y(0)},[a,l,y]),(0,n.useEffect)(()=>{p&&void 0!==l&&(u(!1),v())},[p,l,v]);let b=(0,n.useRef)(!0);(0,n.useEffect)(()=>{if(void 0!==i&&0!==i){if(b.current){b.current=!1;return}a&&void 0!==l&&u(!0)}},[i,a,l]);let j=(null==m?void 0:m.previewRecordIndex)??d;return{dataPreview:(0,n.useMemo)(()=>(null==m?void 0:m.dataPreview)??[],[m]),currentRecordIndex:j,isLoading:g,isFetching:h,isError:f,error:x,load:y}}var tC=a(807);let tI=(0,eJ.createColumnHelper)(),tw=e=>{let{configName:t,isActive:a,onPreviewDataChange:r}=e,{t:o}=(0,l.useTranslation)(),d=s.Form.useFormInstance(),[p,u]=(0,n.useState)(0),[m,g]=(0,n.useState)(""),[h,f]=(0,n.useState)(!1),{data:x}=tu({name:t}),v=(0,n.useCallback)(()=>j(d.getFieldsValue(!0),(null==x?void 0:x.configuration)??{}),[d,x]),[y,{isLoading:b,error:S}]=e4(),C=tj(),I=s.Form.useWatch(["interpreterConfig","type"]),{dataPreview:w,currentRecordIndex:T,isLoading:D,isFetching:N,isError:F,error:k,load:$}=tS({configName:t,enabled:a,getCurrentConfig:v});(0,n.useEffect)(()=>{u(T)},[T]),(0,n.useEffect)(()=>{null!=k&&("object"!=typeof k||null===k||404!==k.status)&&(0,c.trackError)(new c.ApiError(k))},[k]),(0,n.useEffect)(()=>{void 0!==S&&(0,c.trackError)(new c.ApiError(S))},[S]);let L=async()=>{"error"in await y({name:t,bundleDataImporterCopyPreviewParameters:{currentConfig:v(),previewScope:C}})||($(0,{forceRefetch:!0}),null==r||r())},P=[{key:"upload",label:o("data-importer.preview-import.upload-file"),onClick:()=>{f(!0)}},{key:"copy",label:o("data-importer.preview-import.copy-from-source"),onClick:()=>{L()}}],R=(0,n.useMemo)(()=>[tI.accessor("label",{header:o("data-importer.preview-import.column.label"),size:300}),tI.accessor("data",{header:o("data-importer.preview-import.column.data"),meta:{autoWidth:!0}})],[o]),A=(0,n.useMemo)(()=>F?[]:w.map(e=>({...e,data:"string"==typeof e.data?e.data:JSON.stringify(e.data)})),[w,F]),O=(0,n.useMemo)(()=>{if(""===m)return A;let e=m.toLowerCase();return A.filter(t=>(t.label??"").toLowerCase().includes(e))},[A,m]),E=D||N||b;return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(s.Box,{margin:{bottom:"extra-small"},children:(0,i.jsxs)(s.Flex,{align:"center",gap:"extra-small",justify:"space-between",children:[(0,i.jsxs)(s.Flex,{align:"center",gap:"extra-small",children:[(0,i.jsx)(M,{children:o("data-importer.preview-import.title")}),(0,i.jsxs)(tC.Ay,{componentDisabled:!1,children:[(0,i.jsx)(s.Dropdown,{menu:{items:P},children:(0,i.jsx)(s.DropdownButton,{disabled:E,type:"default",children:o("data-importer.preview-import.choose-preview-data")})}),(0,i.jsx)(s.IconButton,{disabled:E||p<=0,icon:{value:"chevron-left"},onClick:()=>{$(Math.max(0,p-1))},tooltip:{title:o("data-importer.preview-import.prev")},type:"default"}),(0,i.jsx)(s.IconButton,{disabled:E,icon:{value:"chevron-right"},onClick:()=>{$(p+1)},tooltip:{title:o("data-importer.preview-import.next")},type:"default"})]})]}),(0,i.jsx)(s.SearchInput,{maxWidth:320,onChange:e=>{g(e.target.value)},placeholder:o("data-importer.preview-import.search-placeholder"),withClear:!0,withPrefix:!0})]})}),(0,i.jsx)(s.Grid,{autoWidth:!0,columns:R,data:O,isLoading:E}),(0,i.jsx)(s.ImportModal,{action:`${(0,eZ.getPrefix)()}/bundle/data-importer/config/${t}/upload-preview`,data:{...void 0!==C&&{previewScope:C},...void 0!==I&&{interpreterType:I}},onOpenChange:e=>{f(e)},onUploadSuccess:()=>{f(!1),$(0,{forceRefetch:!0}),null==r||r()},open:h,title:o("data-importer.preview-import.upload-file")})]})};var tT=a(3513);let tD=e=>{let{registry:t,...a}=e,{t:r}=(0,l.useTranslation)(),o=(0,n.useMemo)(()=>t.getDynamicTypesForGroup("loading"),[t]),d=(0,n.useMemo)(()=>o.map(e=>{let{type:t,label:a}=e;return{value:t,label:r(a)}}),[o,r]);return(0,i.jsxs)(O,{title:r("data-importer.resolver.element-loading"),children:[(0,i.jsx)(s.Form.Item,{label:r("data-importer.resolver.loading-strategy"),name:["resolverConfig","loadingStrategy","type"],tooltip:r("data-importer.resolver.loading-strategy.tooltip"),children:(0,i.jsx)(s.Select,{filterOption:E,options:d,showSearch:!0})}),o.map(e=>(0,i.jsx)(s.Form.Conditional,{condition:t=>{var a,r;return(null==(r=t.resolverConfig)||null==(a=r.loadingStrategy)?void 0:a.type)===e.type},children:e.renderSettings(a)},e.id))]})},tN=e=>{let{registry:t,...a}=e,{t:r}=(0,l.useTranslation)(),o=(0,n.useMemo)(()=>t.getDynamicTypesForGroup("createLocation"),[t]),d=(0,n.useMemo)(()=>o.map(e=>{let{type:t,label:a}=e;return{value:t,label:r(a)}}),[o,r]);return(0,i.jsxs)(O,{title:r("data-importer.resolver.element-creation"),children:[(0,i.jsx)(s.Form.Item,{label:r("data-importer.resolver.create-location-strategy"),name:["resolverConfig","createLocationStrategy","type"],tooltip:r("data-importer.resolver.create-location-strategy.tooltip"),children:(0,i.jsx)(s.Select,{filterOption:E,options:d,showSearch:!0})}),o.map(e=>(0,i.jsx)(s.Form.Conditional,{condition:t=>{var a,r;return(null==(r=t.resolverConfig)||null==(a=r.createLocationStrategy)?void 0:a.type)===e.type},children:e.renderSettings(a)},e.id))]})},tF=e=>{let{registry:t,...a}=e,{t:r}=(0,l.useTranslation)(),o=(0,n.useMemo)(()=>t.getDynamicTypesForGroup("updateLocation"),[t]),d=(0,n.useMemo)(()=>o.map(e=>{let{type:t,label:a}=e;return{value:t,label:r(a)}}),[o,r]);return(0,i.jsxs)(O,{title:r("data-importer.resolver.element-location-update"),children:[(0,i.jsx)(s.Form.Item,{label:r("data-importer.resolver.location-update-strategy"),name:["resolverConfig","locationUpdateStrategy","type"],tooltip:r("data-importer.resolver.location-update-strategy.tooltip"),children:(0,i.jsx)(s.Select,{filterOption:E,options:d,showSearch:!0})}),o.map(e=>(0,i.jsx)(s.Form.Conditional,{condition:t=>{var a,r;return(null==(r=t.resolverConfig)||null==(a=r.locationUpdateStrategy)?void 0:a.type)===e.type},children:e.renderSettings(a)},e.id))]})},tk=e=>{let{registry:t,...a}=e,{t:r}=(0,l.useTranslation)(),o=(0,n.useMemo)(()=>t.getDynamicTypesForGroup("publishing"),[t]),d=(0,n.useMemo)(()=>o.map(e=>{let{type:t,label:a}=e;return{value:t,label:r(a)}}),[o,r]);return(0,i.jsxs)(O,{title:r("data-importer.resolver.element-publishing"),children:[(0,i.jsx)(s.Form.Item,{label:r("data-importer.resolver.publishing-strategy"),name:["resolverConfig","publishingStrategy","type"],tooltip:r("data-importer.resolver.publishing-strategy.tooltip"),children:(0,i.jsx)(s.Select,{filterOption:E,options:d,showSearch:!0})}),o.map(e=>(0,i.jsx)(s.Form.Conditional,{condition:t=>{var a,r;return(null==(r=t.resolverConfig)||null==(a=r.publishingStrategy)?void 0:a.type)===e.type},children:e.renderSettings(a)},e.id))]})},t$=e=>{let{configName:t,columnHeaderOptions:a,isActive:o}=e,{t:d}=(0,l.useTranslation)(),p=(0,c.useSettings)(),u=(0,n.useMemo)(()=>(p.validLanguages??[]).map(e=>({value:e,label:e})),[p.validLanguages]),{data:m,isLoading:g}=(0,tT.useClassDefinitionCollectionQuery)(void 0,{skip:!o}),h=((null==m?void 0:m.items)??[]).map(e=>({value:e.id,label:e.name})),f=(0,n.useMemo)(()=>r.container.get(Z),[]);return(0,i.jsx)(P.FieldWidthProvider,{fieldWidthValues:{medium:600},children:(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(M,{children:d("data-importer.resolver.title")}),(0,i.jsx)(O,{children:(0,i.jsx)(s.Form.Item,{label:d("data-importer.resolver.class"),name:["resolverConfig","dataObjectClassId"],required:!0,children:(0,i.jsx)(s.Select,{filterOption:E,loadingSkeleton:g,options:h,placeholder:d("data-importer.resolver.class-placeholder"),showSearch:!0})})}),(0,i.jsx)(tD,{columnHeaderOptions:a,languageOptions:u,registry:f}),(0,i.jsx)(tN,{classOptions:h,columnHeaderOptions:a,isLoadingClasses:g,languageOptions:u,registry:f}),(0,i.jsx)(tF,{classOptions:h,columnHeaderOptions:a,isLoadingClasses:g,languageOptions:u,registry:f}),(0,i.jsx)(tk,{columnHeaderOptions:a,registry:f})]})})};function tL(e){var t;return{dataIndex:String(e.dataIndex??""),label:String(e.label??e.dataIndex??""),value:"string"==typeof(t=e.data)?t:void 0!==t?JSON.stringify(t):""}}let tM=(0,p.createStyles)(e=>{let{css:t,token:a}=e;return{mappingLayout:t`
      width: 100%;
      height: 100%;
      min-width: 720px;
    `,mappingLayoutLeft:t`
      flex: 2;
      min-width: 0;
      height: 100%;
      overflow-y: scroll;
    `,mappingLayoutCenter:t`
      width: 46px;
      flex-shrink: 0;
      height: 100%;
    `,mappingLayoutCenterArrow:t`
      position: sticky;
      top: 50%;
      transform: translateY(-50%);
      pointer-events: none;
      color: ${a.colorFillActive};
    `,mappingLayoutRight:t`
      flex: 3;
      min-width: 0;
      height: 100%;
      overflow-y: scroll;
    `,panel:t`
      height: 100%;
    `,panelScrollable:t`
      flex: 1;
      min-height: 0;
      padding: 0 ${a.paddingSM}px ${a.paddingMD}px;
    `,sourcesPanel:t`
      height: 100%;
      background: ${a.colorFillTertiary};
    `,sourcesHeader:t`
      padding: 0 ${a.paddingMD}px;
      height: 52px;
      box-sizing: border-box;
      flex-shrink: 0;
    `,sourcesTitle:t`
      color: ${a.colorPrimary};
      font-weight: 600;
      font-size: ${a.fontSizeLG}px;
      margin: 0;
    `,sourceRowOuter:t`
      border-left: 2px solid ${a.colorBorder};
      border-radius: ${a.borderRadiusLG}px;
      box-shadow: ${a.boxShadowTertiary};
      transition: opacity 0.15s;
      position: relative;

      &:hover .source-add-btn {
        opacity: 1;
        pointer-events: auto;
      }
    `,sourceRowOuterMapped:t`
      border-left-color: ${a.colorPrimaryBorderHover};
    `,sourceRowOuterFaded:t`
      opacity: 0.4;
    `,sourceRowInner:t`
      background: ${a.colorBgContainer};
      border: 1px solid ${a.colorBorderSecondary};
      border-left: none;
      border-radius: ${a.borderRadiusLG}px;
      min-height: 40px;
      overflow: hidden;
    `,sourceRowInnerMapped:t`
      cursor: pointer;
    `,sourceRowInnerUnmapped:t`
      cursor: pointer;
    `,sourceRowTagArea:t`
      flex: 1;
      padding: ${a.paddingXS}px ${a.paddingXS}px;
      min-width: 0;
    `,sourceTagInner:t`
      display: inline-flex;
      align-items: center;
    `,sourceAddBtn:t`
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.15s;
      flex-shrink: 0;
      display: inline-flex;
      align-items: center;
    `,sourceValue:t`
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      color: ${a.colorTextDescription};
      font-size: ${a.fontSize}px;
      padding: 0 ${a.paddingXS}px;
      min-width: 0;
    `,noContentWrapper:t`
      flex: 1;
      padding: ${a.paddingXL}px ${a.paddingMD}px;
    `,sourceRowsSpace:t`
      width: 100%;
    `,badgeMappedCount:t`
      & .ant-badge-count {
        background-color: ${a.colorFillActive};
        color: ${a.colorPrimary};
        box-shadow: none;
      }
    `,droppablePanel:t`
      width: 100%;

      & .dnd--drag-active,
      & .dnd--drag-valid,
      & .dnd--drag-error {
        background: unset !important;
        border: unset !important;
        outline: none !important;
      }
    `,panelDndWrapper:t`
      & .ant-collapse {
        transition: border-color 0.15s, border-style 0.15s;
      }

      &.dnd--drag-active .ant-collapse {
        border-style: dashed !important;
        border-color: ${a.colorBorder} !important;
      }

      &.dnd--drag-valid .ant-collapse {
        border-style: dashed !important;
        border-color: ${a.colorPrimary} !important;
      }

      &.dnd--drag-error .ant-collapse {
        border-style: dashed !important;
        border-color: ${a.colorError} !important;
      }
    `,panelExpanded:t`
      & .ant-collapse {
        border-color: ${a.colorPrimaryBorder} !important;
      }
    `,sourceDropZone:t`
      border-radius: ${a.borderRadius}px;
    `,mappingsHeader:t`
      padding: 0 ${a.paddingMD}px 0 0;
      height: 52px;
      box-sizing: border-box;
      flex-shrink: 0;
    `,mappingsTitle:t`
      color: ${a.colorPrimary};
      font-weight: 600;
      font-size: ${a.fontSizeLG}px;
      margin: 0;
      margin-right: ${a.paddingXS}px;
    `,mappingsActions:t`
      flex: 1;
    `,mappingsDivider:t`
      margin: 0;
      height: 16px;
    `,mappingsContent:t`
      flex: 1;
      padding: 0 ${a.paddingMD}px ${a.paddingMD}px 0;
      margin-top: -10px;
    `,emptyState:t`
      flex: 1;
      display: flex;
      flex-direction: column;
      height: 100%;
      min-height: 0;

      /* Droppable renders a wrapper div — make it fill too */
      & > div {
        flex: 1;
        display: flex;
        flex-direction: column;
        height: 100%;
      }
    `,emptyStateInner:t`
      flex: 1;
      height: 100%;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      text-align: center;
      color: ${a.colorTextSecondary};
      line-height: 1.6;
      border-radius: ${a.borderRadiusLG}px;
      transition: background 0.15s, outline-color 0.15s;

      &.dnd--drag-active {
        outline: 2px dashed ${a.colorBorderSecondary};
        outline-offset: -2px;
      }

      &.dnd--drag-valid {
        background: ${a.colorFillSecondary};
        outline: 2px dashed ${a.colorInfoBorderHover};
        outline-offset: -2px;
      }

      &.dnd--drag-error {
        outline: 2px dashed ${a.colorErrorBorder};
        outline-offset: -2px;
      }
    `,mappingItemContent:t`
      padding: ${a.paddingSM}px ${a.paddingXS}px;
    `,mappingLabelRow:t`
      display: flex;
      align-items: center;
      gap: ${a.sizeXS}px;
      padding: 0 ${a.paddingXXS}px;
    `,mappingLabelInput:t`
      flex: 1;
    `,mappingDivider:t`
      border-top: 1px solid ${a.colorBorderSecondary};
      margin-top: ${a.paddingXS}px;
    `,sourcesDestRow:t`
      display: flex;
      align-items: stretch;
      padding-top: ${a.paddingSM}px;
    `,sourcesDestCol:t`
      display: flex;
      flex-direction: column;
      gap: ${a.sizeXXS}px;
      flex: 1;
      min-width: 0;
      padding: 0 ${a.paddingXXS}px;
    `,arrowCol:t`
      flex-shrink: 0;
      padding: 0 ${a.paddingSM}px;
    `,arrowColSimple:t`
      display: flex;
      flex-direction: column;
      justify-content: flex-start;
    `,arrowLabelSpacer:t`
      height: calc(22px + ${a.paddingXXS}px);
      flex-shrink: 0;
    `,arrowSelectRow:t`
      display: flex;
      align-items: center;
      height: ${a.controlHeight}px;
    `,arrowColAdvanced:t`
      display: flex;
      flex-direction: column;
      justify-content: center;
      gap: 10px;
    `,arrowWarningBadge:t`
      display: flex;
      align-items: center;
      justify-content: center;
      color: ${a.colorWarning};
      font-size: ${a.fontSizeLG}px;
      line-height: 1;
    `,arrowAdvancedIcon:t`
      display: flex;
      align-items: center;
      justify-content: center;
      color: ${a.colorIcon};
      font-size: ${a.fontSizeLG}px;
      line-height: 1;
    `,arrowSvg:t`
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    `,destinationTextBlock:t`
      display: flex;
      flex-direction: column;
      justify-content: center;
      /* Fills the destination column and centers within it, so the text stays on the same
         vertical center as the source control and the arrow — including when a multi-source
         Select wraps onto several lines and sourcesDestRow stretches both columns taller.
         The min-height keeps the unwrapped case matching the Select it replaces. */
      flex: 1;
      min-height: ${a.controlHeight}px;
      padding: 0 ${a.paddingXXS}px;
      font-size: ${a.fontSize}px;
      line-height: 22px;
      color: ${a.colorText};
    `,requiresAdvancedHint:t`
      display: flex;
      align-items: center;
      flex: 1;
      min-height: ${a.controlHeight}px;
      padding: 0 ${a.paddingXXS}px;
      font-size: ${a.fontSize}px;
      line-height: 22px;
      color: ${a.colorWarningText};
    `,languageSelect:t`
      flex: 1;
    `,filterEmptyState:t`
      flex: 1;
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      min-height: 0;

      /* Droppable renders a wrapper div — make it fill too */
      & > div {
        flex: 1;
        display: flex;
        flex-direction: column;
        width: 100%;
        height: 100%;
      }
    `,filterEmptyStateInner:t`
      flex: 1;
      width: 100%;
      height: 100%;
      min-height: 0;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      gap: ${a.paddingSM}px;
      text-align: center;
      color: ${a.colorTextSecondary};
      border-radius: ${a.borderRadiusLG}px;
      transition: background 0.15s, outline-color 0.15s;

      &.dnd--drag-active {
        outline: 2px dashed ${a.colorBorderSecondary};
        outline-offset: -2px;
      }

      &.dnd--drag-valid {
        background: ${a.colorFillSecondary};
        outline: 2px dashed ${a.colorInfoBorderHover};
        outline-offset: -2px;
      }

      &.dnd--drag-error {
        outline: 2px dashed ${a.colorErrorBorder};
        outline-offset: -2px;
      }
    `,hiddenItem:t`
      display: none;
    `,mappingDropZoneWrapper:t`
      width: 100%;
      padding: 2px 0;

      & .dnd--drag-active,
      & .dnd--drag-valid,
      & .dnd--drag-error {
        border: none !important;
        outline: none !important;
      }
    `,mappingDropZone:t`
      width: 100%;
      height: 6px;
      border-radius: ${a.borderRadiusSM}px;
      background: transparent;
      transition: background 0.15s;
      pointer-events: none;
      flex-shrink: 0;

      &.dnd--drag-active {
        pointer-events: auto;
        background: ${a.colorBorderSecondary};
      }

      &.dnd--drag-valid {
        pointer-events: auto;
        background: ${a.colorInfoBorderHover};
      }

      &.dnd--drag-error {
        pointer-events: auto;
        background: ${a.colorErrorBorder};
      }
    `,mappingItemNew:t`
      @keyframes mapping-item-slide-in {
        0% {
          opacity: 0;
          transform: translateY(-12px);
        }
        100% {
          opacity: 1;
          transform: translateY(0);
        }
      }

      animation: mapping-item-slide-in 400ms ease-in-out;
    `,annotatedTitle:t`
      display: inline-flex;
      align-items: center;
      gap: ${a.marginXS}px;
      min-width: 0;
    `,removedTitle:t`
      text-decoration: line-through;
      color: ${a.colorTextTertiary};
    `}}),tP="data-importer-source-column",tR=e=>{let{configName:t,sourceRows:a,hasPreviewError:r,activeFilter:o,onSetFilter:d,onAddMappingFromSource:c}=e,{t:p}=(0,l.useTranslation)(),{styles:u}=tM(),m=s.Form.useWatch(e=>JSON.stringify((e.mappingConfig??[]).map(e=>e.dataSourceIndex??[]))),g=(0,n.useMemo)(()=>void 0!==m?JSON.parse(m):void 0,[m]),h=(0,n.useMemo)(()=>{let e={};return(g??[]).forEach(t=>{t.forEach(t=>{e[t]=(e[t]??0)+1})}),e},[g]),f=null!==o,x=a.length>0;return(0,i.jsxs)(s.Flex,{className:u.sourcesPanel,vertical:!0,children:[(0,i.jsxs)(s.Flex,{align:"center",className:u.sourcesHeader,justify:"space-between",children:[(0,i.jsx)(s.Text,{className:u.sourcesTitle,children:p("data-importer.mapping.sources.title")}),f&&(0,i.jsx)(s.Button,{onClick:()=>{d(null)},size:"small",type:"link",children:p("data-importer.mapping.sources.reset-view")})]}),(0,i.jsxs)(s.Flex,{className:u.panelScrollable,vertical:!0,children:[!x&&r&&(0,i.jsx)(s.Flex,{align:"center",className:u.noContentWrapper,justify:"center",children:(0,i.jsx)(s.NoContent,{text:p("data-importer.mapping.sources.empty")})}),x&&(0,i.jsx)(s.Space,{className:u.sourceRowsSpace,direction:"vertical",size:"extra-small",children:a.map(e=>{let t=h[e.dataIndex]??0,a=t>0,r=f&&o!==e.dataIndex;return(0,i.jsx)("div",{className:$()(u.sourceRowOuter,{[u.sourceRowOuterMapped]:a,[u.sourceRowOuterFaded]:r}),children:(0,i.jsx)(s.Draggable,{info:{type:tP,title:e.label,icon:{value:"workflow"},data:{dataIndex:e.dataIndex,label:e.label}},children:(0,i.jsxs)(s.Flex,{align:"center",className:$()(u.sourceRowInner,a?u.sourceRowInnerMapped:u.sourceRowInnerUnmapped),onClick:()=>{d(o===e.dataIndex?null:e.dataIndex)},children:[(0,i.jsxs)(s.Flex,{align:"center",className:u.sourceRowTagArea,gap:"extra-small",children:[(0,i.jsx)("div",{className:u.sourceTagInner,children:(0,i.jsxs)(s.Space,{size:"extra-small",children:[(0,i.jsx)(s.Tag,{color:a?"purple":void 0,children:e.label}),a&&(0,i.jsx)(s.Badge,{className:u.badgeMappedCount,count:t,size:"large"})]})}),!a&&(0,i.jsx)("span",{className:`source-add-btn ${u.sourceAddBtn}`,children:(0,i.jsx)(s.IconButton,{icon:{value:"plus-circle"},onClick:t=>{t.stopPropagation(),c(e.dataIndex,e.label),d(e.dataIndex)},size:"small",tooltip:{title:p("data-importer.mapping.add")},type:"default"})})]}),(0,i.jsx)("span",{className:u.sourceValue,title:e.value,children:e.value})]})})},e.dataIndex)})})]})]})},tA="__default__";function tO(e){return void 0===e||""===e||"default"===e?tA:e}let tE=(0,p.createStyles)(e=>{let{css:t,token:a}=e;return{wrapper:t`
      flex: 1;
    `,header:t`
      height: 32px;
    `,title:t`
      font-size: 12px;
      font-weight: 600;
      color: ${a.colorPrimaryText};
    `,tableWrapper:t`
      min-height: 180px;
      max-height: 420px;
      border: 0.5px solid ${a.colorBorderSecondary};
      border-radius: ${a.borderRadiusSM}px;
      overflow: hidden;
      overflow-y: auto;
    `,tableHeader:t`
      display: grid;
      grid-template-columns: 1fr 1fr;
      background: ${a.colorFillAlter};
      border-bottom: 0.5px solid ${a.colorBorderSecondary};
    `,tableHeaderCell:t`
      font-size: 12px;
      padding: 6px ${a.paddingXS}px;
      font-weight: 500;
    `,tableHeaderCellBorder:t`
      border-right: 0.5px solid ${a.colorBorderSecondary};
    `,tableRow:t`
      display: grid;
      grid-template-columns: 1fr 1fr;
      background: ${a.colorBgContainer};
      height: 32px;
    `,tableRowHighlighted:t`
      background: ${a.colorSuccessBg};
    `,tableRowBorder:t`
      border-bottom: 0.5px solid ${a.colorBorderSecondary};
    `,tableCell:t`
      font-size: 12px;
      padding: 0 ${a.paddingXS}px;
      overflow: hidden;
      white-space: nowrap;
      text-overflow: ellipsis;
    `,tableCellBorder:t`
      border-right: 0.5px solid ${a.colorBorderSecondary};
    `,stateMessage:t`
      padding: ${a.paddingMD}px ${a.paddingXS}px;
      font-size: 12px;
      color: ${a.colorTextSecondary};
      text-align: center;
    `,previewArea:t`
      min-height: 100px;
      overflow-y: auto;
    `,muted:t`
      font-size: 12px;
      color: ${a.colorTextQuaternary};
    `,previewLine:t`
      font-size: 12px;
      color: ${a.colorTextSecondary};
      margin-bottom: ${a.paddingXXS}px;
    `}}),tB=e=>{let{t}=(0,l.useTranslation)(),{styles:a,cx:r}=tE(),[o,d]=(0,n.useState)([]),[c,p]=(0,n.useState)(0),[u,m]=(0,n.useState)(0),[g,h]=(0,n.useState)(""),{dataPreview:f,currentRecordIndex:x,isLoading:v,isFetching:y,isError:b,load:j}=tS({configName:e.configName,enabled:"import"===e.mode,forceRefreshToken:e.forceRefreshToken}),[S,C]=(0,n.useState)([]),[I,w]=(0,n.useState)(0),T=tj(),[D,N]=(0,n.useState)(void 0),{data:F,isLoading:k,isFetching:$,isError:L,refetch:M}=tr(D,{skip:"result"!==e.mode||void 0===D,refetchOnMountOrArgChange:!1});(0,n.useEffect)(()=>{d(f.map(e=>tL(e)))},[f]),(0,n.useEffect)(()=>{m(x)},[x]),(0,n.useEffect)(()=>{b&&d([])},[b]);let P=t=>{var a,r,i,n;let o=void 0===e.currentMappingItem?void 0:{mappingConfig:[e.currentMappingItem],...(null==(a=e.baseConfig)?void 0:a.loaderConfig)!==void 0&&{loaderConfig:e.baseConfig.loaderConfig},...(null==(r=e.baseConfig)?void 0:r.interpreterConfig)!==void 0&&{interpreterConfig:e.baseConfig.interpreterConfig},...(null==(i=e.baseConfig)?void 0:i.resolverConfig)!==void 0&&{resolverConfig:e.baseConfig.resolverConfig},...(null==(n=e.baseConfig)?void 0:n.processingConfig)!==void 0&&{processingConfig:e.baseConfig.processingConfig}};N({name:e.configName,bundleDataImporterLoadPreviewParameters:{recordNumber:t,...void 0!==o&&{currentConfig:o},...void 0!==T&&{previewScope:T}}})};(0,n.useEffect)(()=>{if("result"!==e.mode||void 0===F)return;let t=F.transformationResultPreviews??[];C(void 0===e.currentMappingItem?t:t.slice(0,1))},[e.mode,F,e.currentMappingItem]),(0,n.useEffect)(()=>{L&&C([])},[L]),(0,n.useEffect)(()=>{"result"===e.mode&&P(I)},[e.refreshToken]);let R=(0,n.useRef)(!0);(0,n.useEffect)(()=>{if("result"===e.mode&&void 0!==e.forceRefreshToken&&0!==e.forceRefreshToken){if(R.current){R.current=!1;return}void 0===D?P(I):M()}},[e.forceRefreshToken]);let A=(e,t,r,n,o)=>(0,i.jsxs)(s.Flex,{align:"center",className:a.header,justify:"space-between",children:[(0,i.jsx)("span",{className:a.title,children:e}),(0,i.jsxs)(s.Space,{size:"mini",children:[(0,i.jsx)(s.IconButton,{disabled:!t||r,icon:{value:"chevron-left"},onClick:n,size:"small",type:"default"}),(0,i.jsx)(s.IconButton,{disabled:r,icon:{value:"chevron-right"},onClick:o,size:"small",type:"default"})]})]});if("import"===e.mode){let n=""===g.trim()?o:o.filter(e=>e.label.toLowerCase().includes(g.toLowerCase())||e.value.toLowerCase().includes(g.toLowerCase()));return(0,i.jsxs)(s.Flex,{className:a.wrapper,gap:"extra-small",vertical:!0,children:[A(t("data-importer.mapping.advanced-modal.step-source.import-preview"),u>0,v||y,()=>{let e=Math.max(0,c-1);p(e),j(e)},()=>{let e=c+1;p(e),j(e)}),(0,i.jsx)(s.SearchInput,{maxWidth:"100%",onChange:e=>{h(e.target.value)},placeholder:t("data-importer.mapping.advanced-modal.step-source.search-placeholder"),value:g,withClear:!0,withPrefix:!0}),(0,i.jsxs)("div",{className:a.tableWrapper,children:[(0,i.jsxs)("div",{className:a.tableHeader,children:[(0,i.jsx)("div",{className:r(a.tableHeaderCell,a.tableHeaderCellBorder),children:t("data-importer.mapping.advanced-modal.step-source.column-name")}),(0,i.jsx)("div",{className:a.tableHeaderCell,children:t("data-importer.mapping.advanced-modal.step-source.column-data")})]}),(v||y)&&(0,i.jsx)("div",{className:a.stateMessage,children:(0,i.jsx)(s.Spin,{type:"classic"})}),!(v||y)&&n.map((t,o)=>{let l=e.selectedDataSourceIndex.includes(t.dataIndex),d=o===n.length-1;return(0,i.jsxs)("div",{className:r(a.tableRow,l&&a.tableRowHighlighted,!d&&a.tableRowBorder),children:[(0,i.jsx)(s.Flex,{align:"center",className:r(a.tableCell,a.tableCellBorder),children:t.label}),(0,i.jsx)(s.Flex,{align:"center",className:a.tableCell,children:t.value})]},t.dataIndex)}),!(v||y)&&0===n.length&&(0,i.jsx)("div",{className:a.stateMessage,children:t("data-importer.mapping.advanced-modal.no-data")})]})]})}return(0,i.jsxs)(s.Flex,{className:a.wrapper,gap:"extra-small",vertical:!0,children:[A(t("data-importer.mapping.advanced-modal.step-target.preview-result"),I>0,k||$,()=>{let e=Math.max(0,I-1);w(e),P(e)},()=>{let e=I+1;w(e),P(e)}),(0,i.jsxs)("div",{className:a.previewArea,children:[(k||$)&&(0,i.jsx)("div",{className:a.muted,children:(0,i.jsx)(s.Spin,{type:"classic"})}),!(k||$)&&0===S.length&&(0,i.jsx)("div",{className:a.muted,children:t("data-importer.mapping.advanced-modal.no-preview")}),!(k||$)&&S.map((e,t)=>(0,i.jsx)("div",{className:a.previewLine,children:e},`preview-${t}`))]})]})},tz=(0,p.createStyles)(e=>{let{css:t,token:a}=e;return{twoColumnLayout:t`
      min-height: 280px;
      width: 100%;
      overflow: hidden;
    `,leftColumn:t`
      flex: 1 1 0;
      min-width: 0;
      background: ${a.colorFillAdditional};
      border-radius: ${a.borderRadius}px;
      padding: 10px ${a.paddingSM}px;
    `,labelSmall:t`
      font-size: 12px;
    `,selectFull:t`
      width: 100%;
      /* Ant Design sets max-width: 9999px as an inline style on .ant-select
         for multiple-mode selects — override it so the select cannot overflow
         its flex container. */
      &.ant-select {
        max-width: 100% !important;
      }
    `,rightColumn:t`
      flex: 1 1 0;
      min-width: 0;
    `}}),tH=e=>{let{configName:t,dataSourceIndex:a,forceRefreshToken:r,columnHeaderOptions:n,onDataSourceIndexChange:o}=e,{t:d}=(0,l.useTranslation)(),{styles:c}=tz();return(0,i.jsxs)(s.Flex,{className:c.twoColumnLayout,gap:"extra-small",children:[(0,i.jsxs)(s.Flex,{className:c.leftColumn,gap:6,vertical:!0,children:[(0,i.jsx)(s.Text,{className:c.labelSmall,strong:!0,children:d("data-importer.mapping.advanced-modal.step-source.label")}),(0,i.jsx)(s.Text,{className:c.labelSmall,type:"secondary",children:d("data-importer.mapping.advanced-modal.step-source.description")}),(0,i.jsx)(s.Select,{className:c.selectFull,mode:"multiple",onChange:o,options:n,placeholder:d("data-importer.mapping.item.source-placeholder"),showSearch:!0,value:a})]}),(0,i.jsx)(s.Flex,{className:c.rightColumn,vertical:!0,children:(0,i.jsx)(tB,{configName:t,forceRefreshToken:r,mode:"import",selectedDataSourceIndex:a})})]})};var tq=a(2692);let tW=(0,p.createStyles)(e=>{let{css:t,token:a}=e;return{twoColumnLayout:t`
      width: 100%;
      overflow: hidden;
    `,leftColumn:t`
      flex: 1 0 0;
      min-width: 0;
    `,listHeader:t`
      height: 32px;
      flex-shrink: 0;
    `,listHeaderTitle:t`
      font-size: 12px;
      font-weight: 600;
      color: ${a.colorPrimaryText};
      flex: 1;
    `,itemsList:t`
      flex: 1;
      overflow-y: auto;
    `,emptyState:t`
      font-size: 12px;
      color: ${a.colorTextQuaternary};
    `,transformerCardOverlay:t`
      border: 1px solid ${a.colorBorderSecondary};
      border-radius: ${a.borderRadiusSM}px;
      padding: 6px ${a.paddingXS}px;
      gap: ${a.paddingXXS}px;
      background: ${a.colorFillAdditional};
      box-shadow: ${a.boxShadowSecondary};
      cursor: grabbing;
    `,rightColumn:t`
      flex: 1 0 0;
      min-width: 0;
      padding-left: ${a.paddingXXS}px;
    `,sourceSectionHeader:t`
      height: 32px;
    `,sourceSectionTitle:t`
      font-size: 12px;
      font-weight: 600;
      color: ${a.colorPrimaryText};
    `,sourceValues:t`
      font-size: 12px;
      color: ${a.colorText};
      line-height: 22px;
      flex-wrap: wrap;
    `,sourceSeparator:t`
      color: ${a.colorTextSecondary};
      margin: 0 4px;
    `}});var tV=a(8668),tX=a(3627),t_=a(8831),tG=a(4979);let tU=(0,p.createStyles)(e=>{let{css:t,token:a}=e;return{transformerCardWrapper:t`
      & .ant-collapse.collapse-item--theme-primary {
        background-color: ${a.colorFillAdditional};
      }

      & .ant-collapse-content {
        background-color: ${a.colorFillAdditional} !important;
      }
    `,dragHandle:t`
      cursor: grab;
      user-select: none;
      flex-shrink: 0;
      margin-right: ${a.paddingXXS}px;

      &:active {
        cursor: grabbing;
      }
    `,dragHandleIcon:t`
      font-size: 14px;
      line-height: 1;
      color: ${a.colorTextTertiary};
    `,transformerLabel:t`
      font-weight: 400;
      font-size: 12px;
      color: ${a.colorText};
    `,transformerDeleteButton:t`
      color: ${a.colorPrimary} !important;

      &:hover {
        color: ${a.colorPrimaryHover} !important;
        background: transparent !important;
      }
    `}}),tK=e=>{let{label:t,children:a,dragHandleProps:r,index:n,onRemove:o,removeTooltip:l}=e,{styles:d}=tU(),c=(0,i.jsxs)(s.Flex,{align:"center",gap:"mini",children:[(0,i.jsx)(s.Flex,{align:"center",className:d.dragHandle,...r,children:(0,i.jsx)("span",{className:d.dragHandleIcon,children:"⠿"})}),(0,i.jsx)("span",{className:d.transformerLabel,children:t})]}),p=(0,i.jsx)(s.IconButton,{className:d.transformerDeleteButton,icon:{value:"trash"},onClick:e=>{e.stopPropagation(),o(n)},size:"small",tooltip:{title:l},type:"text"});return(0,i.jsx)("div",{className:d.transformerCardWrapper,children:(0,i.jsx)(s.CollapseItem,{bordered:!1,defaultActive:!0,extra:p,hasContentSeparator:!1,label:c,size:"small",theme:"primary",children:a})})},tQ=e=>{let{item:t,index:a,label:r,children:n,onRemove:o,removeTooltip:l}=e,{attributes:s,listeners:d,setNodeRef:c,transform:p,transition:u,isDragging:m}=(0,tX.gl)({id:t._id}),g={transform:tG.Ks.Transform.toString(p),transition:u,opacity:+!m};return(0,i.jsx)("div",{ref:c,style:g,children:(0,i.jsx)(tK,{dragHandleProps:{...s,...d},index:a,label:r,onRemove:o,removeTooltip:l,children:n})})},tY=e=>{let{items:t,activeId:a,transformerRegistry:r,onDragStart:n,onDragEnd:o,onRemove:s,onUpdateSettings:d}=e,{t:c}=(0,l.useTranslation)(),{styles:p}=tW(),u=(0,tV.FR)((0,tV.MS)(tV.AN,{activationConstraint:{distance:8}}),(0,tV.MS)(tV.uN,{coordinateGetter:tX.JR}));return(0,i.jsxs)(tV.Mp,{collisionDetection:tV.fp,modifiers:[t_.FN],onDragEnd:o,onDragStart:n,sensors:u,children:[(0,i.jsx)(tX.gB,{items:t.map(e=>e._id),strategy:tX._G,children:t.map((e,t)=>{let a="string"==typeof e.type?e.type:"",n=r.getDynamicType(a,!1),o=e.settings??{};return(0,i.jsx)(tQ,{index:t,item:e,label:(null==n?void 0:n.label)??a,onRemove:s,removeTooltip:c("data-importer.mapping.advanced-modal.transformer.remove"),children:null==n?void 0:n.renderSettings(o,e=>{d(t,e)})},e._id)})}),(0,i.jsx)(tV.Hd,{children:(()=>{if(null===a)return null;let e=t.findIndex(e=>e._id===a);if(-1===e)return null;let n=t[e],o="string"==typeof n.type?n.type:"",l=r.getDynamicType(o,!1),u=n.settings??{};return(0,i.jsx)("div",{className:p.transformerCardOverlay,children:(0,i.jsx)(tK,{index:e,label:(null==l?void 0:l.label)??o,onRemove:s,removeTooltip:c("data-importer.mapping.advanced-modal.transformer.remove"),children:null==l?void 0:l.renderSettings(u,t=>{d(e,t)})})})})()})]})},tJ=(0,p.createStyles)(e=>{let{css:t,token:a}=e;return{root:t`
    color: ${a.colorErrorText};
    font-size: 12px;
    line-height: 18px;
    background: ${a.colorErrorBg};
    border: 1px solid ${a.colorErrorBorder};
    border-radius: ${a.borderRadius}px;
    padding: ${a.paddingXXS}px ${a.paddingXS}px;
  `}}),tZ=e=>{let{children:t}=e,{styles:a}=tJ();return(0,i.jsx)("div",{className:a.root,children:t})},t0=(0,n.createContext)(void 0);function t1(){let e=(0,n.useContext)(t0);if(void 0===e)throw Error("useResultPreviewContext must be used within a ResultPreviewProvider");return e}let t2=e=>{let{children:t,...a}=e,r=(0,n.useMemo)(()=>a,[a.configName,a.previewRefreshToken,a.forceRefreshToken,a.currentMappingItem,a.baseConfig,a.calculateTypeError,a.isFetchingAttributes]);return(0,i.jsx)(t0.Provider,{value:r,children:t})},t3=(0,p.createStyles)(e=>{let{css:t}=e;return{wrapper:t`
    flex: 1;
    overflow: hidden;
  `}}),t5=()=>{let{configName:e,previewRefreshToken:t,forceRefreshToken:a,currentMappingItem:r,baseConfig:n,calculateTypeError:o,isFetchingAttributes:l}=t1(),{styles:d}=t3();return(0,i.jsxs)("div",{className:d.wrapper,children:[l&&(0,i.jsx)(s.Spin,{type:"classic"}),!l&&void 0!==o&&(0,i.jsx)(tZ,{children:o}),!l&&void 0===o&&(0,i.jsx)(tB,{baseConfig:n,configName:e,currentMappingItem:r,forceRefreshToken:a,mode:"result",refreshToken:t})]})},t9=(0,p.createStyles)(e=>{let{css:t,token:a}=e;return{outlineButton:t`
      height: 32px;
      padding: 0 15px;
      font-size: 12px;
      color: ${a.colorPrimary};
      background: ${a.colorBgContainer};
      border: 1px solid ${a.colorPrimaryBorder};
      border-radius: ${a.borderRadius}px;
      cursor: pointer;
      box-shadow: ${a.boxShadowTertiary};
    `,boxHeader:t`
      padding: ${a.paddingXXS}px ${a.paddingXS}px;
    `,boxHeaderTitle:t`
      font-size: 12px;
      font-weight: 600;
    `,selectFull:t`
      width: 100%;
      &.ant-select {
        max-width: 100% !important;
      }
    `}}),t6=e=>{let{dataSourceIndex:t,columnHeaderOptions:a,editingSource:r,onToggleEditing:n,onBlurSource:d,onChangeSource:c,getSourceLabel:p}=e,{t:u}=(0,l.useTranslation)(),{styles:m}=tW(),{styles:g}=t9();return(0,i.jsxs)(s.Flex,{className:m.rightColumn,gap:"extra-small",vertical:!0,children:[(0,i.jsxs)(s.Flex,{gap:"mini",vertical:!0,children:[(0,i.jsxs)(s.Flex,{align:"center",className:m.sourceSectionHeader,gap:"mini",children:[(0,i.jsx)("span",{className:m.sourceSectionTitle,children:u("data-importer.mapping.advanced-modal.step-source.label")}),(0,i.jsx)(s.IconButton,{icon:{value:"edit-pen"},onClick:n,size:"small",tooltip:{title:u("data-importer.mapping.advanced-modal.transformer.edit-source")},type:"text"})]}),r?(0,i.jsx)(s.Select,{className:g.selectFull,mode:"multiple",onBlur:d,onChange:e=>{c(Array.isArray(e)?e:[])},options:a,showSearch:!0,value:t}):(0,i.jsx)(s.Flex,{className:m.sourceValues,wrap:"wrap",children:0===t.length?(0,i.jsx)("span",{className:m.emptyState,children:"—"}):t.map((e,t)=>(0,i.jsxs)(o().Fragment,{children:[t>0&&(0,i.jsx)("span",{className:m.sourceSeparator,children:" | "}),(0,i.jsx)("span",{children:p(e)})]},e))})]}),(0,i.jsx)(t5,{})]})},t4=e=>({...e,_id:(0,tq.v4)()}),t8=e=>{let{_id:t,...a}=e;return a},t7=e=>{let{pipeline:t,dataSourceIndex:a,columnHeaderOptions:o,onPipelineChange:d,onDataSourceIndexChange:c}=e,{t:p}=(0,l.useTranslation)(),{styles:u}=tW(),[m,g]=(0,n.useState)(()=>t.map(t4)),h=(0,n.useRef)(t);(0,n.useEffect)(()=>{t!==h.current&&(h.current=t,g(e=>t.map((t,a)=>{let r=e[a];return(null==r?void 0:r.type)===t.type?{...t,_id:r._id}:t4(t)})))},[t]);let[f,x]=(0,n.useState)(!1),[v,y]=(0,n.useState)(null),b=(0,n.useMemo)(()=>r.container.get(ef),[]),j=(0,n.useMemo)(()=>{let e=b.getDynamicTypes(),t=t=>e.filter(e=>e.group===t).map(e=>({key:e.id,label:e.label}));return[{key:"dataManipulation",label:p("data-importer.mapping.advanced-modal.transformer.group.data-manipulation"),children:t("dataManipulation")},{key:"dataTypes",label:p("data-importer.mapping.advanced-modal.transformer.group.data-types"),children:t("dataTypes")},{key:"loadImport",label:p("data-importer.mapping.advanced-modal.transformer.group.load-import"),children:t("loadImport")}]},[b]);return(0,i.jsxs)(s.Flex,{className:u.twoColumnLayout,gap:"extra-small",children:[(0,i.jsxs)(s.Flex,{className:u.leftColumn,gap:"extra-small",vertical:!0,children:[(0,i.jsxs)(s.Flex,{align:"center",className:u.listHeader,gap:"extra-small",children:[(0,i.jsx)("span",{className:u.listHeaderTitle,children:p("data-importer.mapping.advanced-modal.step-transformations")}),(0,i.jsx)(s.Dropdown,{menu:{items:j,onClick:e=>{let t,{key:a}=e;g(t=[...m,t4({type:String(a),settings:{}})]),d(t.map(t8))}},trigger:["click"],children:(0,i.jsx)(s.IconTextButton,{icon:{value:"add"},size:"small",type:"default",children:p("data-importer.mapping.add")})})]}),(0,i.jsxs)(s.Flex,{className:u.itemsList,gap:6,vertical:!0,children:[0===m.length&&(0,i.jsx)("span",{className:u.emptyState,children:p("data-importer.mapping.advanced-modal.no-transformers")}),(0,i.jsx)(tY,{activeId:v,items:m,onDragEnd:e=>{y(null);let{active:t,over:a}=e;if(null===a||t.id===a.id)return;let r=m.findIndex(e=>e._id===t.id),i=m.findIndex(e=>e._id===a.id);if(-1===r||-1===i)return;let n=[...m],[o]=n.splice(r,1);n.splice(i,0,o),g(n),d(n.map(t8))},onDragStart:e=>{y(String(e.active.id))},onRemove:e=>{let t=m.filter((t,a)=>a!==e);g(t),d(t.map(t8))},onUpdateSettings:(e,t)=>{let a=m.map((a,r)=>r===e?{...a,settings:t}:a);g(a),d(a.map(t8))},transformerRegistry:b})]})]}),(0,i.jsx)(t6,{columnHeaderOptions:o,dataSourceIndex:a,editingSource:f,getSourceLabel:e=>{let t=o.find(t=>t.value===e);return(null==t?void 0:t.label)??e},onBlurSource:()=>{x(!1)},onChangeSource:e=>{c(e),x(!1)},onToggleEditing:()=>{x(e=>!e)}})]})},ae=(0,p.createStyles)(e=>{let{css:t,token:a}=e;return{twoColumnLayout:t`
      min-height: 240px;
    `,leftColumn:t`
      flex: 0 0 calc(50% - 4px);
      min-width: 0;
      background: ${a.colorFillAdditional};
      border-radius: ${a.borderRadius}px;
    `,leftHeader:t`
      padding: ${a.paddingXXS}px ${a.paddingXS}px;
      height: 32px;
    `,leftHeaderTitle:t`
      font-size: 12px;
    `,fieldsContainer:t`
      padding: 0 ${a.paddingXS}px ${a.paddingXS}px ${a.paddingXS}px;
      flex: 1;

      & > div {
        min-width: 0;
      }
    `,fieldLabel:t`
      font-size: 12px;
      margin-bottom: ${a.paddingXXS}px;
    `,overwriteLabel:t`
      font-size: 12px;
      margin-top: 2px;
    `,switchLabel:t`
      font-size: 12px;
    `,selectFull:t`
      width: 100%;
      height: 32px;
    `,selectSkeletonWrapper:t`
      width: 100%;
      min-width: 0;

      & > * {
        width: 100%;
        min-width: 0;
      }
    `,classificationStoreKeyInput:t`
      flex: 1;
    `,rightColumn:t`
      flex: 0 0 calc(50% - 4px);
      min-width: 0;
    `}}),at=()=>{let{styles:e}=ae();return(0,i.jsx)(s.Flex,{className:e.rightColumn,vertical:!0,children:(0,i.jsx)(t5,{})})},aa=e=>{let{dataTarget:t,transformationResultType:a,classId:o,classFieldOptions:d,isLocalized:c,onDataTargetChange:p}=e,{t:u}=(0,l.useTranslation)(),{styles:m}=ae(),g=(0,n.useMemo)(()=>r.container.get(e_),[]),h=(0,n.useMemo)(()=>g.getDynamicType((null==t?void 0:t.type)??"",!1),[g,null==t?void 0:t.type]),f=(0,n.useMemo)(()=>g.getDynamicTypes().map(e=>{let{id:t,label:a}=e;return{value:t,label:u(a)}}),[g]);return(0,i.jsxs)(s.Flex,{className:m.fieldsContainer,gap:6,vertical:!0,children:[(0,i.jsxs)("div",{children:[(0,i.jsx)("div",{className:m.fieldLabel,children:u("data-importer.mapping.advanced-modal.step-target.type")}),(0,i.jsx)("div",{className:m.selectSkeletonWrapper,children:(0,i.jsx)(s.Select,{className:m.selectFull,onChange:function(e){var a;let r=g.getDynamicType(e??"",!1),i=(null==r||null==(a=r.getDefaultSettings)?void 0:a.call(r,null==t?void 0:t.settings))??(null==t?void 0:t.settings)??{};p({...t,type:e,settings:i})},options:f,value:null==t?void 0:t.type})})]}),void 0!==h?h.supportsType(a)?h.renderSettings({classId:o,transformationResultType:a,settings:null==t?void 0:t.settings,onChange:e=>{p({...t,settings:e})},isLocalized:c,classFieldOptions:d}):(0,i.jsx)(tZ,{children:null==h?void 0:h.getTypeErrorMessage(u)}):(0,i.jsx)(i.Fragment,{})]})},ar=e=>{let{classId:t,transformationResultType:a,dataTarget:r,onDataTargetChange:o}=e,{t:d}=(0,l.useTranslation)(),{styles:c}=ae(),{classFieldOptions:p,isLocalized:u}=function(e){var t;let{attributesMap:a,transformationResultType:r,dataTarget:i,onDataTargetChange:o}=e,{isFetchingAttributes:l,calculateTypeError:s}=t1(),d=(0,n.useMemo)(()=>a[tO(r)]??[],[a,r]),c=(0,n.useMemo)(()=>(s??"")!==""?[]:d.map(e=>({value:e.key,label:e.title})),[s,d]),p=(0,n.useMemo)(()=>{var e;return(null==(e=d.find(e=>{var t;return e.key===(null==i||null==(t=i.settings)?void 0:t.fieldName)}))?void 0:e.localized)??!1},[d,null==i||null==(t=i.settings)?void 0:t.fieldName]);return(0,n.useEffect)(()=>{var e;let t=null==i?void 0:i.type,a=null==i||null==(e=i.settings)?void 0:e.fieldName;"classificationstore"!==t&&"classificationstoreBatch"!==t&&!l&&void 0!==a&&(c.some(e=>e.value===a)||o({...i,settings:{...null==i?void 0:i.settings,fieldName:void 0,language:void 0}}))},[c,l]),{classFieldOptions:c,isLocalized:p}}(e);return(0,i.jsxs)(s.Flex,{className:c.twoColumnLayout,gap:"extra-small",children:[(0,i.jsxs)(s.Flex,{className:c.leftColumn,vertical:!0,children:[(0,i.jsx)(s.Flex,{align:"center",className:c.leftHeader,children:(0,i.jsx)(s.Text,{className:c.leftHeaderTitle,strong:!0,children:d("data-importer.mapping.advanced-modal.step-target")})}),(0,i.jsx)(aa,{classFieldOptions:p,classId:t,dataTarget:r,isLocalized:u,onDataTargetChange:o,transformationResultType:a})]}),(0,i.jsx)(at,{})]})},ai=(0,p.createStyles)(e=>{let{css:t,token:a}=e;return{sectionPanel:t`
      & .ant-collapse.collapse-item--theme-default {
        background-color: ${a.colorFillAlter};

        & .ant-collapse-content {
          background-color: ${a.colorBgContainer};
        }
      }
    `,stepBadge:t`
      display: inline-flex;
      align-items: center;
      justify-content: center;
      min-width: 20px;
      height: 20px;
      padding: 0 6px;
      border-radius: 10px;
      background-color: ${a.colorPrimary};
      color: ${a.colorTextLightSolid};
      font-size: ${a.fontSizeSM}px;
      font-weight: ${a.fontWeightStrong};
      line-height: 20px;
      margin-inline-end: ${a.marginXXS}px;
    `,footer:t`
      border-top: 1px solid ${a.colorBorderSecondary};
      padding-top: ${a.paddingSM}px;
      margin-top: ${a.paddingXXS}px;
    `}});function an(e){return{key:e.key??e.name??"",title:e.title??e.name??e.key??"",localized:!!e.localized}}let ao=e=>{var t;let{open:a,onClose:r,onSave:o,configName:d,classId:c,item:p,columnHeaderOptions:u,attributesMap:m,baseConfig:g}=e,{t:h}=(0,l.useTranslation)(),{styles:f}=ai(),[x,v]=(0,n.useState)(()=>structuredClone(p)),[y,b]=(0,n.useState)({source:!0,transformations:!1,target:!1}),[j,S]=(0,n.useState)(0),[C,I]=(0,n.useState)(0),w=(0,n.useRef)(null),T=(0,n.useCallback)(()=>{null!==w.current&&clearTimeout(w.current),w.current=setTimeout(()=>{S(e=>e+1),w.current=null},800)},[]),D=tj(),[N,k]=(0,n.useState)(void 0),{data:$,isFetching:L,error:M,refetch:P}=e5(N,{skip:void 0===N,refetchOnMountOrArgChange:!1});(0,n.useEffect)(()=>{void 0!==$&&v(e=>({...e,transformationResultType:$.type}))},[$]);let R=void 0!==M?null==(t=M.data)?void 0:t.detail:void 0;(0,n.useEffect)(()=>{a&&(v(structuredClone(p)),b({source:!0,transformations:!1,target:!1}))},[a,p]);let A=e=>{b(t=>({source:!1,transformations:!1,target:!1,[e]:!t[e]}))},O=x.transformationPipeline??[],E=e=>{v(t=>({...t,dataSourceIndex:e})),T()},B=(0,n.useRef)(x);B.current=x;let{mergedAttributesMap:z,isFetchingExtraAttributes:H}=function(e){let{open:t,configName:a,classId:r,localItem:i,localItemRef:o,attributesMap:l,setCalculateTypeRequest:s}=e,d=JSON.stringify(i.transformationPipeline??[]),c=JSON.stringify(i.dataSourceIndex??[]),p=(0,n.useRef)(!0),u=tj();(0,n.useEffect)(()=>{if(!t){p.current=!0;return}if(p.current){p.current=!1;return}let e=o.current??{};s({name:a,bundleDataImporterCalculateTransformationResultTypeParameters:{previewScope:u,currentConfig:{label:e.label,dataSourceIndex:e.dataSourceIndex,transformationPipeline:e.transformationPipeline,dataTarget:e.dataTarget}}})},[d,c,t,a,u,o,s]);let m=tO(i.transformationResultType),g=m!==tA&&void 0===l[m],{data:h,isFetching:f}=ts({classId:r??"",transformationResultType:i.transformationResultType,systemWrite:!0},{skip:!g||void 0===r||""===r});return{mergedAttributesMap:(0,n.useMemo)(()=>{if(!g||(null==h?void 0:h.attributes)===void 0)return l;let e=h.attributes.map(an);return{...l,[m]:e}},[l,g,h,m]),isFetchingExtraAttributes:g&&f}}({open:a,configName:d,classId:c,localItem:x,localItemRef:B,attributesMap:m,setCalculateTypeRequest:k}),q=(0,n.useCallback)(async()=>{let e=B.current,t={name:d,bundleDataImporterCalculateTransformationResultTypeParameters:{previewScope:D,currentConfig:{label:e.label,dataSourceIndex:e.dataSourceIndex,transformationPipeline:e.transformationPipeline,dataTarget:e.dataTarget}}},a=JSON.stringify(N)===JSON.stringify(t);if(k(t),a)try{await P()}catch{}},[d,N,P,D]),W=(0,n.useCallback)(()=>{q(),I(e=>e+1)},[q]),V=F();return(0,i.jsx)(s.Modal,{footer:(0,i.jsxs)(s.Flex,{align:"center",className:f.footer,gap:"extra-small",justify:"flex-end",children:[(0,i.jsx)(s.IconButton,{disabled:L,icon:{value:"refresh"},onClick:W,tooltip:{title:h("data-importer.mapping.advanced-modal.refresh-all-previews")}}),!V&&(0,i.jsx)(s.Button,{onClick:()=>{o(x),r()},type:"primary",children:h("data-importer.mapping.advanced-modal.save")})]}),onCancel:r,open:a,title:h("data-importer.mapping.advanced-modal.title"),width:996,children:(0,i.jsx)(t2,{baseConfig:g,calculateTypeError:R,configName:d,currentMappingItem:x,forceRefreshToken:C,isFetchingAttributes:H||L,previewRefreshToken:j,children:(0,i.jsxs)(s.Flex,{gap:"small",vertical:!0,children:[(0,i.jsx)("div",{className:f.sectionPanel,children:(0,i.jsx)(s.Panel,{active:y.source,collapsible:!0,onChange:()=>{A("source")},theme:"default",title:(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)("span",{className:f.stepBadge,children:"1"}),h("data-importer.mapping.advanced-modal.step-source")]}),children:(0,i.jsx)(tH,{columnHeaderOptions:u,configName:d,dataSourceIndex:x.dataSourceIndex??[],forceRefreshToken:C,onDataSourceIndexChange:E})})}),(0,i.jsx)("div",{className:f.sectionPanel,children:(0,i.jsx)(s.Panel,{active:y.transformations,collapsible:!0,onChange:()=>{A("transformations")},theme:"default",title:(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)("span",{className:f.stepBadge,children:"2"}),h("data-importer.mapping.advanced-modal.step-transformations")]}),children:(0,i.jsx)(t7,{columnHeaderOptions:u,dataSourceIndex:x.dataSourceIndex??[],onDataSourceIndexChange:E,onPipelineChange:e=>{v(t=>({...t,transformationPipeline:e})),T()},pipeline:O})})}),(0,i.jsx)("div",{className:f.sectionPanel,children:(0,i.jsx)(s.Panel,{active:y.target,collapsible:!0,onChange:()=>{A("target")},theme:"default",title:(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)("span",{className:f.stepBadge,children:"3"}),h("data-importer.mapping.advanced-modal.step-target")]}),children:(0,i.jsx)(ar,{attributesMap:z,classId:c,dataTarget:x.dataTarget,onDataTargetChange:e=>{v(t=>({...t,dataTarget:e}))},transformationResultType:x.transformationResultType})})})]})})})},al=e=>{let{children:t,className:a}=e,{getStateClasses:r}=(0,s.useDroppable)();return(0,i.jsx)("div",{className:$()(a,...r()),children:t})};var as=a(5710);let ad=e=>{let{fill:t}=e;return(0,i.jsx)("svg",{fill:"none",height:"12",viewBox:"0 0 26 12",width:"26",xmlns:"http://www.w3.org/2000/svg",children:(0,i.jsx)("path",{d:"M25.5303 6.05377C25.8232 5.76087 25.8232 5.286 25.5303 4.99311L20.7574 0.220137C20.4645 -0.0727568 19.9896 -0.0727568 19.6967 0.220137C19.4038 0.51303 19.4038 0.987904 19.6967 1.2808L23.9393 5.52344L19.6967 9.76608C19.4038 10.059 19.4038 10.5338 19.6967 10.8267C19.9896 11.1196 20.4645 11.1196 20.7574 10.8267L25.5303 6.05377ZM0 5.52344V6.27344H25V5.52344V4.77344H0V5.52344Z",fill:t,fillOpacity:1})})},ac=e=>{let{isAdvanced:t,isWarningState:a,isInProgressState:r}=e,{styles:n}=tM(),{token:o}=as.A.useToken(),l=t||a||r,d=a||r?o.colorWarning:o.colorIcon,c=(0,i.jsx)("span",{className:n.arrowSvg,children:(0,i.jsx)(ad,{fill:d})});return l?(0,i.jsxs)("div",{className:$()(n.arrowCol,n.arrowColAdvanced),children:[t&&!a&&!r&&(0,i.jsx)("span",{className:n.arrowAdvancedIcon,children:(0,i.jsx)(s.Icon,{value:"transformation"})}),(a||r)&&(0,i.jsx)("span",{className:n.arrowWarningBadge,children:(0,i.jsx)(s.Icon,{value:"warning-circle"})}),c]}):(0,i.jsxs)("div",{className:$()(n.arrowCol,n.arrowColSimple),children:[(0,i.jsx)("div",{className:n.arrowLabelSpacer}),(0,i.jsx)("div",{className:n.arrowSelectRow,children:c})]})},ap=o().memo(e=>{let{fieldIndex:t,itemLabel:a,dataSourceIndex:r,isAdvanced:o,isInProgressState:d,isWarningState:c,selectedAttr:p,selectedFieldName:u,isLocalized:m,language:g,columnHeaderOptions:h,attributeOptions:f,languageOptions:x,onOpenAdvanced:v,onRemove:y}=e,b=F(),{t:j}=(0,l.useTranslation)(),{styles:S}=tM(),C=s.Form.useFormInstance(),[I,w]=(0,n.useState)(!1),[T,D]=(0,n.useState)(!1),N=(0,n.useMemo)(()=>{if(0===(r??[]).length)return[];let e=new Set(r);return h.filter(t=>e.has(t.value))},[r,h]),k=I?h:N,$=(0,n.useMemo)(()=>void 0===u||""===u?[]:[{value:u,label:(null==p?void 0:p.title)??u}],[p,u]);return(0,n.useEffect)(()=>{if(!0!==globalThis.__DI_MAPPING_DEBUG__)return;let e=performance.now();requestAnimationFrame(()=>{console.debug("[DI][Perf] mapping item content painted",{fieldIndex:t,expandedState:"expanded",durationMs:Number((performance.now()-e).toFixed(2))})})},[t]),(0,i.jsxs)("div",{className:S.mappingItemContent,children:[(0,i.jsxs)("div",{className:S.mappingLabelRow,children:[(0,i.jsx)("div",{className:S.mappingLabelInput,style:{flex:1},children:(0,i.jsx)(s.Input,{onChange:e=>{C.setFieldValue(["mappingConfig",t,"label"],e.target.value,{triggerChange:!0})},placeholder:j("data-importer.mapping.item.label"),value:a??""})}),(0,i.jsx)(tC.Ay,{componentDisabled:!1,children:(0,i.jsx)(s.IconTextButton,{disabled:!1,icon:{value:"transformation"},onClick:v,type:"default",children:j("data-importer.mapping.item.advanced")})}),!b&&(0,i.jsx)(s.IconButton,{icon:{value:"trash"},onClick:y,tooltip:{title:j("data-importer.mapping.item.delete")},type:"default"})]}),(0,i.jsx)("div",{className:S.mappingDivider}),(0,i.jsxs)("div",{className:S.sourcesDestRow,children:[(0,i.jsxs)("div",{className:S.sourcesDestCol,children:[(0,i.jsx)("div",{children:j("data-importer.mapping.item.source")}),(0,i.jsx)("div",{className:S.sourceDropZone,children:(0,i.jsx)(s.Select,{filterOption:E,mode:"multiple",onChange:e=>{C.setFieldValue(["mappingConfig",t,"dataSourceIndex"],e,{triggerChange:!0}),e.length>1&&(C.setFieldValue(["mappingConfig",t,"transformationResultType"],"default"),C.setFieldValue(["mappingConfig",t,"dataTarget","settings","fieldName"],void 0),C.setFieldValue(["mappingConfig",t,"dataTarget","settings","language"],void 0))},onFocus:()=>{w(!0)},options:k,placeholder:j("data-importer.mapping.item.source-placeholder"),showSearch:!0,style:{maxWidth:"100%"},value:r??[]})})]}),(0,i.jsx)(ac,{isAdvanced:o,isInProgressState:d,isWarningState:c}),(0,i.jsxs)("div",{className:S.sourcesDestCol,children:[(0,i.jsx)("div",{children:j("data-importer.mapping.item.destination")}),o&&(0,i.jsx)("div",{className:S.destinationTextBlock,children:(0,i.jsx)("span",{children:(null==p?void 0:p.title)??u??""})}),!o&&d&&(0,i.jsx)("div",{className:S.requiresAdvancedHint,children:j("data-importer.mapping.item.requires-advanced-setup")}),!o&&!d&&(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(s.Select,{filterOption:E,onChange:e=>{C.setFieldValue(["mappingConfig",t,"dataTarget","settings","fieldName"],e,{triggerChange:!0})},onFocus:()=>{D(!0)},options:T?f:$,placeholder:j("data-importer.mapping.item.destination-placeholder"),showSearch:!0,style:{maxWidth:"100%"},value:u??void 0}),m&&(0,i.jsx)(s.Select,{filterOption:E,onChange:e=>{C.setFieldValue(["mappingConfig",t,"dataTarget","settings","language"],e,{triggerChange:!0})},options:x,placeholder:j("data-importer.mapping.item.data-target.language-placeholder"),showSearch:!0,style:{maxWidth:"100%"},value:g??void 0})]})]})]})]})});ap.displayName="MappingItemContent";let au=s.FormAnnotationsProvider,am="function"==typeof au?au:null,ag=s.useFormItemAnnotation,ah="function"==typeof ag?ag:()=>void 0,af={added:"green",changed:"gold",removed:"red",moved:"geekblue"},ax=e=>{let{status:t}=e,{t:a}=(0,l.useTranslation)();return(0,i.jsx)(s.Tag,{color:af[t],"data-review-mark":"",style:{marginInlineEnd:0},children:a(`data-importer.review.status.${t}`)})},av=o().memo(e=>{let t,{fieldIndex:a,mappingId:r,remove:d,onRemoveItem:p,configName:u,columnHeaderOptions:m,classId:g,expanded:h,onToggle:f,itemLabel:x,dataSourceIndex:v,transformationResultType:y,selectedFieldName:b,language:j,attributesMap:S}=e,C=o().useRef(0);C.current+=1,!0===globalThis.__DI_MAPPING_DEBUG__&&(1===C.current||C.current%50==0)&&console.debug("[DI][MappingItem] render",{fieldIndex:a,mappingId:r,renderCount:C.current,expanded:h,hasDataSource:(v??[]).length>0,trt:y??"default"});let{t:I}=(0,l.useTranslation)(),{styles:w,cx:T}=tM(),D=s.Form.useFormInstance(),[N,F]=(0,n.useState)(!1),k=(0,c.useSettings)(),$=(0,n.useMemo)(()=>(k.validLanguages??[]).map(e=>({value:e,label:e})),[k.validLanguages]),L=(v??[]).length,M=void 0!==b&&""!==b,P=(0,n.useCallback)(()=>(D.getFieldValue("mappingConfig")??[]).findIndex(e=>e.mappingId===r),[D,r]);(0,n.useEffect)(()=>{if(!h)return;let e=P();if(e<0)return;let t=D.getFieldValue(["mappingConfig",e])??{},a=t.label??"",r=t.dataSourceIndex??[];if(""===a&&r.length>0){let t=m.find(e=>e.value===r[0]);void 0!==t&&D.setFieldValue(["mappingConfig",e,"label"],t.label,{triggerChange:!0})}},[h,m,D,P]);let R=S[tO(y)]??[],A=(0,n.useMemo)(()=>h?R.map(e=>({value:e.key,label:e.title})):[],[h,R]),O=(0,n.useMemo)(()=>{if(h)return R.find(e=>e.key===b)},[h,R,b]),E=(null==O?void 0:O.localized)??!1,B=void 0!==x&&""!==x?x:I("data-importer.mapping.item.new-label"),z=ah(["mappingConfig",a]),H=void 0===z?B:(0,i.jsxs)("span",{className:w.annotatedTitle,children:[(0,i.jsx)("span",{className:"removed"===z.status?w.removedTitle:void 0,children:B}),(0,i.jsx)(ax,{status:z.status})]}),q=(0,n.useCallback)(e=>{let t=P();if(t<0)return;let a=e.data.dataIndex,r=D.getFieldValue(["mappingConfig",t,"dataSourceIndex"])??[];if(!r.includes(a)){let e=[...r,a];D.setFieldValue(["mappingConfig",t,"dataSourceIndex"],e,{triggerChange:!0}),e.length>1&&(D.setFieldValue(["mappingConfig",t,"transformationResultType"],"default"),D.setFieldValue(["mappingConfig",t,"dataTarget","settings","fieldName"],void 0),D.setFieldValue(["mappingConfig",t,"dataTarget","settings","language"],void 0))}},[D,P]),W=(0,n.useCallback)(()=>{F(!0)},[]),V=(0,n.useCallback)(()=>{p(a)},[p,a]);return(0,i.jsxs)(s.Droppable,{className:w.droppablePanel,disableDndActiveIndicator:!1,isValidContext:e=>e.type===tP,onDrop:q,variant:"default",children:[(0,i.jsx)(al,{className:T(w.panelDndWrapper,h&&w.panelExpanded),children:(0,i.jsx)(s.Panel,{active:h,border:!0,collapsible:!0,contentPadding:"none",onChange:f,theme:"default",title:H,children:h&&(0,i.jsx)(ap,{attributeOptions:A,columnHeaderOptions:m,dataSourceIndex:v,fieldIndex:a,isAdvanced:void 0!==y&&""!==y&&"default"!==y,isInProgressState:L>1&&!M,isLocalized:E,isWarningState:L>0&&!M,itemLabel:x,language:j,languageOptions:$,onOpenAdvanced:W,onRemove:V,selectedAttr:O,selectedFieldName:b})})}),N&&(0,i.jsx)(ao,{attributesMap:S,baseConfig:{loaderConfig:D.getFieldsValue(!0).loaderConfig,interpreterConfig:D.getFieldsValue(!0).interpreterConfig,resolverConfig:D.getFieldsValue(!0).resolverConfig,processingConfig:D.getFieldsValue(!0).processingConfig},classId:g,columnHeaderOptions:m,configName:u,item:(t=P())<0?{}:D.getFieldValue(["mappingConfig",t])??{},onClose:()=>{F(!1)},onSave:e=>{let t=P();t<0||D.setFieldValue(["mappingConfig",t],e,{triggerChange:!0}),F(!1)},open:N})]})},function(e,t){if(!e.expanded&&!t.expanded)return e.expanded===t.expanded&&e.fieldIndex===t.fieldIndex&&e.mappingId===t.mappingId&&e.itemLabel===t.itemLabel&&e.onToggle===t.onToggle&&e.onRemoveItem===t.onRemoveItem&&e.remove===t.remove;let a=e.dataSourceIndex,r=t.dataSourceIndex,i=a===r||void 0!==a&&a.length===(null==r?void 0:r.length)&&a.every((e,t)=>e===r[t]);return e.fieldIndex===t.fieldIndex&&e.mappingId===t.mappingId&&e.remove===t.remove&&e.onRemoveItem===t.onRemoveItem&&e.configName===t.configName&&e.columnHeaderOptions===t.columnHeaderOptions&&e.classId===t.classId&&e.expanded===t.expanded&&e.onToggle===t.onToggle&&e.itemLabel===t.itemLabel&&i&&e.transformationResultType===t.transformationResultType&&e.selectedFieldName===t.selectedFieldName&&e.language===t.language&&e.attributesMap===t.attributesMap});function ay(e,t){return void 0!==e&&(null===t||e===t)}av.displayName="MappingItem";let ab=e=>{let{insertIndex:t,add:a,onInsertItem:r,onDropped:o,acceptedDataIndex:l}=e,{styles:d}=tM(),c=(0,n.useCallback)(e=>{let{dataIndex:i,label:n}=e.data;r(a,t,i,n),o(t)},[a,t,r,o]);return(0,i.jsx)(s.Droppable,{className:d.mappingDropZoneWrapper,disableDndActiveIndicator:!1,isValidContext:e=>e.type===tP&&ay(e.data.dataIndex,l??null),onDrop:c,variant:"default",children:(0,i.jsx)(al,{className:d.mappingDropZone})})},aj=(0,n.createContext)({configName:"",classId:void 0,columnHeaderOptions:[],attributesMap:{},sourceRows:[]}),aS=aj.Provider,aC=o().memo(e=>{var t,a,r,l;let{fieldIndex:d,mappingId:c,insertIndex:p,remove:u,onRemoveItem:m,expanded:g,onToggle:h,activeFilter:f,isNew:x,add:v,onDropped:y,onInsertItem:b,acceptedDataIndex:j}=e,S=o().useRef(0);S.current+=1,!0===globalThis.__DI_MAPPING_DEBUG__&&(1===S.current||S.current%50==0)&&console.debug("[DI][MappingItemWithFilter] render",{fieldIndex:d,mappingId:c,renderCount:S.current,expanded:g,activeFilter:f});let{configName:C,classId:I,columnHeaderOptions:w,attributesMap:T}=(0,n.useContext)(aj),{styles:D,cx:N}=tM(),F=s.Form.useFormInstance(),k=(0,n.useRef)(d);k.current=d,s.Form.useWatch(e=>{var t;return null==e||null==(t=e.mappingConfig)?void 0:t[k.current]});let $=F.getFieldValue(["mappingConfig",d])??{},L=$.dataSourceIndex,M=null!==f&&!(L??[]).includes(f);return(0,i.jsxs)("div",{className:N(M&&D.hiddenItem),children:[(0,i.jsx)(ab,{acceptedDataIndex:j,add:v,insertIndex:p,onDropped:y,onInsertItem:b}),(0,i.jsx)("div",{className:N(x&&D.mappingItemNew),children:(0,i.jsx)(av,{attributesMap:T,classId:I,columnHeaderOptions:w,configName:C,dataSourceIndex:L,expanded:g,fieldIndex:d,itemLabel:$.label,language:null==(a=$.dataTarget)||null==(t=a.settings)?void 0:t.language,mappingId:c,onRemoveItem:m,onToggle:h,remove:u,selectedFieldName:null==(l=$.dataTarget)||null==(r=l.settings)?void 0:r.fieldName,transformationResultType:$.transformationResultType})})]})});aC.displayName="MappingItemWithFilter";let aI=e=>{let{add:t,onInsertItem:a,onDropped:r}=e,{t:o}=(0,l.useTranslation)(),{styles:d}=tM(),c=(0,n.useCallback)(e=>{let{dataIndex:i,label:n}=e.data;a(t,0,i,n),r(0)},[t,a,r]);return(0,i.jsx)(s.Droppable,{className:d.emptyState,disableDndActiveIndicator:!1,isValidContext:e=>e.type===tP,onDrop:c,variant:"default",children:(0,i.jsx)(al,{className:d.emptyStateInner,children:(0,i.jsx)("span",{children:o("data-importer.mapping.empty-state")})})})},aw=e=>{let{activeFilter:t,activeFilterLabel:a,fields:r,onAddMappingForFilter:o,add:d,onInsertItem:c,onDropped:p}=e,{t:u}=(0,l.useTranslation)(),{styles:m}=tM(),g=s.Form.useWatch(e=>JSON.stringify((e.mappingConfig??[]).map(e=>e.dataSourceIndex??[]))),h=(0,n.useMemo)(()=>void 0!==g?JSON.parse(g):[],[g]),f=(0,n.useCallback)(e=>{let{dataIndex:a,label:i}=e.data;ay(a,t)&&(c(d,r.length,a,i),p(r.length))},[t,c,d,r.length,p]);return h.some(e=>e.includes(t))?null:(0,i.jsx)(s.Droppable,{className:m.filterEmptyState,disableDndActiveIndicator:!1,isValidContext:e=>e.type===tP&&ay(e.data.dataIndex,t),onDrop:f,variant:"default",children:(0,i.jsxs)(al,{className:m.filterEmptyStateInner,children:[(0,i.jsx)("span",{children:u("data-importer.mapping.filter-empty",{source:a??t})}),(0,i.jsx)(s.IconTextButton,{icon:{value:"add"},onClick:o,type:"default",children:u("data-importer.mapping.add")})]})})};function aT(){return!0===globalThis.__DI_MAPPING_DEBUG__}let aD=o().memo(e=>{let{fields:t,add:a,remove:r,hasItems:d,flashIndex:c,activeFilter:p,activeFilterLabel:u,expandedKeys:m,allVisibleCollapsed:g,onCollapseAll:h,onNewKey:f,onToggleKey:x,onOpenAutofillSuggestions:v,onAddItem:y,onRemoveItem:b,onAddMappingForFilter:j,onInsertItem:S,onDropped:C,getMappingIdByIndex:I}=e,w=F(),{t:T}=(0,l.useTranslation)(),{styles:D}=tM(),N=(0,n.useRef)(0);N.current+=1,aT()&&(1===N.current||N.current%20==0)&&console.debug("[DI][MappingsPanelContent] render",{renderCount:N.current,fieldCount:t.length,activeFilter:p,flashIndex:c,expandedMode:"all"===m?"all":"set"});let k=(0,n.useRef)(new Set(t.map(e=>e.key)));(0,n.useLayoutEffect)(()=>{let e=aT(),a=new Set(t.map(e=>e.key)),r=k.current,i=Array.from(a).filter(e=>!r.has(e));1===i.length?f(i[0]):e&&i.length>1&&console.debug("[DI][MappingsPanelContent] skip auto-expand for bulk add",{addedKeyCount:i.length,fieldCount:t.length}),k.current=a},[t,f]);let $=(0,n.useMemo)(()=>t.map(e=>e.key),[t]),L=(0,n.useCallback)(e=>()=>{b(r,e)},[b,r]),M=(0,n.useRef)(x),P=(0,n.useRef)(t);M.current=x,P.current=t;let R=(0,n.useRef)(new Map),A=(0,n.useCallback)(e=>(R.current.has(e)||R.current.set(e,()=>{let t=P.current.map(e=>e.key);M.current(e,t)}),R.current.get(e)),[]),O=(0,n.useMemo)(()=>{let e=aT(),n=e?performance.now():0,l=p??void 0,s=t.map((e,t)=>{let n=I(e.name),s="all"===m||m.has(e.key);return(0,i.jsx)(o().Fragment,{children:(0,i.jsx)(aC,{acceptedDataIndex:l,activeFilter:p,add:a,expanded:s,fieldIndex:e.name,insertIndex:t,isNew:c===t,mappingId:n,onDropped:C,onInsertItem:S,onRemoveItem:L(e.name),onToggle:A(e.key),remove:r})},e.key)});return e&&console.debug("[DI][MappingsPanelContent] itemList built",{itemCount:s.length,durationMs:Number((performance.now()-n).toFixed(2)),activeFilter:p}),s},[t,a,r,p,m,c,C,S,L,A,I]);return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsxs)(s.Flex,{align:"center",className:D.mappingsHeader,gap:"small",children:[(0,i.jsx)(s.Text,{className:D.mappingsTitle,children:T("data-importer.mapping.title-short")}),(0,i.jsxs)(s.Flex,{align:"center",className:D.mappingsActions,gap:"extra-small",children:[!w&&(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(s.IconTextButton,{icon:{value:"new"},onClick:()=>{y(a,t.length)},type:"default",children:T("data-importer.mapping.add")}),(0,i.jsx)(s.Divider,{className:D.mappingsDivider,type:"vertical"}),(0,i.jsx)(s.IconTextButton,{icon:{value:"autofill"},onClick:v,type:"default",children:T("data-importer.mapping.auto-fill")})]}),d&&(0,i.jsx)(s.Button,{onClick:()=>{h($)},size:"small",style:{marginLeft:"auto"},type:"link",children:T(g?"data-importer.mapping.expand-all":"data-importer.mapping.collapse-all")})]})]}),(0,i.jsxs)(s.Flex,{className:D.mappingsContent,vertical:!0,children:[!d&&null===p&&(0,i.jsx)(aI,{add:a,onDropped:C,onInsertItem:S}),O,d&&(0,i.jsx)(ab,{acceptedDataIndex:p??void 0,add:a,insertIndex:t.length,onDropped:C,onInsertItem:S}),null!==p&&(0,i.jsx)(aw,{activeFilter:p,activeFilterLabel:u,add:a,fields:t,onAddMappingForFilter:()=>{j(a)},onDropped:C,onInsertItem:S})]})]})});aD.displayName="MappingsPanelContent";let aN=e=>{let{activeFilter:t,activeFilterLabel:a,expandedKeys:r,expandAllPending:o,onCollapseAll:l,onNewKey:d,onToggleKey:c,onOpenAutofillSuggestions:p,onAddItem:u,onRemoveItem:m,onAddMappingForFilter:g,onInsertItem:h,getMappingIdByIndex:f}=e,{styles:x}=tM(),[v,y]=(0,n.useState)(null),b=(0,n.useRef)(null),j=(0,n.useCallback)(e=>{null!==b.current&&clearTimeout(b.current),y(e),b.current=setTimeout(()=>{y(null)},400)},[]),S=(0,n.useRef)(()=>void 0),C=(0,n.useRef)(()=>void 0),I=(0,n.useMemo)(()=>(e,t)=>{S.current(e,t)},[]),w=(0,n.useMemo)(()=>e=>{C.current(e)},[]),T=(0,n.useRef)([]),D=(0,n.useCallback)(e=>{let t=T.current;return t.length===e.length&&e.every((e,a)=>e.key===t[a].key&&e.name===t[a].name)?t:(T.current=e,e)},[]);return(0,i.jsx)(s.Flex,{className:x.panel,vertical:!0,children:(0,i.jsx)(s.Form.List,{name:"mappingConfig",children:(e,n)=>{let{add:s,remove:x}=n;S.current=s,C.current=x;let y=D(e),b=y.length>0,T=!o&&"all"!==r&&y.every(e=>!r.has(e.key));return(0,i.jsx)(aD,{activeFilter:t,activeFilterLabel:a,add:I,allVisibleCollapsed:T,expandedKeys:r,fields:y,flashIndex:v,getMappingIdByIndex:f,hasItems:b,onAddItem:u,onAddMappingForFilter:g,onCollapseAll:l,onDropped:j,onInsertItem:h,onNewKey:d,onOpenAutofillSuggestions:p,onRemoveItem:m,onToggleKey:c,remove:w})}})})},aF=e=>{let{options:t,valueRef:a,errorRef:r}=e,{t:o}=(0,l.useTranslation)(),[d,c]=(0,n.useState)(void 0),[p,u]=(0,n.useState)(!1);return r.current=u,(0,i.jsx)(s.Form.Item,{help:p?o("data-importer.mapping.new-modal.source-required"):void 0,label:o("data-importer.mapping.new-modal.source-label"),required:!0,style:{marginTop:12,marginBottom:0},validateStatus:p?"error":void 0,children:(0,i.jsx)(s.Select,{allowClear:!0,filterOption:E,onChange:e=>{c(e),a.current=e,void 0!==e&&u(!1)},options:t,placeholder:o("data-importer.mapping.item.source-placeholder"),showSearch:!0,style:{width:"100%"},value:d})})};function ak(){return!0===globalThis.__DI_MAPPING_DEBUG__}let a$=["array","boolean","date","quantityValue","asset","assetArray","gallery","dataObject","dataObjectArray"];function aL(e,t){let a=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"manual",r=arguments.length>3?arguments[3]:void 0,i=arguments.length>4?arguments[4]:void 0,n=arguments.length>5?arguments[5]:void 0;return{mappingId:(0,x.uuid)(),label:t,dataSourceIndex:[e],transformationResultType:"autofill"===a?n??"default":void 0,dataTarget:{type:"direct",settings:{..."autofill"===a&&{fieldName:r??e},...void 0!==i&&""!==i&&{language:i},writeIfTargetIsNotEmpty:!0,writeIfSourceIsEmpty:!0}}}}let aM=()=>(0,i.jsxs)("svg",{fill:"none",height:"38",viewBox:"0 0 38 38",width:"38",xmlns:"http://www.w3.org/2000/svg",children:[(0,i.jsxs)("g",{clipPath:"url(#panel-arrow-clip)",children:[(0,i.jsx)("path",{d:"M26.9167 12.6641L33.25 18.9974L26.9167 25.3307",stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2"}),(0,i.jsx)("path",{d:"M33.25 19L24.7095 19C22.9533 19.0001 21.2242 18.5666 19.6758 17.738C18.1274 16.9094 16.8075 15.7113 15.8333 14.25C14.8592 12.7887 13.5393 11.5906 11.9909 10.762C10.4424 9.93337 8.71337 9.49988 6.95717 9.5L4.75 9.5",stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2"}),(0,i.jsx)("path",{d:"M33.25 19L24.7095 19C22.9533 18.9999 21.2242 19.4334 19.6758 20.262C18.1274 21.0906 16.8075 22.2887 15.8333 23.75C14.8592 25.2113 13.5393 26.4094 11.9909 27.238C10.4424 28.0666 8.71337 28.5001 6.95717 28.5L4.75 28.5",stroke:"currentColor",strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:"2"})]}),(0,i.jsx)("defs",{children:(0,i.jsx)("clipPath",{id:"panel-arrow-clip",children:(0,i.jsx)("rect",{fill:"white",height:"38",transform:"translate(38 1.66103e-06) rotate(90)",width:"38"})})})]});function aP(e){return e.toLowerCase().replace(/[^a-z0-9]/g,"")}function aR(e){return e.split(/(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])|[\s_.-]+/).map(e=>e.toLowerCase()).filter(e=>e.length>0)}function aA(e,t){if(0===e.length&&0===t.length)return 1;if(e.length<2||t.length<2)return+(e===t);let a=new Set,r=new Set;for(let t=0;t<e.length-1;t++)a.add(e.slice(t,t+2));for(let e=0;e<t.length-1;e++)r.add(t.slice(e,e+2));let i=0;a.forEach(e=>{r.has(e)&&i++});let n=a.size+r.size-i;return 0===n?0:i/n}function aO(e,t){if(0===e.length&&0===t.length)return 1;let a=new Set(e),r=new Set(t),i=0;a.forEach(e=>{r.has(e)&&i++});let n=a.size+r.size-i;return 0===n?0:i/n}function aE(e,t){let a=aP(e),r=aP(t.title),i=aP(t.key),n=t.key.lastIndexOf("."),o=n>=0?t.key.slice(n+1):null,l=null!==o?aP(o):null;if(a===r||a===i||null!==l&&a===l)return 100;let s=aR(e),d=aR(t.title),c=aR(t.key),p=Math.max(aO(s,d),aO(s,c),aA(a,r),aA(a,i));return null!==o&&null!==l&&(p=Math.max(p,aO(s,aR(o)),aA(a,l))),Math.round(100*p)}let aB=(0,p.createStyles)(e=>{let{css:t,token:a}=e;return{tableHeaderRow:t`
      padding: ${a.paddingXXS}px ${a.paddingMD}px;
      border-bottom: 1px solid ${a.colorBorderSecondary};
    `,tableHeaderCell:t`
      color: ${a.colorTextSecondary};
      white-space: nowrap;
    `,tableRow:t`
      padding: ${a.paddingXXS}px ${a.paddingMD}px;
      min-height: 36px;

      &:hover {
        background: ${a.colorFillAlter};
        cursor: pointer;
      }
    `,sourceCell:t`
      flex: 1.5;
      min-width: 0;
      overflow: hidden;
    `,destinationCell:t`
      flex: 2.5;
      min-width: 0;
      overflow: hidden;
    `,localeTag:t`
      flex-shrink: 0;
      font-size: ${a.fontSizeSM}px;
      background-color: ${a.colorPrimaryBg} !important;
      color: ${a.colorPrimary} !important;
      border-color: ${a.colorPrimaryBorder} !important;
    `,resultCell:t`
      flex: 2;
      min-width: 0;
      color: ${a.colorTextDescription};
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    `,cellText:t`
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    `,emptyState:t`
      padding: ${a.paddingXL}px ${a.paddingMD}px;
    `,scoreText:t`
      white-space: nowrap;
    `,dotGreen:t`
      display: inline-block;
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background-color: ${a.colorSuccess};
      flex-shrink: 0;
    `,dotYellow:t`
      display: inline-block;
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background-color: ${a.colorWarning};
      flex-shrink: 0;
    `,dotOrange:t`
      display: inline-block;
      width: 10px;
      height: 10px;
      border-radius: 50%;
      background-color: ${a.colorWarningTextActive};
      flex-shrink: 0;
    `}}),az=e=>{let{suggestions:t,selectedIds:a,onToggle:r,previewRow:n,hasPrevRow:o,isLoadingPreviewRow:d,onPrevRow:c,onNextRow:u}=e,{t:m}=(0,l.useTranslation)(),{styles:g}=aB(),h=(0,p.useTheme)();return 0===t.length?(0,i.jsx)("div",{className:g.emptyState,children:(0,i.jsx)(s.NoContent,{text:m("data-importer.mapping.autofill-suggestions.empty")})}):(0,i.jsxs)(s.Flex,{vertical:!0,children:[(0,i.jsxs)(s.Flex,{align:"center",className:g.tableHeaderRow,gap:"small",children:[(0,i.jsx)("div",{style:{width:24,flexShrink:0}}),(0,i.jsx)("div",{style:{width:56,flexShrink:0},children:(0,i.jsx)("span",{className:g.tableHeaderCell,children:m("data-importer.mapping.autofill-suggestions.score")})}),(0,i.jsx)("div",{className:g.sourceCell,children:(0,i.jsx)("span",{className:g.tableHeaderCell,children:m("data-importer.mapping.autofill-suggestions.source")})}),(0,i.jsx)("div",{style:{width:36,flexShrink:0}}),(0,i.jsx)(s.Flex,{align:"center",className:g.destinationCell,gap:h.paddingSM,children:(0,i.jsx)("span",{className:g.tableHeaderCell,children:m("data-importer.mapping.autofill-suggestions.destination")})}),(0,i.jsx)("div",{className:g.resultCell,children:(0,i.jsxs)(s.Flex,{align:"center",justify:"space-between",children:[(0,i.jsx)("span",{className:g.tableHeaderCell,children:m("data-importer.mapping.autofill-suggestions.result")}),(0,i.jsxs)(s.Flex,{align:"center",gap:4,children:[(0,i.jsx)(s.IconButton,{disabled:!o||d,icon:{value:"chevron-left"},onClick:c,size:"small",type:"text"}),(0,i.jsx)(s.IconButton,{disabled:d,icon:{value:"chevron-right"},onClick:u,size:"small",type:"text"})]})]})})]}),t.map(e=>{var t;return(0,i.jsxs)(s.Flex,{align:"center",className:g.tableRow,gap:"small",onClick:()=>{r(e.id)},children:[(0,i.jsx)("div",{style:{width:24,flexShrink:0},children:(0,i.jsx)(s.Checkbox,{checked:a.has(e.id),onChange:()=>{r(e.id)},onClick:e=>{e.stopPropagation()}})}),(0,i.jsx)("div",{style:{width:56,flexShrink:0},children:(0,i.jsxs)(s.Flex,{align:"center",gap:6,children:[(0,i.jsx)("span",{className:g.scoreText,children:`${e.score}%`}),(0,i.jsx)("span",{className:(t=e.score,t>=90?g.dotGreen:t>=70?g.dotYellow:g.dotOrange)})]})}),(0,i.jsx)("div",{className:g.sourceCell,children:(0,i.jsx)("span",{className:g.cellText,children:`${e.sourceLabel} [${e.sourceIndex}]`})}),(0,i.jsx)(s.Flex,{align:"center",justify:"center",style:{width:36,flexShrink:0},children:(0,i.jsx)(ad,{fill:h.colorTextTertiary})}),(0,i.jsxs)(s.Flex,{align:"center",className:g.destinationCell,gap:h.paddingSM,children:[(0,i.jsx)("span",{className:g.cellText,children:`Direct, ${e.targetFieldLabel}`}),null!==e.language&&(0,i.jsx)(s.Tag,{className:g.localeTag,children:e.language})]}),(0,i.jsx)("div",{className:g.resultCell,children:d?(0,i.jsx)(s.Spin,{size:"small",type:"classic"}):n[e.sourceIndex]??""})]},e.id)})]})};function aH(){return!0===globalThis.__DI_MAPPING_DEBUG__}let aq=o().memo(e=>{let{configName:t,isActive:a}=e,{styles:r}=tM(),{t:o}=(0,l.useTranslation)(),d=(0,p.useTheme)(),{validLanguages:u}=(0,c.useSettings)(),m=(0,s.useFormModal)(),g=(0,s.useMessage)(),h=s.Form.useFormInstance(),f=s.Form.useWatch(["loaderConfig","type"]),v=s.Form.useWatch(["interpreterConfig","type"]),{columnHeaderOptions:y,initialLoadDone:b,sourceRows:S,hasPreviewError:C,attributesMap:I,classId:w,getMappingConfig:T,getBackendConfig:D}=function(e,t){var a,r;let i=s.Form.useFormInstance(),o=(0,l.useAppDispatch)(),{data:d,isSuccess:c,requestId:p}=tu({name:e}),[u,m]=(0,n.useState)([]),[g,h]=(0,n.useState)(!1),[f,x]=(0,n.useState)([]),[v,y]=(0,n.useState)(!1),[b,S]=(0,n.useState)({}),C=tj(),[I,w]=(0,n.useState)(void 0),[T,D]=(0,n.useState)(void 0),[N,F]=(0,n.useState)(!1),{data:k,refetch:$,isFetching:L,isError:M,isSuccess:P}=tt(I,{skip:void 0===I,refetchOnMountOrArgChange:!1}),{data:R,refetch:A,isFetching:O,isError:E,isSuccess:B}=ta(T,{skip:void 0===T,refetchOnMountOrArgChange:!1}),z=null==d||null==(r=d.configuration)||null==(a=r.resolverConfig)?void 0:a.dataObjectClassId,H=s.Form.useWatch(["resolverConfig","dataObjectClassId"])??z,q=s.Form.useWatch(e=>JSON.stringify((e.mappingConfig??[]).map(e=>e.transformationResultType??""))),W=(0,n.useMemo)(()=>void 0!==q?JSON.parse(q):void 0,[q]),V=(0,n.useCallback)(()=>i.getFieldValue("mappingConfig")??[],[i]),X=(0,n.useCallback)(()=>j(i.getFieldsValue(!0),(null==d?void 0:d.configuration)??{}),[i,d]),_=(0,n.useCallback)(()=>{let e=X();return{loaderConfig:e.loaderConfig,interpreterConfig:e.interpreterConfig}},[X]);(0,n.useEffect)(()=>{P&&void 0!==k&&m((k.columnHeaders??[]).map(e=>({value:String(e.dataIndex??e.id??""),label:String(e.label??e.dataIndex??e.id??"")})))},[P,k]),(0,n.useEffect)(()=>{M&&m([])},[M]),(0,n.useEffect)(()=>{if(!B||void 0===R)return;let e=(R.dataPreview??[]).map(e=>tL(e));x(e),y(0===e.length)},[B,R]),(0,n.useEffect)(()=>{E&&(x([]),y(!0))},[E]),(0,n.useEffect)(()=>{let e=void 0!==T&&!O;h(void 0!==I&&!L&&N&&e)},[I,T,L,O,N]);let G=s.Form.useWatch(["loaderConfig","type"]),U=s.Form.useWatch(["interpreterConfig","type"]),K=(0,n.useMemo)(()=>JSON.stringify(_()),[G,U,d]),[Q,Y]=(0,n.useState)(""),[J,Z]=(0,n.useState)(void 0),ee=(0,n.useRef)(0),et=(0,n.useRef)(!1);return(0,n.useEffect)(()=>{if(!c||!t){et.current=t;return}let a=K!==Q,r=void 0!==p&&p!==J,n=!et.current&&t;if(et.current=t,!a&&!r){n&&void 0!==I&&void 0!==T&&Promise.all([$().catch(()=>void 0),A().catch(()=>void 0)]);return}let l=ak(),s=++ee.current,u=l?performance.now():0;l&&console.debug("[DI][Loader] source config refresh start",{cycleId:s,configName:e,argsChanged:a,requestChanged:r,loaderConfigType:G,interpreterConfigType:U,classId:z}),h(!1),F(!1),y(!1),w({name:e,bundleDataImporterCopyPreviewParameters:{currentConfig:_(),previewScope:C}}),D({name:e,bundleDataImporterLoadPreviewParameters:{currentConfig:_(),previewScope:C,recordNumber:0}}),r&&!a&&void 0!==I&&void 0!==T&&(l&&console.debug("[DI][Loader] refetch headers+preview",{cycleId:s}),Promise.all([$().catch(()=>void 0),A().catch(()=>void 0)])),(async()=>{let e=l?performance.now():0;try{let e=i.getFieldValue(["resolverConfig","dataObjectClassId"])??z,t=((null==d?void 0:d.configuration)??{}).mappingConfig??[],a=new Set;void 0!==e&&""!==e&&(a.add(void 0),a$.forEach(e=>a.add(e)),t.forEach(e=>{a.add(e.transformationResultType)}));let n=Array.from(a);l&&console.debug("[DI][Loader] class attributes load start",{cycleId:s,effectiveClassId:e,types:n.map(e=>e??tA)});let c=n.map(async t=>await o(tp.endpoints.bundleDataImporterDataTypeLoadClassAttributes.initiate({classId:e,transformationResultType:t,systemWrite:!0},{forceRefetch:r}))),p=await Promise.all(c);if(n.length>0){let e={};p.forEach((t,a)=>{var r;let i=n[a],o=((null==(r=t.data)?void 0:r.attributes)??[]).map(an);e[void 0===i||""===i||"default"===i?tA:i]=o}),S(t=>{let a=!1;for(let r of Object.keys(e))if(t[r]!==e[r]){a=!0;break}return a?{...t,...e}:t})}}finally{l&&console.debug("[DI][Loader] class attributes load done",{cycleId:s,durationMs:Number((performance.now()-e).toFixed(2))}),F(!0)}})(),l&&console.debug("[DI][Loader] source config refresh queued",{cycleId:s,durationMs:Number((performance.now()-u).toFixed(2))}),Y(K),Z(p)},[c,t,e,K,Q,p,J,_,I,T,$,A,o,i,d,z]),(0,n.useEffect)(()=>{var e;!ak()||P&&console.debug("[DI][Loader] headers load success",{count:(null==k||null==(e=k.columnHeaders)?void 0:e.length)??0})},[P,k]),(0,n.useEffect)(()=>{!ak()||M&&console.debug("[DI][Loader] headers load error")},[M]),(0,n.useEffect)(()=>{!ak()||B&&console.debug("[DI][Loader] preview load success",{rowCount:((null==R?void 0:R.dataPreview)??[]).length})},[B,R]),(0,n.useEffect)(()=>{!ak()||E&&console.debug("[DI][Loader] preview load error")},[E]),(0,n.useEffect)(()=>{if(void 0===H||""===H||!g)return;let e=V(),t=new Set;if(e.forEach(e=>{let a=tO(e.transformationResultType);void 0===b[a]&&t.add(a)}),0===t.size)return;let a=Array.from(t);Promise.all(a.map(async e=>await o(tp.endpoints.bundleDataImporterDataTypeLoadClassAttributes.initiate({classId:H,transformationResultType:e===tA?void 0:e,systemWrite:!0})))).then(e=>{S(t=>{let r={};return(e.forEach((e,t)=>{var i;r[a[t]]=((null==(i=e.data)?void 0:i.attributes)??[]).map(an)}),a.some(e=>t[e]!==r[e]))?{...t,...r}:t})})},[W,g,H]),{columnHeaderOptions:u,initialLoadDone:g,sourceRows:f,hasPreviewError:v,attributesMap:b,setAttributesMap:S,classId:H,mappingTrtList:W,getMappingConfig:V,getBackendConfig:X}}(t,a),{dataPreview:N,currentRecordIndex:F,isFetching:k,load:$}=tS({configName:t,enabled:a,getCurrentConfig:D}),[L,M]=(0,n.useState)(new Set),[R,A]=(0,n.useState)(!1),[,O]=(0,n.useTransition)(),[E,B]=(0,n.useState)(null),[z,H]=(0,n.useState)(null),[q,W]=(0,n.useState)(new Set),V=(0,n.useRef)(!0),X=(0,n.useRef)(f),_=(0,n.useRef)(v),G=(0,n.useRef)(null),U=(0,n.useRef)(E);U.current=E;let K=(0,n.useMemo)(()=>{var e;return null===E?null:(null==(e=S.find(e=>e.dataIndex===E))?void 0:e.label)??E},[E,S]),Q=(0,n.useMemo)(()=>({configName:t,classId:w,columnHeaderOptions:y,attributesMap:I,sourceRows:S}),[t,w,y,I,S]);(0,n.useEffect)(()=>{let e=X.current!==f,t=_.current!==v;(e||t)&&(aH()&&console.debug("[DI][Action] reset expanded panels on source type change",{prevLoaderType:X.current,nextLoaderType:f,prevInterpreterType:_.current,nextInterpreterType:v}),M(new Set),X.current=f,_.current=v)},[f,v]);let Y=(0,n.useRef)(L);Y.current=L;let J=(0,n.useCallback)(e=>{let t=Y.current,a="all"===t?new Set(e):t,r=e.every(e=>!a.has(e)),i=r?"expand-all":"collapse-all";if(G.current={action:i,startedAt:performance.now()},aH()&&console.debug("[DI][Action] toggle expand/collapse all",{action:i,visibleCount:e.length,previouslyExpandedVisibleCount:e.filter(e=>a.has(e)).length}),r)V.current=!0,A(!0),O(()=>{M("all"),A(!1)});else{V.current=!1;let t=new Set(a);e.forEach(e=>t.delete(e)),M(t)}},[]);(0,n.useEffect)(()=>{if(!aH()||null===G.current||"collapse-all"!==G.current.action)return;let e=G.current;G.current=null,requestAnimationFrame(()=>{requestAnimationFrame(()=>{console.debug("[DI][Perf] expand/collapse all painted",{action:e.action,durationMs:Number((performance.now()-e.startedAt).toFixed(2))})})})},[L]);let Z=(0,n.useCallback)((e,t)=>{M(a=>{let r=new Set("all"===a?t:a);return r.has(e)?r.delete(e):r.add(e),r})},[]),ee=(0,n.useCallback)(e=>{M(t=>{if(!V.current)return t;if("all"===t)return"all";let a=new Set(t);return a.add(e),a})},[]),et=(0,n.useCallback)((e,t)=>{let a=aH();a&&console.debug("[DI][Action] remove mapping requested",{index:t,beforeCount:T().length,activeFilter:U.current});let r=U.current,i=null;null!==r&&(T().filter((e,a)=>a!==t).some(e=>(e.dataSourceIndex??[]).includes(r))||(i=r,B(null))),e(t),a&&console.debug("[DI][Action] remove mapping done",{index:t,clearedFilter:i,keptFilter:null===i?r:null})},[T]),ea=(0,n.useCallback)((e,t)=>aL(e,t,"manual"),[]),er=(0,n.useCallback)((e,t)=>{let a={current:void 0},r={current:void 0};m.confirm({title:o("data-importer.mapping.new-modal.title"),content:(0,i.jsx)(aF,{errorRef:r,options:y,valueRef:a}),okText:o("data-importer.mapping.add"),onOk:async()=>{var t,i;let n=a.current;if(void 0===n)return null==(i=r.current)||i.call(r,!0),await Promise.reject(Error("source required"));let o=(null==(t=y.find(e=>e.value===n))?void 0:t.label)??n;aH()&&console.debug("[DI][Action] add mapping via modal",{dataIndex:n,label:o,insertIndex:0,beforeCount:T().length}),e(ea(n,o),0);let l=U.current;null!==l&&l!==n&&B(n)}})},[m,o,y,ea,T]),ei=(0,n.useCallback)((e,t,a,r)=>{aH()&&console.debug("[DI][Action] insert mapping via drop",{dataIndex:a,label:r,insertIndex:t,beforeCount:T().length}),e(ea(a,r),t)},[ea,T]),en=(0,n.useMemo)(()=>(N.length>0?N.map(tL):S).reduce((e,t)=>(e[t.dataIndex]=t.value,e),{}),[N,S]),eo=(0,n.useCallback)(()=>{if(0===y.length)return void g.warning(o("data-importer.mapping.autofill-suggestions.no-source-columns"));let e=function(e,t,a,r,i){let n,o=(n=new Set,a.forEach(e=>{(e.dataSourceIndex??[]).forEach(e=>n.add(e))}),n),l=function(e){let t=new Map;for(let a of[tA,...Object.keys(e).filter(e=>e!==tA)])for(let r of e[a]??[])t.has(r.key)||t.set(r.key,{attr:r,transformationResultType:a===tA?"default":a});return Array.from(t.values())}(t),s=new Set(i.map(e=>e.toLowerCase())),d=[];for(let t of e){if(o.has(t.value))continue;let e=function(e,t,a){let r=function(e,t){let a=/^(.*?)[_.-]([a-z]{2})(?:[_-]([A-Za-z]{2,4}))?$/.exec(e);if(null===a)return null;let r=a[1],i=a[2],n=a[3];return 0!==r.length&&t.has(i)?{base:r,locale:void 0!==n?`${i}_${n.toUpperCase()}`:i}:null}(e,a),i=-1,n=null,o=-1,l=null,s=null;for(let a of t){let t=aE(e,a.attr);if(t>i&&(i=t,n=a),!0===a.attr.localized&&null!==r){let e=aE(r.base,a.attr);e>o&&(o=e,l=a,s=r.locale)}}let d=o>=i&&null!==l,c=d?l:n,p=d?o:i,u=d?s:null;return null===c||p<40?null:{entry:c,score:p,language:u}}(t.label,l,s);if(null===e)continue;let a=r.find(e=>e.dataIndex===t.value);d.push({id:(0,x.uuid)(),sourceIndex:t.value,sourceLabel:t.label,targetFieldName:e.entry.attr.key,targetFieldLabel:e.entry.attr.title,transformationResultType:e.entry.transformationResultType,score:e.score,language:e.language,previewResult:(null==a?void 0:a.value)??null})}return d.sort((e,t)=>t.score-e.score)}(y,I,T(),S,u??[]);H(e),W(new Set(e.map(e=>e.id))),$(0)},[T,y,I,S,u,g,o,$]),el=(0,n.useCallback)(()=>{let e=Math.max(0,F-1);e!==F&&$(e)},[F,$]),es=(0,n.useCallback)(()=>{$(F+1)},[F,$]),ed=(0,n.useCallback)(e=>{W(t=>{let a=new Set(t);return a.has(e)?a.delete(e):a.add(e),a})},[]),ec=(0,n.useCallback)(()=>{H(null),W(new Set)},[]),ep=(0,n.useCallback)(()=>{null!==z&&W(e=>z.every(t=>e.has(t.id))?new Set:new Set(z.map(e=>e.id)))},[z]),eu=(0,n.useCallback)(()=>{if(null===z)return;let e=z.filter(e=>q.has(e.id)).map(e=>aL(e.sourceIndex,e.sourceLabel,"autofill",e.targetFieldName,e.language??void 0,e.transformationResultType)),t=T();aH()&&console.debug("[DI][Action] autofill suggestions applied",{appliedCount:e.length,beforeCount:t.length}),h.setFieldValue("mappingConfig",[...t,...e],{triggerChange:!0}),H(null),W(new Set)},[z,q,T,h]),em=(0,n.useCallback)((e,t)=>{let a=T(),r=ea(e,t);aH()&&console.debug("[DI][Action] add mapping from source panel",{dataIndex:e,label:t,beforeCount:a.length}),h.setFieldValue("mappingConfig",[...a,r],{triggerChange:!0})},[T,ea,h]),eg=(0,n.useCallback)(e=>{let t=U.current;if(null===t)return;let a=K??t;aH()&&console.debug("[DI][Action] add mapping for active filter",{dataIndex:t,label:a,beforeCount:T().length}),e(ea(t,a))},[K,ea,T]),eh=(0,n.useCallback)(e=>(function(e,t){let a=e.getFieldValue(["mappingConfig",t]),r=null==a?void 0:a.mappingId;if(void 0!==r&&""!==r)return r;let i=(0,x.uuid)();return e.setFieldValue(["mappingConfig",t,"mappingId"],i,{triggerChange:!1}),i})(h,e),[h]),ef=(0,n.useMemo)(()=>{if(null!==z&&0===z.length)return[(0,i.jsx)(s.Button,{onClick:ec,type:"primary",children:o("data-importer.mapping.autofill-suggestions.ok")},"ok")];let e=null!==z&&z.length>0&&z.every(e=>q.has(e.id)),t=(null==z?void 0:z.some(e=>q.has(e.id)))===!0;return(0,i.jsxs)(s.Flex,{style:{width:"100%"},children:[(0,i.jsxs)(s.Flex,{align:"center",gap:"small",style:{flex:1},children:[(0,i.jsx)(s.Checkbox,{checked:e,indeterminate:t&&!e,onChange:ep}),(0,i.jsx)("span",{children:o("data-importer.mapping.autofill-suggestions.selected",{count:q.size})})]}),k&&(0,i.jsx)(s.Spin,{size:"small",style:{marginInlineEnd:8},type:"classic"}),(0,i.jsxs)(s.Flex,{align:"center",gap:"small",children:[(0,i.jsx)(s.Button,{onClick:ec,type:"default",children:o("data-importer.mapping.autofill-suggestions.reject-all")}),(0,i.jsx)(s.Button,{disabled:0===q.size,onClick:eu,type:"primary",children:o("data-importer.mapping.autofill-suggestions.apply")})]})]})},[o,z,q,k,ep,ec,eu]);return(0,i.jsxs)(s.Content,{loading:!b,children:[(0,i.jsx)(aS,{value:Q,children:(0,i.jsxs)(s.Flex,{className:r.mappingLayout,children:[(0,i.jsx)("div",{className:r.mappingLayoutLeft,children:(0,i.jsx)(tR,{activeFilter:E,configName:t,hasPreviewError:C,onAddMappingFromSource:em,onSetFilter:B,sourceRows:S})}),(0,i.jsx)(s.Flex,{align:"center",className:r.mappingLayoutCenter,vertical:!0,children:(0,i.jsx)(s.Flex,{align:"center",className:r.mappingLayoutCenterArrow,justify:"center",children:(0,i.jsx)(aM,{})})}),(0,i.jsx)("div",{className:r.mappingLayoutRight,children:(0,i.jsx)(P.FieldWidthProvider,{fieldWidthValues:{small:9999,medium:9999,large:9999},children:(0,i.jsx)(aN,{activeFilter:E,activeFilterLabel:K,expandAllPending:R,expandedKeys:L,getMappingIdByIndex:eh,onAddItem:er,onAddMappingForFilter:eg,onCollapseAll:J,onInsertItem:ei,onNewKey:ee,onOpenAutofillSuggestions:eo,onRemoveItem:et,onToggleKey:Z})})})]})}),(0,i.jsx)(s.Modal,{footer:ef,onCancel:ec,open:null!==z,styles:{body:{padding:0,paddingBlock:0,paddingInline:0,maxHeight:"60vh",overflowY:"auto"},footer:{padding:"12px 16px",borderTop:null!==z&&z.length>0?`1px solid ${d.colorPrimaryBorder}`:"none"}},title:o("data-importer.mapping.autofill-suggestions.title"),width:1100,children:null!==z&&(0,i.jsx)(az,{hasPrevRow:F>0,isLoadingPreviewRow:k,onNextRow:es,onPrevRow:el,onToggle:ed,previewRow:en,selectedIds:q,suggestions:z})})]})});aq.displayName="MappingStep";let aW=(0,p.createStyles)(e=>{let{css:t,token:a}=e;return{loggingGroups:t`
      width: 100%;
    `,loggingGroup:t`
      width: 100%;
    `,loggingGroupTitle:t`
      margin-bottom: ${a.paddingXS}px;
      font-size: ${a.fontSize}px;
      font-weight: 600;
      color: ${a.colorTextHeading};
    `,loggingItem:t`
      margin-bottom: ${a.paddingXS}px;
    `,loggingItemLast:t`
      margin-bottom: 0;
    `}}),aV=e=>{let{columnHeaderOptions:t}=e,{t:a}=(0,l.useTranslation)(),{styles:r,cx:o}=aW(),d=s.Form.useFormInstance(),c=[{value:"sequential",label:a("data-importer.processing.execution-type.sequential")},{value:"parallel",label:a("data-importer.processing.execution-type.parallel")}],p=[{value:"delete",label:a("data-importer.processing.cleanup.strategy.delete")},{value:"unpublish",label:a("data-importer.processing.cleanup.strategy.unpublish")}],u=void 0!==ah(["processingConfig","doDeltaCheck"]),m=void 0!==ah(["processingConfig","cleanup","doCleanup"]),g=void 0!==ah(["processingConfig","cleanup","strategy"]),h=s.Form.useWatch(["processingConfig","logging","disableInfoLogs"]),f=s.Form.useWatch(["processingConfig","logging","disableErrorLogs"]);return(0,n.useEffect)(()=>{!0===h&&d.setFieldValue(["processingConfig","logging","disableInfoFileObjects"],!0)},[h,d]),(0,n.useEffect)(()=>{!0===f&&d.setFieldValue(["processingConfig","logging","disableErrorFileObjects"],!0)},[f,d]),(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(M,{children:a("data-importer.processing.title")}),(0,i.jsxs)(O,{title:a("data-importer.processing.execution.title"),children:[(0,i.jsx)(s.Form.Item,{label:a("data-importer.processing.execution-type"),name:["processingConfig","executionType"],tooltip:a("data-importer.processing.execution-type.tooltip"),children:(0,i.jsx)(s.Select,{filterOption:E,options:c,showSearch:!0})}),(0,i.jsx)(s.Form.Item,{name:["processingConfig","doArchiveImportFile"],valuePropName:"checked",children:(0,i.jsx)(s.Switch,{labelRight:a("data-importer.processing.archive-import-file")})}),(0,i.jsx)(s.Form.Item,{name:["processingConfig","disableVersioning"],valuePropName:"checked",children:(0,i.jsx)(s.Switch,{labelRight:a("data-importer.processing.disable-versioning")})})]}),(0,i.jsxs)(O,{title:a("data-importer.processing.id-delta.title"),children:[(0,i.jsx)(s.Form.Item,{label:a("data-importer.processing.id-data-index"),name:["processingConfig","idDataIndex"],tooltip:a("data-importer.processing.id-data-index.tooltip"),children:(0,i.jsx)(s.Select,{allowClear:!0,filterOption:E,options:t,placeholder:a("data-importer.processing.id-data-index-placeholder"),showSearch:!0})}),(0,i.jsxs)(s.Form.Conditional,{condition:e=>{var t;return!!(null==(t=e.processingConfig)?void 0:t.idDataIndex)||u||m||g},children:[(0,i.jsx)(s.Form.Item,{name:["processingConfig","doDeltaCheck"],valuePropName:"checked",children:(0,i.jsx)(s.Switch,{labelRight:a("data-importer.processing.delta-check")})}),(0,i.jsx)(s.Form.Item,{name:["processingConfig","cleanup","doCleanup"],valuePropName:"checked",children:(0,i.jsx)(s.Switch,{labelRight:a("data-importer.processing.cleanup.do-cleanup")})}),(0,i.jsx)(s.Form.Conditional,{condition:e=>{var t,a;return!!(null==(a=e.processingConfig)||null==(t=a.cleanup)?void 0:t.doCleanup)||g},children:(0,i.jsx)(O,{theme:"fieldset",title:a("data-importer.processing.cleanup.title"),children:(0,i.jsx)(s.Form.Item,{label:a("data-importer.processing.cleanup.strategy"),name:["processingConfig","cleanup","strategy"],tooltip:a("data-importer.processing.cleanup.strategy.tooltip"),children:(0,i.jsx)(s.Select,{filterOption:E,options:p,showSearch:!0})})})})]})]}),(0,i.jsx)(O,{title:a("data-importer.processing.logging.title"),children:(0,i.jsxs)(s.Flex,{className:r.loggingGroups,gap:"small",vertical:!0,children:[(0,i.jsxs)("div",{className:r.loggingGroup,children:[(0,i.jsx)("div",{className:r.loggingGroupTitle,children:a("data-importer.processing.logging.info.title")}),(0,i.jsx)(s.Form.Item,{className:r.loggingItem,name:["processingConfig","logging","disableInfoLogs"],valuePropName:"checked",children:(0,i.jsx)(s.Switch,{labelRight:a("data-importer.processing.logging.info.disable-logs")})}),(0,i.jsx)(s.Form.Item,{className:o(r.loggingItem,r.loggingItemLast),name:["processingConfig","logging","disableInfoFileObjects"],valuePropName:"checked",children:(0,i.jsx)(s.Switch,{disabled:!0===h,labelRight:a("data-importer.processing.logging.info.disable-file-objects")})})]}),(0,i.jsxs)("div",{className:r.loggingGroup,children:[(0,i.jsx)("div",{className:r.loggingGroupTitle,children:a("data-importer.processing.logging.error.title")}),(0,i.jsx)(s.Form.Item,{className:r.loggingItem,name:["processingConfig","logging","disableErrorLogs"],valuePropName:"checked",children:(0,i.jsx)(s.Switch,{labelRight:a("data-importer.processing.logging.error.disable-logs")})}),(0,i.jsx)(s.Form.Item,{className:o(r.loggingItem,r.loggingItemLast),name:["processingConfig","logging","disableErrorFileObjects"],valuePropName:"checked",children:(0,i.jsx)(s.Switch,{disabled:!0===f,labelRight:a("data-importer.processing.logging.error.disable-file-objects")})})]})]})})]})},aX=(0,p.createStyles)(e=>{let{css:t,token:a}=e;return{tabLayout:t`
      height: 100%;
      min-height: 0;
    `,stepContent:t`
      flex: 1;
      min-height: 0;
      overflow-y: auto;
      padding: ${a.paddingXS}px ${a.paddingSM}px;
    `,stepContentHidden:t`
      display: none;
    `,stepContentMapping:t`
      flex: 1;
      height: 0;
      overflow: auto;
    `,stepContentMappingHidden:t`
      display: none;
    `}}),a_=function(e,t){let a=arguments.length>2&&void 0!==arguments[2]?arguments[2]:0,r=s.Form.useFormInstance(),{data:i}=tu({name:e}),o=tj(),l=s.Form.useWatch(["loaderConfig","type"]),d=s.Form.useWatch(["interpreterConfig","type"]),c=(0,n.useMemo)(()=>{if(void 0===i||void 0===l)return;let t=j(r.getFieldsValue(!0),i.configuration??{});return{name:e,bundleDataImporterCopyPreviewParameters:{previewScope:o,currentConfig:{loaderConfig:t.loaderConfig,interpreterConfig:t.interpreterConfig}}}},[e,i,r,l,d,o]),{data:p,refetch:u}=tt(c,{skip:void 0===c||!t}),m=(0,n.useRef)(a);return(0,n.useEffect)(()=>{t&&void 0!==c&&a!==m.current&&(m.current=a,u().catch(()=>void 0))},[t,a,c,u]),(0,n.useMemo)(()=>((null==p?void 0:p.columnHeaders)??(null==i?void 0:i.columnHeaders)??[]).map(e=>({value:"string"==typeof e?e:e.dataIndex??"",label:"string"==typeof e?e:e.label??e.dataIndex??""})),[null==p?void 0:p.columnHeaders,null==i?void 0:i.columnHeaders])},aG=e=>{let{configName:t,activeStep:a,onStepChange:r}=e,{t:o}=(0,l.useTranslation)(),{styles:d}=aX(),[c,p]=(0,n.useState)(0),u=a??c,[m,g]=(0,n.useState)(0),h=a_(t,2===u||4===u,m),f=(0,n.useMemo)(()=>[{title:o("data-importer.data-setup.steps.data-source.title")},{title:o("data-importer.data-setup.steps.preview-import.title")},{title:o("data-importer.data-setup.steps.resolver.title")},{title:o("data-importer.data-setup.steps.mapping.title")},{title:o("data-importer.data-setup.steps.processing-settings.title")}],[o]),x=3===u;return(0,i.jsxs)(s.Flex,{className:d.tabLayout,vertical:!0,children:[(0,i.jsx)(s.Box,{margin:{x:"small"},children:(0,i.jsx)(s.Steps,{current:u,items:f,onChange:e=>{p(e),null==r||r(e)},size:"small",type:"navigation"})}),(0,i.jsx)("div",{className:$()(d.stepContentMapping,!x&&d.stepContentMappingHidden),children:(0,i.jsx)(aq,{configName:t,isActive:x})}),(0,i.jsx)("div",{className:$()(d.stepContent,0!==u&&d.stepContentHidden),children:(0,i.jsx)(eY,{configName:t})}),(0,i.jsx)("div",{className:$()(d.stepContent,1!==u&&d.stepContentHidden),children:(0,i.jsx)(tw,{configName:t,isActive:1===u,onPreviewDataChange:()=>{g(e=>e+1)}})}),(0,i.jsx)("div",{className:$()(d.stepContent,2!==u&&d.stepContentHidden),children:(0,i.jsx)(t$,{columnHeaderOptions:h,configName:t,isActive:2===u})}),(0,i.jsx)("div",{className:$()(d.stepContent,4!==u&&d.stepContentHidden),children:(0,i.jsx)(aV,{columnHeaderOptions:h})})]})};var aU=a(6514),aK=a(8221),aQ=a.n(aK);let aY=()=>{let{t:e}=(0,l.useTranslation)(),t=s.Form.useFormInstance(),a=s.Form.useWatch(["executionConfig","cronDefinition"])??"",r=s.Form.useWatch(["loaderConfig","type"]),[o,d]=(0,n.useState)(a),[c,p]=(0,n.useState)(!1),u=(0,n.useCallback)(aQ()(e=>{d(e),p(!1)},500),[]);(0,n.useEffect)(()=>()=>{u.cancel()},[u]),(0,n.useEffect)(()=>{a.trim().length>0&&p(!0),u(a)},[a,u]);let m=0===o.trim().length,{data:g,isFetching:h}=tc({cronExpression:o},{skip:m}),f=(c||h)&&a.trim().length>0;(0,n.useEffect)(()=>{c||h||t.validateFields([["executionConfig","cronDefinition"]],{dirty:!1}).catch(()=>{})},[g,h,c,m]);let{t:x}=(0,l.useTranslation)(),v=(0,n.useMemo)(()=>({async validator(e,t){void 0===t||0===t.trim().length?await Promise.resolve():c||h||void 0===g?await Promise.reject(Error("")):g.isValid?await Promise.resolve():await Promise.reject(Error(g.message))}}),[c,h,g,x]);return(0,i.jsx)(s.Form.Item,{hasFeedback:!f&&a.trim().length>0,label:(0,i.jsxs)(s.Flex,{align:"center",gap:8,children:[(0,i.jsx)("span",{children:e("data-importer.execution.cron-definition")}),(0,i.jsx)(s.Button,{href:"https://crontab.guru/",icon:(0,i.jsx)(s.Icon,{value:"share-nodes"}),rel:"noopener noreferrer",target:"_blank",type:"link",children:e("data-importer.execution.cron-generator")})]}),name:["executionConfig","cronDefinition"],rules:[v],validateStatus:f?"":void 0,children:(0,i.jsx)(s.Input,{disabled:"push"===r,onBlur:()=>{u.flush()},placeholder:"0 2 * * *",suffix:f?(0,i.jsx)(aU.A,{spin:!0}):(0,i.jsx)("span",{})})})},aJ=e=>{let{isDirty:t,isStarting:a,onStart:r,label:n}=e,{t:o}=(0,l.useTranslation)(),d="push"===s.Form.useWatch(["loaderConfig","type"]),c=d||t||a,p=t?o("data-importer.execution.start-import.tooltip-dirty"):d?o("data-importer.execution.start-import.tooltip-push"):void 0;return(0,i.jsx)(s.Tooltip,{title:p,children:(0,i.jsx)("span",{children:(0,i.jsx)(s.Button,{disabled:c,loading:a&&!d,onClick:r,type:"primary",children:n})})})},aZ=(0,p.createStyles)(e=>{let{token:t,css:a}=e;return{progressLabel:a`
      font-size: 12px;
      font-weight: 400;
      line-height: 22px;
      color: ${t.colorText};
      margin: 0;
    `,progressWrapper:a`
      width: 100%;

      /* antd Progress root is inline-flex by default — override to fill full width */
      .ant-progress {
        display: block;
        width: 100%;
        margin-bottom: 0;
      }

      /* Ensure the inner bar line fills the wrapper */
      .ant-progress-inner {
        width: 100% !important;
      }

      /* Pad the inner text so it sits 8px from the left edge */
      .ant-progress-text {
        padding-inline-start: ${t.paddingXS}px;
      }
    `,colorFill:t.colorFill,colorBgLayout:t.colorBgLayout}}),a0=e=>{let{configName:t,isDirty:a}=e,{t:r}=(0,l.useTranslation)(),o=(0,s.useMessage)(),{styles:d}=aZ(),[p,{isLoading:u}]=tf(),[m,{isLoading:g}]=tx(),{data:h,refetch:f}=th({name:t},{pollingInterval:5e3}),[x,v]=(0,n.useState)(!1),[y,b]=(0,n.useState)(null),[j,S]=(0,n.useState)(!1),[C,I]=(0,n.useState)(!1);(0,n.useEffect)(()=>{(null==h?void 0:h.isRunning)===!0&&(v(!1),b(null),I(!1))},[null==h?void 0:h.isRunning]),(0,n.useEffect)(()=>{(null==h?void 0:h.isRunning)===!1&&(S(!1),(h.processedItems??0)>0&&I(!0))},[null==h?void 0:h.isRunning]);let w=!j&&(x||((null==h?void 0:h.isRunning)??!1)),T=(null==y?void 0:y.progress)??(null==h?void 0:h.progress)??0,D=(null==y?void 0:y.processedItems)??(null==h?void 0:h.processedItems)??0,N=(null==y?void 0:y.totalItems)??(null==h?void 0:h.totalItems)??0,F=async()=>{let e=await p({name:t});if("error"in e){void 0!==e.error&&(0,c.trackError)(new c.ApiError(e.error)),o.error(r("data-importer.execution.start-import.error"));return}e.data.success?(o.success(r("data-importer.execution.start-import.success")),b({processedItems:0,totalItems:(null==h?void 0:h.totalItems)??0,progress:0}),v(!0),I(!1)):o.error(r("data-importer.execution.start-import.error")),f()},k=async()=>{let e=await m({name:t});if("error"in e){void 0!==e.error&&(0,c.trackError)(new c.ApiError(e.error)),o.error(r("data-importer.execution.cancel.error"));return}o.success(r("data-importer.execution.cancel.success")),S(!0),v(!1),b(null),I(!1),f()};return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(O,{title:r("data-importer.execution.manual-execution"),children:(0,i.jsx)(aJ,{isDirty:a,isStarting:u,label:r("data-importer.execution.start-import"),onStart:()=>{F()}})}),(0,i.jsx)(O,{noWidthLimit:!0,title:r("data-importer.execution.status.title"),children:w?(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)("p",{className:d.progressLabel,children:r("data-importer.execution.status.current-progress")}),(0,i.jsx)("div",{className:d.progressWrapper,children:(0,i.jsx)(s.Progress,{format:()=>r("data-importer.execution.status.processing",{processedItems:D,totalItems:N}),percent:Math.round(100*T),percentPosition:{align:"start",type:"inner"},size:[-1,32],status:"active",strokeColor:d.colorFill,trailColor:"rgba(0, 0, 0, 0.06)"})}),(0,i.jsx)(s.Button,{loading:g,onClick:()=>{k()},children:r("data-importer.execution.status.cancel")})]}):(0,i.jsx)(s.Text,{children:r(C?"data-importer.execution.status.finished":"data-importer.execution.status.not-running")})})]})},a1=e=>{let{configName:t,isDirty:a,showRuntime:r=!0}=e,{t:n}=(0,l.useTranslation)(),o=[{value:"recurring",label:n("data-importer.execution.schedule-type.recurring")},{value:"job",label:n("data-importer.execution.schedule-type.job")}];return(0,i.jsxs)(i.Fragment,{children:[r&&(0,i.jsx)(a0,{configName:t,isDirty:a}),(0,i.jsxs)(O,{title:n("data-importer.execution.settings.title"),children:[(0,i.jsx)(s.Form.Item,{initialValue:"recurring",label:n("data-importer.execution.schedule-type"),name:["executionConfig","scheduleType"],children:(0,i.jsx)(s.Select,{options:o})}),(0,i.jsx)(s.Form.Conditional,{condition:e=>{var t;return((null==(t=e.executionConfig)?void 0:t.scheduleType)??"recurring")==="recurring"},children:(0,i.jsx)(O,{theme:"fieldset",title:n("data-importer.execution.schedule-type.recurring"),children:(0,i.jsx)(aY,{})})}),(0,i.jsx)(s.Form.Conditional,{condition:e=>{var t;return(null==(t=e.executionConfig)?void 0:t.scheduleType)==="job"},children:(0,i.jsx)(s.Form.Item,{label:n("data-importer.execution.scheduled-at"),name:["executionConfig","scheduledAt"],children:(0,i.jsx)(s.DatePicker,{outputFormat:"YYYY-MM-DD HH:mm",outputType:"dateString",showTime:{format:"HH:mm"}})})})]})]})};var a2=a(969),a3=a(1119);let a5=(0,p.createStyles)(e=>{let{css:t}=e;return{fullWidth:t`
      width: 100%;
    `}}),a9="YYYY-MM-DD HH:mm",a6=e=>{let{children:t}=e,[a,r]=(0,n.useState)("filter"),o=(0,n.useMemo)(()=>({entries:[],buttons:[],sizing:"default",highlights:[],activeTab:a,setEntries:()=>{},setButtons:()=>{},setSizing:()=>{},setHighlights:()=>{},setActiveTab:r,addEntry:()=>{},removeEntry:()=>{},addButton:()=>{},removeButton:()=>{},toggleHighlight:()=>{},openTab:e=>{r(e)},closeTab:()=>{r("")},toggleTab:e=>{r(t=>t===e?"":e)}}),[a]);return(0,i.jsx)(s.SidebarContext.Provider,{value:o,children:t})},a4=[{key:"filter",icon:(0,i.jsx)(s.Icon,{options:{width:"16px",height:"16px"},value:"filter"}),component:(0,i.jsx)(()=>{let{t:e}=(0,l.useTranslation)(),{styles:t}=a5(),[a]=s.Form.useForm(),{dateFrom:r,setDateFrom:n,dateTo:o,setDateTo:d,relatedObjectId:c,setRelatedObjectId:p,message:u,setMessage:m,pid:g,setPid:h,resetFilters:f,updateFilters:x,isLoading:v}=(0,a2.useFilter)();return(0,i.jsx)(s.ContentLayout,{renderToolbar:(0,i.jsxs)(s.Toolbar,{theme:"secondary",children:[(0,i.jsx)(s.IconTextButton,{disabled:v,icon:{value:"close"},onClick:()=>{f(),a.resetFields()},type:"link",children:e("sidebar.clear-all-filters")}),(0,i.jsx)(s.Button,{disabled:v,loading:v,onClick:x,type:"primary",children:e("button.apply")})]}),children:(0,i.jsx)(s.Content,{padded:!0,children:(0,i.jsx)(s.Form,{form:a,layout:"vertical",children:(0,i.jsxs)(s.Space,{className:t.fullWidth,direction:"vertical",size:"none",children:[(0,i.jsx)(s.Title,{children:e("application-logger.sidebar.search-parameter")}),(0,i.jsx)(s.Form.Item,{label:e("application-logger.filter.date-from"),name:"dateFrom",children:(0,i.jsx)(s.DatePicker,{className:"w-full",format:a9,onChange:e=>{n(e)},outputType:"dateString",showTime:{format:"HH:mm"},value:r})}),(0,i.jsx)(s.Form.Item,{label:e("application-logger.filter.date-to"),name:"dateTo",children:(0,i.jsx)(s.DatePicker,{className:"w-full",format:a9,onChange:e=>{d(e)},outputType:"dateString",showTime:{format:"HH:mm"},value:o})}),(0,i.jsx)(s.Form.Item,{label:e("application-logger.filter.priority"),name:"priority",children:(0,i.jsx)(a2.PrioritySelect,{})}),(0,i.jsx)(s.Form.Item,{label:e("application-logger.filter.message"),name:"message",children:(0,i.jsx)(s.Input,{onChange:e=>{let t=e.target.value;m(""===t?null:t)},value:u??void 0})}),(0,i.jsx)(s.Form.Item,{label:e("application-logger.filter.related-object-id"),name:"relatedObjectId",children:(0,i.jsx)(s.Input,{min:"0",onChange:e=>{let t=e.target.value;p(""===t?null:Number.parseInt(t))},step:"1",type:"number",value:c??void 0})}),(0,i.jsx)(s.Form.Item,{label:e("application-logger.filter.pid"),name:"pid",children:(0,i.jsx)(s.Input,{min:"0",onChange:e=>{let t=e.target.value;h(""===t?null:Number.parseInt(t))},step:"1",type:"number",value:g??void 0})})]})})})})},{})}],a8=e=>{let{configName:t}=e,{t:a}=(0,l.useTranslation)(),r=(0,l.useAppDispatch)(),[o,d]=(0,n.useState)(1),[c,p]=(0,n.useState)(20),[u,m]=(0,n.useState)([]),{columnFilters:g,setIsLoading:h}=(0,a2.useFilter)(),f=[...g,{key:"component",type:"equals",filterValue:"DATA-IMPORTER "+t}],{data:v,isFetching:y}=(0,a2.useBundleApplicationLoggerGetCollectionQuery)({body:{filters:{page:o,pageSize:c,columnFilters:f,sortFilter:(0,a2.mapSortingToSortFilter)(u)}}}),b=(null==v?void 0:v.totalItems)??0,j=(0,n.useCallback)(()=>{r(a2.api.util.invalidateTags(eZ.invalidatingTags.APPLICATION_LOGGER()))},[r]),{refreshInterval:S,setRefreshInterval:C}=(e=>{let[t,a]=(0,n.useState)(void 0),r=(0,n.useCallback)(e,[e]);return(0,n.useEffect)(()=>{if((0,a3.isNil)(t))return;let e=setInterval(()=>{r()},1e3*Number.parseInt(t));return()=>{clearInterval(e)}},[t,r]),{refreshInterval:t,setRefreshInterval:a}})(j);(0,n.useEffect)(()=>{h(y)},[y]);let I=(0,n.useRef)(null),w=(0,x.useElementVisible)(I,!0),T=(0,n.useRef)(!0);return(0,n.useEffect)(()=>{if(w){if(T.current){T.current=!1;return}j()}},[w,j]),(0,i.jsx)(a6,{children:(0,i.jsx)("div",{ref:I,style:{height:"100%"},children:(0,i.jsx)(s.ContentLayout,{className:"h-full",renderSidebar:(0,i.jsx)(s.Sidebar,{entries:a4}),renderToolbar:(0,i.jsxs)(s.Toolbar,{justify:"space-between",theme:"secondary",children:[(0,i.jsxs)(s.Flex,{align:"center",gap:8,children:[!(0,a3.isNil)(S)&&(0,i.jsx)("span",{children:a("application-logger.refresh-interval")}),(0,i.jsx)(s.CreatableSelect,{allowClear:!0,inputType:"number",minWidth:200,numberInputProps:{min:1},onChange:C,onCreateOption:e=>({value:e,label:a("application-logger.refresh-interval.seconds",{seconds:e})}),options:[{value:"3",label:a("application-logger.refresh-interval.seconds",{seconds:3})},{value:"5",label:a("application-logger.refresh-interval.seconds",{seconds:5})},{value:"10",label:a("application-logger.refresh-interval.seconds",{seconds:10})},{value:"30",label:a("application-logger.refresh-interval.seconds",{seconds:30})},{value:"60",label:a("application-logger.refresh-interval.seconds",{seconds:60})}],placeholder:a("application-logger.refresh-interval.select"),validate:e=>!Number.isNaN(Number.parseInt(e))&&Number.parseInt(e)>0,value:S})]}),(0,i.jsxs)(s.Flex,{children:[(0,i.jsx)(s.IconButton,{disabled:y,icon:{value:"refresh"},onClick:j}),b>0&&(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(s.Divider,{size:"small",type:"vertical"}),(0,i.jsx)(s.Pagination,{current:o,defaultPageSize:c,onChange:(e,t)=>{d(e),p(t)},showSizeChanger:!0,showTotal:e=>a("pagination.show-total",{total:e}),total:b})]})]})]}),children:(0,i.jsx)(s.Content,{padded:!0,children:(0,i.jsx)(a2.ApplicationLoggerTable,{isLoading:y,items:(null==v?void 0:v.items)??[],onSortingChange:e=>{m(e),d(1)},sorting:u})})})})})},a7=e=>{let{configName:t}=e;return(0,i.jsx)(a2.FilterProvider,{children:(0,i.jsx)(a8,{configName:t})})},re=()=>void 0,rt=e=>{let{configName:t,configuration:a,isWriteable:r,onSave:n,isLoading:o=!1,modificationDate:p,onChange:m=re,requestId:g,renderToolbar:h,showRuntime:f=!0,activeTab:x,onTabChange:v,activeStep:y,onStepChange:b}=e,{t:S}=(0,l.useTranslation)(),{styles:C}=u(),{form:I,isDirty:w,initialValues:D,handleSave:F,handleValuesChange:k}=(0,d.useDetailView)({configName:t,configData:a,modificationDate:p,isLoading:o,requestId:g,isWriteable:r,transformToForm:T,transformToBackend:j,onSave:n,onChange:m}),$=[{key:"general",label:S("data-importer.tabs.general"),children:(0,i.jsx)(d.GeneralTab,{adapterTypeLabel:S("data-importer.adapter.dataImporterDataObject")})},{key:"data-setup",label:S("data-importer.tabs.data-setup"),fullHeight:!0,children:(0,i.jsx)(aG,{activeStep:y,configName:t,onStepChange:b})},{key:"execution",label:S("data-importer.tabs.execution"),children:(0,i.jsx)(a1,{configName:t,isDirty:w,showRuntime:f})},...f&&(0,c.isBundleActive)("PimcoreApplicationLoggerBundle")?[{key:"import-logs",label:S("data-importer.tabs.import-logs"),fullHeight:!0,children:(0,i.jsx)(a7,{configName:t})}]:[],{key:"permissions",label:S("data-importer.tabs.permissions"),children:(0,i.jsx)(d.PermissionsTab,{isWriteable:r})}].map(e=>({...e,children:!0===e.fullHeight?e.children:(0,i.jsx)(s.Content,{padded:!0,children:e.children})}));return(0,i.jsx)(N,{readOnly:!r,children:(0,i.jsx)(s.ContentLayout,{renderToolbar:null==h?void 0:h({isDirty:w,onSave:F}),children:(0,i.jsx)(s.Content,{loading:o,overflow:{x:"auto",y:"hidden"},children:!o&&(0,i.jsx)("div",{className:C.formWrapper,children:(0,i.jsx)(s.FormKit,{formProps:{form:I,initialValues:D,layout:"vertical",onValuesChange:k,disabled:!r},wrapInPanel:!1,children:(0,i.jsx)(s.Tabs,{activeKey:x,defaultActiveKey:"general",fullHeight:!0,items:$,noTabBarMargin:!0,onChange:v,type:"card"})},g??"")})})})})},ra="mapping",rr=(e,t)=>JSON.stringify(e??null)===JSON.stringify(t??null),ri=(e,t)=>("history"===t?e.base:e.current)??{},rn=e=>e.map(e=>e.row),ro=e=>`${String(e.label??"")}|${JSON.stringify(e.dataSourceIndex??null)}`,rl=e=>{var t,a;let r=(null==(t=e.dataTarget)?void 0:t.settings)??{},i=r.fieldName;if("string"==typeof i&&""!==i)return`${JSON.stringify(e.dataSourceIndex??null)}|${(null==(a=e.dataTarget)?void 0:a.type)??""}:${i}:${String(r.language??"")}`},rs=e=>{if("string"==typeof e.label&&""!==e.label)return e.label;let t=e.dataSourceIndex;return Array.isArray(t)?t.map(String).join(", "):"string"==typeof t?t:"—"},rd=e=>{var t,a,r;let i=null==(a=e.dataTarget)||null==(t=a.settings)?void 0:t.fieldName,n=(null==(r=e.dataTarget)?void 0:r.type)??"";return"string"==typeof i&&""!==i?`${i} (${n})`:n},rc=e=>"string"==typeof e.mappingId&&""!==e.mappingId?e.mappingId:void 0;function rp(e){var t,a;let r=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"review",i=null==e||null==(t=e.slots)?void 0:t[ra];if(null==i)return[];let n=(null==(a=i.proposed)?void 0:a.mappingConfig)??[],o=ri(i,r).mappingConfig??[];if(!Array.isArray(n)||!Array.isArray(o))return[];let l=new Map,s=new Map,d=new Map;o.forEach((e,t)=>{let a=rc(e);void 0!==a&&l.set(a,t),s.has(ro(e))||s.set(ro(e),t);let r=rl(e);void 0===r||d.has(r)||d.set(r,t)});let c=new Set,p=n.map((e,t)=>{let a,r,i=rc(e),n=(a=rc(e),r=rl(e),(void 0!==a?l.get(a):void 0)??s.get(ro(e))??(void 0!==r?d.get(r):void 0)),p=i??`#${t}`,u=rd(e);if(void 0===n||c.has(n))return{key:p,label:rs(e),target:u,status:"added",row:e};c.add(n);let m=o[n],g=e=>{let{mappingId:t,...a}=e;return a};return{key:p,label:rs(e),target:u,currentTarget:rd(m),status:rr(g(m),g(e))?"unchanged":"changed",row:e}});return o.forEach((e,t)=>{c.has(t)||p.splice(Math.min(t,p.length),0,{key:rc(e)??`current#${t}`,label:rs(e),target:rd(e),status:"removed",row:e})}),p}let ru=["active","description","group","name"],rm=new Set(["general.name","general.type","general.path"]),rg={general:"data-importer.review.section.general",dataSource:"data-importer.review.section.data-source",resolver:"data-importer.review.section.resolver",processing:"data-importer.review.section.processing",execution:"data-importer.review.section.execution",permissions:"data-importer.review.section.permissions"},rh={general:{tab:"general"},dataSource:{tab:"data-setup",step:0},resolver:{tab:"data-setup",step:2},mapping:{tab:"data-setup",step:3},processing:{tab:"data-setup",step:4},execution:{tab:"execution"},permissions:{tab:"permissions"}},rf={"loaderConfig.type":"data-importer.data-source.type-label","interpreterConfig.type":"data-importer.file-format.title","resolverConfig.dataObjectClassId":"data-importer.resolver.class","resolverConfig.loadingStrategy.type":"data-importer.resolver.loading-strategy","resolverConfig.createLocationStrategy.type":"data-importer.resolver.create-location-strategy","resolverConfig.locationUpdateStrategy.type":"data-importer.resolver.location-update-strategy","resolverConfig.publishingStrategy.type":"data-importer.resolver.publishing-strategy","processingConfig.executionType":"data-importer.processing.execution-type","processingConfig.idDataIndex":"data-importer.processing.id-data-index","processingConfig.doDeltaCheck":"data-importer.processing.delta-check","processingConfig.doDeltaCheckCheck":"data-importer.processing.delta-check","processingConfig.doArchiveImportFile":"data-importer.processing.archive-import-file","processingConfig.disableVersioning":"data-importer.processing.disable-versioning","processingConfig.cleanup.doCleanup":"data-importer.processing.cleanup.do-cleanup","processingConfig.cleanup.strategy":"data-importer.processing.cleanup.strategy","processingConfig.logging.disableInfoLogs":"data-importer.processing.logging.info.disable-logs","processingConfig.logging.disableInfoFileObjects":"data-importer.processing.logging.info.disable-file-objects","processingConfig.logging.disableErrorLogs":"data-importer.processing.logging.error.disable-logs","processingConfig.logging.disableErrorFileObjects":"data-importer.processing.logging.error.disable-file-objects","executionConfig.scheduleType":"data-importer.execution.schedule-type","executionConfig.cronDefinition":"data-importer.execution.cron-definition","executionConfig.scheduledAt":"data-importer.execution.scheduled-at"},rx={loadingStrategy:"data-importer.resolver.loading-strategy",createLocationStrategy:"data-importer.resolver.create-location-strategy",locationUpdateStrategy:"data-importer.resolver.location-update-strategy",publishingStrategy:"data-importer.resolver.publishing-strategy"},rv=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),ry=e=>{let t=e.replace(/([a-z0-9])([A-Z])/g,"$1 $2").replace(/[_-]+/g," ").trim();return t.charAt(0).toUpperCase()+t.slice(1)},rb=(e,t)=>{let a=e(t);return a===t?void 0:a},rj="data-importer.review",rS=e=>{let{label:t,active:a,onJump:r,styles:n}=e,{t:o}=(0,l.useTranslation)();return(0,i.jsxs)("button",{className:a?n.headlineActive:n.headline,onClick:r,title:o(`${rj}.open-section`),type:"button",children:[(0,i.jsx)("span",{children:t}),(0,i.jsx)(s.Icon,{options:{width:14,height:14},value:"arrow-narrow-right"})]})},rC=e=>{let{groups:t,mappings:a,activeSection:r,labelFor:n,onJump:o,styles:s}=e,{t:d}=(0,l.useTranslation)(),c=0===a.length?null:(0,i.jsxs)("div",{className:s.group,children:[(0,i.jsx)(rS,{active:"mapping"===r,label:d(`${rj}.mappings`),onJump:()=>{o("mapping")},styles:s}),(0,i.jsx)("ul",{className:s.items,children:a.map(e=>(0,i.jsxs)("li",{className:s.item,children:[(0,i.jsx)("span",{className:s.itemLabel,children:e.label}),"unchanged"!==e.status&&(0,i.jsx)(ax,{status:e.status})]},e.key))})]},"mapping"),p=t.map(e=>(0,i.jsxs)("div",{className:s.group,children:[(0,i.jsx)(rS,{active:r===e.section,label:d(e.label),onJump:()=>{o(e.section)},styles:s}),(0,i.jsx)("ul",{className:s.items,children:e.changes.map(e=>(0,i.jsxs)("li",{className:s.item,title:e.address,children:[(0,i.jsx)("span",{className:s.itemLabel,children:n(e)}),(0,i.jsx)(ax,{status:e.status})]},e.address))})]},e.section)),u=t.findIndex(e=>"resolver"===e.section),m=null===c?p:-1===u?[...p,c]:[...p.slice(0,u+1),c,...p.slice(u+1)];return(0,i.jsx)(i.Fragment,{children:m})},rI="data-importer.review.outline",rw=" \xb7 ",rT={csv:"import-csv",json:"json",xml:"code",xlsx:"table",sql:"table"},rD=(e,t,a)=>void 0===a||""===a?void 0:rb(e,`${t}.${a}`)??ry(a),rN=e=>e.filter(e=>void 0!==e&&""!==e),rF=e=>"string"==typeof e&&""!==e?e:void 0,rk=[{section:"general",keys:["general"],skip:new Set(["name","type","path","modificationDate","createDate","writeable"])},{section:"dataSource",keys:["loaderConfig","interpreterConfig"]},{section:"resolver",keys:["resolverConfig"]},{section:"processing",keys:["processingConfig"]},{section:"execution",keys:["executionConfig"]},{section:"permissions",keys:["permissions"]}],r$=(0,p.createStyles)(e=>{let{token:t,css:a}=e;return{card:a`
    background: ${t.colorBgContainer};
    border: 1px solid ${t.colorBorderSecondary};
    border-radius: ${t.borderRadiusLG}px;
    box-shadow: ${t.boxShadowTertiary};
    margin-right: ${t.margin}px;
  `,head:a`
    display: flex;
    flex-direction: column;
    gap: ${t.marginXXS}px;
    padding: ${t.padding}px ${t.padding}px ${t.paddingSM}px;
    border-bottom: 1px solid ${t.colorSplit};
  `,name:a`
    display: flex;
    align-items: center;
    gap: ${t.marginXS}px;
  `,nameText:a`
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-weight: ${t.fontWeightStrong};
    color: ${t.colorText};
  `,pill:a`
    flex: none;
    display: inline-flex;
    align-items: center;
    gap: ${t.marginXXS}px;
    height: ${t.controlHeightSM-4}px;
    padding: 0 ${t.paddingXS}px;
    border-radius: ${t.borderRadiusSM}px;
    background: ${t.colorFillTertiary};
    color: ${t.colorTextSecondary};
    font-size: ${t.fontSizeSM-1}px;
    font-weight: ${t.fontWeightStrong};
    line-height: 1;
  `,dot:a`
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: ${t.colorTextQuaternary};
  `,dotOn:a`
    background: ${t.colorSuccess};
  `,description:a`
    font-size: ${t.fontSizeSM}px;
    line-height: ${t.lineHeightSM};
    color: ${t.colorTextSecondary};
    overflow-wrap: anywhere;
  `,flow:a`
    display: grid;
    grid-template-columns: ${t.controlHeightSM}px minmax(0, 1fr);
    column-gap: ${t.marginSM}px;
    padding: ${t.padding}px;
  `,mark:a`
    display: flex;
    flex-direction: column;
    align-items: center;
  `,badge:a`
    flex: none;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: ${t.controlHeightSM}px;
    height: ${t.controlHeightSM}px;
    border-radius: 50%;
    background: ${t.colorPrimaryBg};
    color: ${t.colorPrimary};
  `,line:a`
    flex: 1;
    width: 1px;
    margin: ${t.marginXXS}px 0;
    background: ${t.colorPrimaryBorder};
  `,stop:a`
    min-width: 0;
    padding-bottom: ${t.padding}px;
  `,stopLast:a`
    min-width: 0;
  `,role:a`
    font-size: ${t.fontSizeSM-2}px;
    font-weight: ${t.fontWeightStrong};
    letter-spacing: .07em;
    text-transform: uppercase;
    color: ${t.colorTextTertiary};
    line-height: ${t.lineHeightSM};
  `,value:a`
    font-weight: ${t.fontWeightStrong};
    color: ${t.colorText};
    font-variant-numeric: tabular-nums;
    overflow-wrap: anywhere;
  `,note:a`
    font-size: ${t.fontSizeSM-1}px;
    line-height: ${t.lineHeightSM};
    color: ${t.colorTextSecondary};
    overflow-wrap: anywhere;
  `,foot:a`
    display: flex;
    flex-direction: column;
    gap: 2px;
    padding: ${t.paddingSM}px ${t.padding}px;
    border-top: 1px solid ${t.colorSplit};
    font-variant-numeric: tabular-nums;
  `,footLead:a`
    font-size: ${t.fontSizeSM}px;
    line-height: ${t.lineHeightSM};
    color: ${t.colorTextSecondary};
  `,footGroups:a`
    font-size: ${t.fontSizeSM-1}px;
    line-height: ${t.lineHeightSM};
    color: ${t.colorTextTertiary};
  `}}),rL="data-importer.review.outline",rM={width:14,height:14},rP=e=>{let{brief:t}=e,{t:a}=(0,l.useTranslation)(),{styles:r,cx:n}=r$();return(0,i.jsxs)("div",{className:r.card,children:[(0,i.jsxs)("div",{className:r.head,children:[(0,i.jsxs)("div",{className:r.name,children:[(0,i.jsx)("span",{className:r.nameText,children:t.name}),(0,i.jsxs)("span",{className:r.pill,children:[(0,i.jsx)("span",{className:n(r.dot,t.active&&r.dotOn)}),a(`${rL}.${t.active?"active":"inactive"}`)]})]}),void 0!==t.description&&(0,i.jsx)("div",{className:r.description,children:t.description})]}),(0,i.jsx)("div",{className:r.flow,children:t.stops.map((e,n)=>{let l=n===t.stops.length-1;return(0,i.jsxs)(o().Fragment,{children:[(0,i.jsxs)("div",{className:r.mark,children:[(0,i.jsx)("span",{className:r.badge,children:(0,i.jsx)(s.Icon,{options:rM,value:e.icon})}),!l&&(0,i.jsx)("span",{className:r.line})]}),(0,i.jsxs)("div",{className:l?r.stopLast:r.stop,children:[(0,i.jsx)("div",{className:r.role,children:a(e.role)}),(0,i.jsx)("div",{className:r.value,children:e.value}),void 0!==e.note&&(0,i.jsx)("div",{className:r.note,children:e.note})]})]},e.key)})}),t.groups.length>0&&(0,i.jsxs)("div",{className:r.foot,children:[(0,i.jsx)("div",{className:r.footLead,children:a(`${rL}.settings`,{count:t.total,sections:t.groups.length})}),(0,i.jsx)("div",{className:r.footGroups,children:t.groups.map(e=>`${a(e.label)} ${e.count}`).join(" \xb7 ")})]})]})},rR="data-importer.review",rA={merged:"success",discarded:"error",refined:"processing"},rO=e=>{let{state:t,resolvedAt:a,styles:r}=e,{t:n}=(0,l.useTranslation)(),o=null!=a&&Number.isFinite(a)&&a>0?new Date(a).toLocaleString():null;return(0,i.jsxs)("div",{className:r.history,children:[(0,i.jsxs)("div",{className:r.historyState,children:[(0,i.jsx)(s.Tag,{color:rA[t]??"default",children:n(`${rR}.state.${t}`,t)}),null!==o&&(0,i.jsx)("span",{children:n(`${rR}.resolved-at`,{when:o,interpolation:{escapeValue:!1}})})]}),(0,i.jsx)("div",{className:r.note,children:n(`${rR}.history-notice`)})]})},rE=(0,p.createStyles)(e=>{let{token:t,css:a}=e;return{layout:a`
    display: flex;
    align-items: stretch;
    gap: ${t.marginLG}px;
    height: 70vh;
    min-height: 420px;
  `,rail:a`
    width: 272px;
    flex: 0 0 272px;
    min-height: 0;
    display: flex;
    flex-direction: column;
    border-right: 1px solid ${t.colorBorderSecondary};
  `,list:a`
    flex: 1;
    min-height: 0;
    overflow-y: auto;
    overflow-x: hidden;
    padding-right: ${t.padding}px;
    display: flex;
    flex-direction: column;
    gap: ${t.marginMD}px;
  `,summary:a`
    padding: ${t.paddingXS}px 0 ${t.paddingXXS}px;
    font-size: ${t.fontSizeSM}px;
    font-weight: ${t.fontWeightStrong};
    letter-spacing: .08em;
    text-transform: uppercase;
    color: ${t.colorTextTertiary};
  `,history:a`
    display: flex;
    flex-direction: column;
    gap: ${t.marginXXS}px;
    padding: ${t.paddingXS}px ${t.padding}px ${t.paddingSM}px 0;
    border-bottom: 1px solid ${t.colorBorderSecondary};
    margin-bottom: ${t.marginXS}px;
  `,historyState:a`
    display: flex;
    align-items: center;
    gap: ${t.marginXS}px;
    color: ${t.colorTextSecondary};
  `,group:a`
    display: flex;
    flex-direction: column;
  `,headline:a`
    display: inline-flex;
    align-items: center;
    gap: ${t.marginXS}px;
    min-height: ${t.controlHeight}px;
    border: none;
    background: none;
    padding: 0;
    margin: 0;
    font: inherit;
    font-weight: ${t.fontWeightStrong};
    color: ${t.colorText};
    cursor: pointer;

    &:hover {
      color: ${t.colorPrimary};
    }
  `,headlineActive:a`
    display: inline-flex;
    align-items: center;
    gap: ${t.marginXS}px;
    min-height: ${t.controlHeight}px;
    border: none;
    background: none;
    padding: 0;
    margin: 0;
    font: inherit;
    font-weight: ${t.fontWeightStrong};
    color: ${t.colorPrimary};
    cursor: pointer;
  `,items:a`
    list-style: none;
    margin: 0;
    padding: 0;
  `,item:a`
    display: flex;
    align-items: center;
    gap: ${t.marginXS}px;
    min-height: ${t.controlHeightSM}px;
    padding: ${t.paddingXXS}px 0;
    border-bottom: 1px solid ${t.colorSplit};
    color: ${t.colorText};

    &:last-child {
      border-bottom: none;
    }
  `,itemLabel:a`
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  `,brief:a`
    display: flex;
    flex-direction: column;
    gap: ${t.marginSM}px;
    margin-right: ${t.margin}px;
  `,briefFlow:a`
    display: flex;
    flex-direction: column;
    padding: ${t.paddingSM}px;
    border: 1px solid ${t.colorBorderSecondary};
    border-radius: ${t.borderRadiusLG}px;
    background: ${t.colorFillQuaternary};
  `,briefStop:a`
    display: flex;
    align-items: center;
    gap: ${t.marginSM}px;
    min-width: 0;
  `,briefIcon:a`
    flex: 0 0 auto;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    background: ${t.colorBgContainer};
    border: 1px solid ${t.colorBorderSecondary};
    color: ${t.colorPrimary};
  `,briefText:a`
    display: flex;
    flex-direction: column;
    min-width: 0;
    line-height: ${t.lineHeightSM};
  `,briefLabel:a`
    font-weight: ${t.fontWeightStrong};
    color: ${t.colorText};
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  `,briefNote:a`
    font-size: ${t.fontSizeSM}px;
    color: ${t.colorTextSecondary};
  `,briefConnector:a`
    width: 1px;
    height: ${t.marginSM}px;
    margin: ${t.marginXXS}px 0 ${t.marginXXS}px 14px;
    background: ${t.colorBorder};
  `,briefTags:a`
    display: flex;
    flex-wrap: wrap;
    gap: ${t.marginXXS}px;
  `,note:a`
    font-size: ${t.fontSizeSM}px;
    color: ${t.colorTextTertiary};
  `,state:a`
    padding: ${t.paddingLG}px;
    color: ${t.colorTextSecondary};
  `,editor:a`
    flex: 1;
    min-width: 0;
    overflow: auto;
  `}}),rB="data-importer.review",rz=e=>{let{subjectRef:t,changeSetId:a,contextRef:r,mode:o="review",state:d,resolvedAt:c,onStatsChange:p}=e,{t:u}=(0,l.useTranslation)(),{styles:m}=rE(),{data:g,isLoading:h,error:f}=function(e,t){let[a,r]=(0,n.useState)({isLoading:!0});return(0,n.useEffect)(()=>{if(void 0===e||""===e)return void r({isLoading:!1,error:Error("no change set")});let a=!1,i=void 0!==t&&""!==t?`?contextRef=${encodeURIComponent(t)}`:"";return r({isLoading:!0}),fetch(`/pimcore-studio/api/bundle/change-control/change-sets/${encodeURIComponent(e)}/review${i}`,{headers:{Accept:"application/json"},credentials:"same-origin"}).then(async e=>{if(!e.ok)throw Error(`review request failed: ${e.status}`);return await e.json()}).then(e=>{a||r({data:e,isLoading:!1})}).catch(e=>{a||r({isLoading:!1,error:e})}),()=>{a=!0}},[e,t]),a}(a,r),x="history"===o,{data:v,isLoading:y,isError:b}=tu({name:t}),j=null==v?void 0:v.configuration,S=(0,l.useAppDispatch)(),C=(0,n.useMemo)(()=>(function(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"review";if(null==e)return[];let a=[];for(let[r,i]of Object.entries(e.slots??{})){if(r===ra)continue;let e=ri(i,t);for(let[t,n]of Object.entries(i.proposed??{})){if(rm.has(t))continue;let i=e[t];rr(i,n)||a.push({address:t,formPath:function(e){let t=e.split(".");return"general"===t[0]?t.length>1&&ru.includes(t[1])?t.slice(1).join("."):void 0:e}(t),label:t.split(".").pop()??t,section:r,status:void 0===i?"added":"changed",current:i,proposed:n})}}return a})(g,o),[g,o]),I=(0,n.useMemo)(()=>rp(g,o),[g,o]),w=(0,n.useMemo)(()=>(function(e,t){let a=arguments.length>2&&void 0!==arguments[2]?arguments[2]:"review",r=structuredClone(t??{});if(null==e)return r;for(let[t,i]of Object.entries(e.slots??{})){let n=i.proposed??{};if(t===ra){void 0!==n.mappingConfig&&(r.mappingConfig=rn(rp(e,a)));continue}for(let[e,t]of Object.entries(n))!function(e,t,a){let r=t.split("."),i=e;r.forEach((e,t)=>{if(t===r.length-1){i[e]=a;return}("object"!=typeof i[e]||null===i[e])&&(i[e]={}),i=i[e]})}(r,e,t)}return r})(g,j,o),[g,j,o]),T=(0,n.useMemo)(()=>(function(e){let t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"review",a=Object.values((null==e?void 0:e.slots)??{});return 0!==a.length&&a.every(e=>0===Object.keys(ri(e,t)).length)})(g,o),[g,o]),D=(0,n.useMemo)(()=>(function(e){let t=new Map;for(let a of e){let e=t.get(a.section)??[];e.push(a),t.set(a.section,e)}let a=[...Object.keys(rg),...t.keys()],r=new Set,i=[];for(let e of a){if(r.has(e))continue;r.add(e);let a=t.get(e);void 0!==a&&0!==a.length&&i.push({section:e,label:rg[e]??e,changes:a})}return i})(C),[C]),N=(0,n.useMemo)(()=>I.filter(e=>"unchanged"!==e.status),[I]),F=(0,n.useMemo)(()=>{var e,t,a;let r,i;return T?(r=[function(e,t){let a=e.loaderConfig,r=e.interpreterConfig,i=rN([rD(t,"data-importer.loader",null==a?void 0:a.type),rD(t,"data-importer.interpreter",null==r?void 0:r.type)]).join(rw);if(""!==i)return{key:"read",icon:rT[(null==r?void 0:r.type)??""]??"import",role:`${rI}.read`,value:i,note:function(e,t){if(void 0===t)return;let a=e=>rF(t[e]);switch(e){case"asset":return a("assetPath");case"http":return a("url");case"sftp":return rN([a("host"),a("remotePath")]).join(":");case"sql":return a("from");case"push":return a("endpoint");default:return}}(null==a?void 0:a.type,null==a?void 0:a.settings)}}(w,u),function(e,t){var a;let r=(null==(a=e.mappingConfig)?void 0:a.length)??0;if(0!==r)return{key:"map",icon:"many-to-many-relation",role:`${rI}.map`,value:t(`${rI}.mappings`,{count:r})}}(w,u),function(e,t){var a,r,i,n;if(void 0===e)return;let o=rF(e.dataObjectClassId),l="dataObject"===e.elementType&&void 0!==o?t(`${rI}.data-objects`,{class:o}):o??rD(t,"data-importer.resolver.element",e.elementType);if(void 0===l||""===l)return;let s=rD(t,"data-importer.resolver.location-strategy",null==(a=e.createLocationStrategy)?void 0:a.type),d=rN([void 0===s?void 0:rN([s,rF(null==(i=e.createLocationStrategy)||null==(r=i.settings)?void 0:r.path)]).join(" "),rD(t,"data-importer.resolver.publishing-strategy",null==(n=e.publishingStrategy)?void 0:n.type)]).join(rw);return{key:"write",icon:"data-object",role:`${rI}.write`,value:l,note:""===d?void 0:d}}(w.resolverConfig,u),function(e,t,a){var r;let i=rF(null==t?void 0:t.cronDefinition)??((null==t?void 0:t.scheduleType)==="job"?rF(t.scheduledAt):void 0)??rb(a,"data-importer.execution.manual-execution")??ry("manualExecution"),n=rD(a,"data-importer.processing.execution-type",null==e?void 0:e.executionType)??i;if(""===n)return;let o=(null==e?void 0:e.doDeltaCheck)===!0||(null==e?void 0:e.doDeltaCheckCheck)===!0,l=(null==e||null==(r=e.cleanup)?void 0:r.doCleanup)===!0?rN([rb(a,"data-importer.processing.cleanup.title")??ry("cleanup"),rD(a,"data-importer.processing.cleanup.strategy",e.cleanup.strategy)]).join(": "):void 0,s=rN([n===i?void 0:i,o?rb(a,"data-importer.processing.delta-check")??ry("deltaCheck"):void 0,l]).join(rw);return{key:"run",icon:"play",role:`${rI}.run`,value:n,note:""===s?void 0:s}}(w.processingConfig,w.executionConfig,u)].filter(e=>void 0!==e),i=rk.map(e=>{let{section:t,keys:a,skip:r}=e;return{section:t,label:rg[t]??t,count:a.reduce((e,t)=>e+function e(t,a){return Array.isArray(t)?t.length:"object"!=typeof t||null===t?+(void 0!==t&&""!==t&&!1!==t):Object.entries(t).filter(e=>{let[t]=e;return(null==a?void 0:a.has(t))!==!0}).reduce((t,a)=>{let[,r]=a;return t+e(r)},0)}(w[t],r),0)}}).filter(e=>e.count>0),{name:rF(null==(e=w.general)?void 0:e.name)??"",active:(null==(t=w.general)?void 0:t.active)===!0,description:rF(null==(a=w.general)?void 0:a.description),stops:r,groups:i,total:i.reduce((e,t)=>e+t.count,0)}):void 0},[T,w,u]);(0,n.useEffect)(()=>{b&&void 0!==g&&S(tp.util.upsertQueryData("bundleDataImporterConfigGet",{name:t},{name:t,configuration:w,userPermissions:{update:!1,delete:!1},modificationDate:0}))},[b,g,w,t,S]);let[k,$]=(0,n.useState)("general"),[L,M]=(0,n.useState)(void 0),P=(0,n.useRef)(null),R=(0,n.useRef)(!1),A=(0,n.useRef)(0),O=(0,n.useCallback)(function(){let e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:0,t=arguments.length>1&&void 0!==arguments[1]?arguments[1]:++A.current;if(t!==A.current)return;let a=P.current,r=null==a?void 0:a.querySelector(".ant-tabs-tabpane-active"),i=(null==r?[]:Array.from(r.querySelectorAll(".pimcore-form-item-annotated, [data-review-mark]"))).find(e=>e.getClientRects().length>0);if(null!==a&&void 0!==i){let e=a.getBoundingClientRect(),t=i.getBoundingClientRect();if(t.top>=e.top&&t.bottom<=e.bottom)return;i.scrollIntoView({block:"center"})}e<24&&window.setTimeout(()=>{O(e+1,t)},250)},[]);(0,n.useEffect)(()=>{if(!R.current)return;R.current=!1;let e=++A.current,t=window.setTimeout(()=>{O(0,e)},250);return()=>{window.clearTimeout(t)}},[k,L,O]),(0,n.useEffect)(()=>{void 0!==g&&(null==p||p(C.length+N.length))},[g,C.length,N.length,p]);let E=(0,n.useMemo)(()=>{let e;return T?{}:{...function(e){let t={};for(let a of e)void 0!==a.formPath&&(t[a.formPath]={status:a.status});return t}(C),...(e={},rp(g,o).forEach((t,a)=>{"unchanged"!==t.status&&(e[["mappingConfig",a].map(String).join(".")]={status:t.status})}),e)}},[T,C,g,o]),B=(0,n.useCallback)(e=>{let t=rh[e];if(void 0!==t){if(t.tab===k&&(t.step??L)===L)return void O();R.current=!0,$(t.tab),M(t.step)}},[k,L,O]),z=(0,n.useCallback)(e=>(function(e,t,a){var r,i;let n=rf[e];if(void 0!==n)return rb(a,n)??ry(e.split(".").pop()??e);let o=e.split("."),l=o[o.length-1];if("loaderConfig"===o[0]&&"settings"===o[1]){let e=(null==t||null==(r=t.loaderConfig)?void 0:r.type)??"";return rb(a,`data-importer.loader.${e}.${rv(l)}`)??ry(l)}if("interpreterConfig"===o[0]&&"settings"===o[1]){let e=(null==t||null==(i=t.interpreterConfig)?void 0:i.type)??"";return rb(a,`data-importer.interpreter.${e}.${rv(l)}`)??ry(l)}if("resolverConfig"===o[0]&&"settings"===o[2]&&void 0!==rx[o[1]]){let e=rb(a,rx[o[1]])??ry(o[1]);return`${e} \xb7 ${ry(l)}`}return ry(l)})(e.address,w,u),[w,u]),H=(0,n.useMemo)(()=>{var e;return null==(e=Object.entries(rh).find(e=>{let[,t]=e;return t.tab===k&&(void 0===t.step||t.step===L)}))?void 0:e[0]},[k,L]);if(null!=f)return(0,i.jsx)("div",{className:m.state,children:u(`${rB}.load-failed`)});if(h||y||void 0===g)return(0,i.jsx)(s.Content,{loading:!0});let q=(0,i.jsx)(tb,{scope:a,children:(0,i.jsx)(rt,{activeStep:L,activeTab:k,configName:t,configuration:w,isWriteable:!1,onSave:async()=>({}),onStepChange:M,onTabChange:$,showRuntime:!1})});return(0,i.jsxs)("div",{className:m.layout,children:[(0,i.jsxs)("aside",{className:m.rail,children:[x&&void 0!==d&&(0,i.jsx)(rO,{resolvedAt:c,state:d,styles:m}),void 0!==F?(0,i.jsxs)("div",{className:m.list,children:[(0,i.jsx)("div",{className:m.summary,children:u(`${rB}.new.title`)}),(0,i.jsx)(rP,{brief:F,styles:m})]}):(0,i.jsxs)("div",{className:m.list,children:[(0,i.jsx)("div",{className:m.summary,children:u(`${rB}.changes`,{count:C.length+N.length})}),(0,i.jsx)(rC,{activeSection:H,groups:D,labelFor:z,mappings:N,onJump:B,styles:m})]})]}),(0,i.jsx)("div",{className:m.editor,ref:P,children:null!==am?(0,i.jsx)(am,{annotations:E,children:q}):q})]})};var rH=a(1635);class rq extends P.DynamicTypeAbstract{}rq=(0,rH.Cg)([(0,l.injectable)()],rq);class rW extends P.DynamicTypeRegistryAbstract{getAllTypes(){return this.getDynamicTypes()}}rW=(0,rH.Cg)([(0,l.injectable)()],rW);let rV=(0,p.createStyles)(e=>{let{css:t}=e;return{label:t`
      font-size: 11px;
      white-space: nowrap;
    `,formItem:t`
      margin-bottom: 6px;
    `,formItemSwitch:t`
      margin-bottom: 0 !important;
      .ant-form-item-row {
        row-gap: 0;
      }
    `,formItemLast:t`
      margin-bottom: 0 !important;
      .ant-form-item-row {
        row-gap: 0;
      }
    `,noSettings:t`
      font-size: 11px;
    `}}),rX=e=>{let{children:t}=e,{styles:a}=rV();return(0,i.jsx)(P.FieldWidthProvider,{children:(0,i.jsx)(s.Form,{colon:!1,layout:"vertical",children:t(a)})})},r_=e=>{let{settings:t,onChange:a}=e;return(0,i.jsx)(rX,{children:e=>(0,i.jsx)(s.Form.Item,{className:e.formItemLast,label:(0,i.jsx)("span",{className:e.label,children:"Mode"}),children:(0,i.jsx)(s.Select,{onChange:e=>{a({...t,mode:e})},options:[{value:"both",label:"Both"},{value:"left",label:"Left"},{value:"right",label:"Right"}],value:t.mode??"both"})})})};class rG extends rq{renderSettings(e,t){return(0,i.jsx)(r_,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="trim",this.label="Trim",this.group="dataManipulation"}}rG=(0,rH.Cg)([(0,l.injectable)()],rG);let rU=e=>{let{settings:t,onChange:a}=e;return(0,i.jsx)(rX,{children:e=>(0,i.jsx)(s.Form.Item,{className:e.formItemLast,label:(0,i.jsx)("span",{className:e.label,children:"Glue"}),children:(0,i.jsx)(s.Input,{onChange:e=>{var r;r=e.target.value,a({...t,glue:r})},value:t.glue??" "})})})};class rK extends rq{renderSettings(e,t){return(0,i.jsx)(rU,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="combine",this.label="Combine",this.group="dataManipulation"}}rK=(0,rH.Cg)([(0,l.injectable)()],rK);let rQ=e=>{let{settings:t,onChange:a}=e,r=(e,r)=>{a({...t,[e]:r})};return(0,i.jsx)(rX,{children:e=>(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(s.Form.Item,{className:e.formItem,label:(0,i.jsx)("span",{className:e.label,children:"Mode"}),children:(0,i.jsx)(s.Select,{onChange:e=>{r("mode",e)},options:[{value:"append",label:"Append"},{value:"prepend",label:"Prepend"}],value:t.mode??"append"})}),(0,i.jsx)(s.Form.Item,{className:e.formItem,label:(0,i.jsx)("span",{className:e.label,children:"Text"}),children:(0,i.jsx)(s.Input,{onChange:e=>{r("text",e.target.value)},value:t.text??""})}),(0,i.jsx)(s.Form.Item,{className:e.formItemLast,children:(0,i.jsx)(s.Switch,{checked:t.alwaysAdd??!1,labelRight:"Always add",onChange:e=>{r("alwaysAdd",e)},size:"small"})})]})})};class rY extends rq{renderSettings(e,t){return(0,i.jsx)(rQ,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="staticText",this.label="Static Text",this.group="dataManipulation"}}rY=(0,rH.Cg)([(0,l.injectable)()],rY);let rJ=e=>{let{settings:t,onChange:a}=e,r=(e,r)=>{a({...t,[e]:r})};return(0,i.jsx)(rX,{children:e=>(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(s.Form.Item,{className:e.formItem,label:(0,i.jsx)("span",{className:e.label,children:"Search"}),children:(0,i.jsx)(s.Input,{onChange:e=>{r("search",e.target.value)},value:t.search??""})}),(0,i.jsx)(s.Form.Item,{className:e.formItemLast,label:(0,i.jsx)("span",{className:e.label,children:"Replace"}),children:(0,i.jsx)(s.Input,{onChange:e=>{r("replace",e.target.value)},value:t.replace??""})})]})})};class rZ extends rq{renderSettings(e,t){return(0,i.jsx)(rJ,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="stringReplace",this.label="String Replace",this.group="dataManipulation"}}rZ=(0,rH.Cg)([(0,l.injectable)()],rZ);let r0=e=>{let{settings:t,onChange:a}=e;return(0,i.jsx)(rX,{children:e=>(0,i.jsx)(s.Form.Item,{className:e.formItemLast,label:(0,i.jsx)("span",{className:e.label,children:"Format"}),children:(0,i.jsx)(s.Input,{onChange:e=>{var r;r=e.target.value,a({...t,format:r})},placeholder:"Y-m-d",value:t.format??"Y-m-d"})})})};class r1 extends rq{renderSettings(e,t){return(0,i.jsx)(r0,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="date",this.label="Date",this.group="dataTypes"}}r1=(0,rH.Cg)([(0,l.injectable)()],r1);let r2=e=>{let{settings:t,onChange:a}=e;return(0,i.jsx)(rX,{children:e=>(0,i.jsx)(s.Form.Item,{className:e.formItemLast,children:(0,i.jsx)(s.Switch,{checked:t.returnNullIfEmpty??!1,labelRight:"Return null if empty",onChange:e=>{a({...t,returnNullIfEmpty:e})},size:"small"})})})};class r3 extends rq{renderSettings(e,t){return(0,i.jsx)(r2,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="numeric",this.label="Numeric",this.group="dataTypes"}}r3=(0,rH.Cg)([(0,l.injectable)()],r3);let r5=e=>{let{settings:t,onChange:a}=e,r=(e,r)=>{a({...t,[e]:r})};return(0,i.jsx)(rX,{children:e=>(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(s.Form.Item,{className:e.formItem,label:(0,i.jsx)("span",{className:e.label,children:"Delimiter"}),children:(0,i.jsx)(s.Input,{onChange:e=>{r("delimiter",e.target.value)},value:t.delimiter??""})}),(0,i.jsx)(s.Form.Item,{className:e.formItemLast,children:(0,i.jsx)(s.Switch,{checked:t.keepSubArrays??!1,labelRight:"Keep sub-arrays",onChange:e=>{r("keepSubArrays",e)},size:"small"})})]})})};class r9 extends rq{renderSettings(e,t){return(0,i.jsx)(r5,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="explode",this.label="Explode",this.group="dataManipulation"}}r9=(0,rH.Cg)([(0,l.injectable)()],r9);let r6=e=>{let{settings:t,onChange:a}=e,r=(e,r)=>{a({...t,[e]:r})};return(0,i.jsx)(rX,{children:e=>(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(s.Form.Item,{className:e.formItem,label:(0,i.jsx)("span",{className:e.label,children:"Original"}),children:(0,i.jsx)(s.Input,{onChange:e=>{r("original",e.target.value)},value:t.original??""})}),(0,i.jsx)(s.Form.Item,{className:e.formItemLast,label:(0,i.jsx)("span",{className:e.label,children:"Converted"}),children:(0,i.jsx)(s.Input,{onChange:e=>{r("converted",e.target.value)},value:t.converted??""})})]})})};class r4 extends rq{renderSettings(e,t){return(0,i.jsx)(r6,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="conditionalConversion",this.label="Conditional Conversion",this.group="dataManipulation"}}r4=(0,rH.Cg)([(0,l.injectable)()],r4);let r8=e=>{let{settings:t,onChange:a}=e,r=(e,r)=>{a({...t,[e]:r})};return(0,i.jsx)(rX,{children:e=>(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(s.Form.Item,{className:e.formItem,label:(0,i.jsx)("span",{className:e.label,children:"Attribute"}),children:(0,i.jsx)(s.Input,{onChange:e=>{r("attribute",e.target.value)},value:t.attribute??""})}),(0,i.jsx)(s.Form.Item,{className:e.formItemLast,label:(0,i.jsx)("span",{className:e.label,children:"Forward parameter"}),children:(0,i.jsx)(s.Input,{onChange:e=>{r("forward_parameter",e.target.value)},value:t.forward_parameter??""})})]})})};class r7 extends rq{renderSettings(e,t){return(0,i.jsx)(r8,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="objectField",this.label="Object Field",this.group="dataManipulation"}}r7=(0,rH.Cg)([(0,l.injectable)()],r7);let ie=e=>{let{settings:t,onChange:a}=e;return(0,i.jsx)(rX,{children:e=>(0,i.jsx)(s.Form.Item,{className:e.formItemLast,label:(0,i.jsx)("span",{className:e.label,children:"Load strategy"}),children:(0,i.jsx)(s.Select,{onChange:e=>{a({...t,loadStrategy:e})},options:[{value:"path",label:"By path"},{value:"id",label:"By ID"}],value:t.loadStrategy??"path"})})})};class it extends rq{renderSettings(e,t){return(0,i.jsx)(ie,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="loadAsset",this.label="Load Asset",this.group="loadImport"}}it=(0,rH.Cg)([(0,l.injectable)()],it);let ia=new Set(["id","path","key"]),ir=e=>{let{settings:t,onChange:a}=e,r=(e,r)=>{a({...t,[e]:r})},o=(0,c.useSettings)(),l=(0,n.useMemo)(()=>(o.validLanguages??[]).map(e=>({value:e,label:e})),[o.validLanguages]),{data:d,isLoading:p}=(0,tT.useClassDefinitionCollectionQuery)(),u=((null==d?void 0:d.items)??[]).map(e=>({value:e.id,label:e.name})),m=t.loadStrategy??"id",g="attribute"===m,h=t.attributeDataObjectClassId??"",f=t.attributeName,{data:x,isLoading:v}=ts({classId:h,systemRead:!0},{skip:""===h||!g}),y=(0,n.useMemo)(()=>((null==x?void 0:x.attributes)??[]).map(e=>({key:e.key??e.name??"",title:e.title??e.name??e.key??"",localized:!!e.localized})),[x]),b=y.map(e=>({value:e.key,label:e.title})),j=y.find(e=>e.key===f),S=(null==j?void 0:j.localized)??!1,C=g&&null!=f&&""!==f&&!ia.has(f);return(0,i.jsx)(rX,{children:e=>(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(s.Form.Item,{className:e.formItem,label:(0,i.jsx)("span",{className:e.label,children:"Load strategy"}),children:(0,i.jsx)(s.Select,{onChange:e=>{r("loadStrategy",e),"attribute"!==e&&a({...t,loadStrategy:e,attributeDataObjectClassId:void 0,attributeName:void 0,loadUnpublished:void 0})},options:[{value:"id",label:"By ID"},{value:"path",label:"By Path"},{value:"attribute",label:"By Attribute"}],value:m})}),g&&(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(s.Form.Item,{className:e.formItem,label:(0,i.jsx)("span",{className:e.label,children:"Class"}),children:(0,i.jsx)(s.Select,{loadingSkeleton:p,onChange:e=>{a({...t,attributeDataObjectClassId:e,attributeName:void 0})},options:u,value:""!==h?h:void 0})}),(0,i.jsx)(s.Form.Item,{className:e.formItem,label:(0,i.jsx)("span",{className:e.label,children:"Attribute name"}),children:(0,i.jsx)(s.Select,{loadingSkeleton:v,onChange:e=>{r("attributeName",e)},options:b,value:f})}),C&&(0,i.jsx)(s.Form.Item,{className:e.formItemSwitch,children:(0,i.jsx)(s.Switch,{checked:!!t.partialMatch,labelRight:"Accept partial match",onChange:e=>{r("partialMatch",e)},size:"small"})}),S&&(0,i.jsx)(s.Form.Item,{className:e.formItem,label:(0,i.jsx)("span",{className:e.label,children:"Language"}),children:(0,i.jsx)(s.Select,{onChange:e=>{r("attributeLanguage",e)},options:l,value:t.attributeLanguage})}),(0,i.jsx)(s.Form.Item,{className:e.formItemLast,children:(0,i.jsx)(s.Switch,{checked:!!t.loadUnpublished,labelRight:"Load unpublished",onChange:e=>{r("loadUnpublished",e)},size:"small"})})]}),g?null:(0,i.jsx)("div",{style:{height:0}})]})})};class ii extends rq{renderSettings(e,t){return(0,i.jsx)(ir,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="loadDataObject",this.label="Load Data Object",this.group="loadImport"}}ii=(0,rH.Cg)([(0,l.injectable)()],ii);let io=e=>{let{settings:t,onChange:a}=e,r=(e,r)=>{a({...t,[e]:r})},o=t.unitSourceSelect??"id",{data:l,isLoading:d}=td(),c=(0,n.useMemo)(()=>((null==l?void 0:l.unitList)??[]).map(e=>({value:e.unitId??"",label:e.abbreviation??e.unitId??""})),[l]);return(0,i.jsx)(rX,{children:e=>(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(s.Form.Item,{className:e.formItem,label:(0,i.jsx)("span",{className:e.label,children:"Unit source"}),children:(0,i.jsx)(s.Select,{onChange:e=>{a({...t,unitSourceSelect:e,staticUnitSelect:void 0})},options:[{value:"id",label:"By Unit ID"},{value:"abbr",label:"By Abbreviation"},{value:"static",label:"Static"}],value:o})}),"static"===o&&(0,i.jsx)(s.Form.Item,{className:e.formItem,label:(0,i.jsx)("span",{className:e.label,children:"Unit"}),children:(0,i.jsx)(s.Select,{loadingSkeleton:d,onChange:e=>{r("staticUnitSelect",e)},options:c,showSearch:!0,value:t.staticUnitSelect})}),(0,i.jsx)(s.Form.Item,{className:e.formItemLast,children:(0,i.jsx)(s.Switch,{checked:!!t.unitNullIfNoValueCheckbox,labelRight:"Null if no value",onChange:e=>{r("unitNullIfNoValueCheckbox",e)},size:"small"})})]})})};class il extends rq{renderSettings(e,t){return(0,i.jsx)(io,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="quantityValue",this.label="Quantity Value",this.group="dataTypes"}}il=(0,rH.Cg)([(0,l.injectable)()],il);let is=e=>{let{settings:t,onChange:a}=e,r=(e,r)=>{a({...t,[e]:r})};return(0,i.jsx)(rX,{children:e=>(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(s.Form.Item,{className:e.formItem,label:(0,i.jsx)("span",{className:e.label,children:"Parent folder"}),children:(0,i.jsx)(s.ManyToOneRelationPath,{allowPathTextInput:!0,allowToClearRelation:!0,allowedAssetTypes:["folder"],assetsAllowed:!0,onChange:e=>{r("parentFolder",e??"/")},value:t.parentFolder??"/"})}),(0,i.jsx)(s.Form.Item,{className:e.formItemSwitch,children:(0,i.jsx)(s.Switch,{checked:!1!==t.useExisting,labelRight:"Use existing",onChange:e=>{r("useExisting",e)},size:"small"})}),(0,i.jsx)(s.Form.Item,{className:e.formItemSwitch,children:(0,i.jsx)(s.Switch,{checked:!0===t.overwriteExisting,labelRight:"Overwrite existing",onChange:e=>{r("overwriteExisting",e)},size:"small"})}),(0,i.jsx)(s.Form.Item,{className:e.formItemLast,label:(0,i.jsx)("span",{className:e.label,children:"Preg match"}),children:(0,i.jsx)(s.Input,{onChange:e=>{r("pregMatch",e.target.value)},value:t.pregMatch??""})})]})})};class id extends rq{renderSettings(e,t){return(0,i.jsx)(is,{onChange:t,settings:e})}constructor(...e){super(...e),this.id="importAsset",this.label="Import Asset",this.group="loadImport"}}id=(0,rH.Cg)([(0,l.injectable)()],id);let ic=()=>{let{styles:e}=rV();return(0,i.jsx)(s.Text,{className:e.noSettings,type:"secondary",children:"No additional settings"})};function ip(e,t,a){class r extends rq{renderSettings(){return(0,i.jsx)(ic,{})}constructor(...r){super(...r),this.id=e,this.label=t,this.group=a}}return(0,rH.Cg)([(0,l.injectable)()],r)}let iu=ip("flattenArray","Flatten Array","dataManipulation"),im=ip("reduceArrayKeyValuePairs","Reduce Array Key-Value Pairs","dataManipulation"),ig=ip("htmlDecode","HTML Decode","dataManipulation"),ih=ip("boolean","Boolean","dataTypes"),ix=ip("asArray","As Array","dataTypes"),iv=ip("asColor","As Color","dataTypes"),iy=ip("asCountries","As Countries","dataTypes"),ib=ip("gallery","Gallery","dataTypes"),ij=ip("imageAdvanced","Image Advanced","dataTypes"),iS=ip("quantityValueArray","Quantity Value Array","dataTypes"),iC=ip("inputQuantityValue","Input Quantity Value","dataTypes"),iI=ip("inputQuantityValueArray","Input Quantity Value Array","dataTypes"),iw=ip("asGeobounds","As Geobounds","dataTypes"),iT=ip("asGeopoint","As Geopoint","dataTypes"),iD=ip("asGeopolygon","As Geopolygon","dataTypes"),iN=ip("asGeopolyline","As Geopolyline","dataTypes");class iF extends P.DynamicTypeRegistryAbstract{}iF=(0,rH.Cg)([(0,l.injectable)()],iF);class ik extends P.DynamicTypeAbstract{}ik=(0,rH.Cg)([(0,l.injectable)()],ik);let i$=()=>{let{t:e}=(0,l.useTranslation)(),t=t=>({async validator(a){let r=arguments.length>1&&void 0!==arguments[1]?arguments[1]:"";r.length<=1?await Promise.resolve():await Promise.reject(Error(e("data-importer.interpreter.csv.single-char-only",{field:t})))}});return(0,i.jsxs)(s.FormKit.Panel,{children:[(0,i.jsx)(s.Form.Item,{name:["interpreterConfig","settings","skipFirstRow"],valuePropName:"checked",children:(0,i.jsx)(s.Switch,{labelRight:e("data-importer.interpreter.csv.skip-first-row")})}),(0,i.jsx)(s.Form.Item,{name:["interpreterConfig","settings","saveHeaderName"],valuePropName:"checked",children:(0,i.jsx)(s.Switch,{labelRight:e("data-importer.interpreter.csv.save-header-name")})}),(0,i.jsx)(s.Form.Item,{initialValue:",",label:e("data-importer.interpreter.csv.delimiter"),name:["interpreterConfig","settings","delimiter"],required:!0,rules:[{required:!0,message:e("data-importer.interpreter.csv.required",{field:e("data-importer.interpreter.csv.delimiter")})},t(e("data-importer.interpreter.csv.delimiter"))],children:(0,i.jsx)(s.Input,{})}),(0,i.jsx)(s.Form.Item,{initialValue:'"',label:e("data-importer.interpreter.csv.enclosure"),name:["interpreterConfig","settings","enclosure"],required:!0,rules:[{required:!0,message:e("data-importer.interpreter.csv.required",{field:e("data-importer.interpreter.csv.enclosure")})},t(e("data-importer.interpreter.csv.enclosure"))],children:(0,i.jsx)(s.Input,{})}),(0,i.jsx)(s.Form.Item,{initialValue:"\\",label:e("data-importer.interpreter.csv.escape"),name:["interpreterConfig","settings","escape"],required:!0,rules:[t(e("data-importer.interpreter.csv.escape"))],children:(0,i.jsx)(s.Input,{})})]})};class iL extends ik{renderSettings(){return(0,i.jsx)(i$,{})}constructor(...e){super(...e),this.id="csv",this.label="data-importer.interpreter.csv"}}iL=(0,rH.Cg)([(0,l.injectable)()],iL);let iM=()=>{let{t:e}=(0,l.useTranslation)();return(0,i.jsx)(s.Form.Item,{label:e("data-importer.interpreter.json.path"),name:["interpreterConfig","settings","path"],children:(0,i.jsx)(s.Input,{placeholder:"data[*]"})})};class iP extends ik{renderSettings(){return(0,i.jsx)(iM,{})}constructor(...e){super(...e),this.id="json",this.label="data-importer.interpreter.json"}}iP=(0,rH.Cg)([(0,l.injectable)()],iP);let iR=()=>{let{t:e}=(0,l.useTranslation)();return(0,i.jsx)(s.Alert,{message:e("data-importer.interpreter.sql.info"),type:"info"})};class iA extends ik{renderSettings(){return(0,i.jsx)(iR,{})}constructor(...e){super(...e),this.id="sql",this.label="data-importer.interpreter.sql"}}iA=(0,rH.Cg)([(0,l.injectable)()],iA);let iO=(0,p.createStyles)(e=>{let{css:t}=e;return{monoTextArea:t`
      font-family: monospace;
    `}}),iE=()=>{let{t:e}=(0,l.useTranslation)(),{styles:t}=iO();return(0,i.jsxs)(s.FormKit.Panel,{children:[(0,i.jsx)(s.Form.Item,{initialValue:"/root/item",label:e("data-importer.interpreter.xml.xpath"),name:["interpreterConfig","settings","xpath"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.interpreter.xml.xpath")})}],children:(0,i.jsx)(s.Input,{})}),(0,i.jsx)(s.Form.Item,{label:e("data-importer.interpreter.xml.schema"),name:["interpreterConfig","settings","schema"],children:(0,i.jsx)(s.TextArea,{className:t.monoTextArea,rows:6})})]})};class iB extends ik{renderSettings(){return(0,i.jsx)(iE,{})}constructor(...e){super(...e),this.id="xml",this.label="data-importer.interpreter.xml"}}iB=(0,rH.Cg)([(0,l.injectable)()],iB);let iz=()=>{let{t:e}=(0,l.useTranslation)();return(0,i.jsxs)(s.FormKit.Panel,{children:[(0,i.jsx)(s.Form.Item,{name:["interpreterConfig","settings","skipFirstRow"],valuePropName:"checked",children:(0,i.jsx)(s.Switch,{labelRight:e("data-importer.interpreter.xlsx.skip-first-row")})}),(0,i.jsx)(s.Form.Item,{initialValue:"Sheet1",label:e("data-importer.interpreter.xlsx.sheet-name"),name:["interpreterConfig","settings","sheetName"],children:(0,i.jsx)(s.Input,{})})]})};class iH extends ik{renderSettings(){return(0,i.jsx)(iz,{})}constructor(...e){super(...e),this.id="xlsx",this.label="data-importer.interpreter.xlsx"}}iH=(0,rH.Cg)([(0,l.injectable)()],iH);class iq extends P.DynamicTypeRegistryAbstract{}iq=(0,rH.Cg)([(0,l.injectable)()],iq);class iW extends P.DynamicTypeAbstract{}iW=(0,rH.Cg)([(0,l.injectable)()],iW);let iV=()=>{let{t:e}=(0,l.useTranslation)();return(0,i.jsx)(s.Form.Item,{label:e("data-importer.loader.asset.asset-path"),name:["loaderConfig","settings","assetPath"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.asset.asset-path")})}],children:(0,i.jsx)(s.ManyToOneRelationPath,{allowPathTextInput:!0,allowedAssetTypes:["text","document","unknown"],assetsAllowed:!0})})};class iX extends iW{renderSettings(e){return(0,i.jsx)(iV,{})}constructor(...e){super(...e),this.id="asset",this.label="data-importer.loader.asset"}}iX=(0,rH.Cg)([(0,l.injectable)()],iX);let i_=e=>{let{configName:t}=e,{t:a}=(0,l.useTranslation)(),r=s.Form.useFormInstance(),[o,d]=(0,n.useState)(!1),{data:c,isFetching:p,isLoading:u,isError:m,refetch:g}=tg({name:t}),h=`${(0,eZ.getPrefix)()}/bundle/data-importer/config/${t}/upload-import-file`;(0,n.useEffect)(()=>{let e=(null==c?void 0:c.filePath)??"";(r.getFieldValue(["loaderConfig","settings","uploadFilePath"])??"")!==e&&r.setFieldValue(["loaderConfig","settings","uploadFilePath"],e,{triggerChange:!1})},[null==c?void 0:c.filePath,r]);let f=(null==c?void 0:c.exists)===!0,x=u||p&&void 0===c,v=(null==c?void 0:c.message)??a(f?"data-importer.loader.upload.file-uploaded":"data-importer.loader.upload.no-file");return(0,i.jsxs)(s.Space,{direction:"vertical",size:"small",children:[x?(0,i.jsx)(s.Spin,{type:"classic"}):(0,i.jsx)(s.Alert,{message:v,type:m?"error":f?"success":"warning"}),(0,i.jsx)(s.Form.Item,{hidden:!0,name:["loaderConfig","settings","uploadFilePath"],children:(0,i.jsx)(s.Input,{})}),(0,i.jsx)(s.Button,{onClick:()=>{d(!0)},type:"primary",children:a("data-importer.loader.upload.open-upload")}),(0,i.jsx)(s.ImportModal,{action:h,onOpenChange:d,onUploadSuccess:()=>{g()},open:o,title:a("data-importer.loader.upload.modal-title")})]})};class iG extends iW{renderSettings(e){return(0,i.jsx)(i_,{configName:e})}constructor(...e){super(...e),this.id="upload",this.label="data-importer.loader.upload"}}iG=(0,rH.Cg)([(0,l.injectable)()],iG);let iU=()=>{let{t:e}=(0,l.useTranslation)();return(0,i.jsxs)(s.FormKit.Panel,{children:[(0,i.jsx)(s.Form.Item,{label:e("data-importer.loader.http.schema"),name:["loaderConfig","settings","schema"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.http.schema")})}],children:(0,i.jsx)(s.Select,{filterOption:E,options:[{value:"https://",label:"HTTPS"},{value:"http://",label:"HTTP"}],showSearch:!0})}),(0,i.jsx)(s.Form.Item,{label:e("data-importer.loader.http.url"),name:["loaderConfig","settings","url"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.http.url")})}],children:(0,i.jsx)(s.Input,{placeholder:"example.com/data.csv"})})]})};class iK extends iW{renderSettings(e){return(0,i.jsx)(iU,{})}constructor(...e){super(...e),this.id="http",this.label="data-importer.loader.http"}}iK=(0,rH.Cg)([(0,l.injectable)()],iK);let iQ=()=>{let{t:e}=(0,l.useTranslation)();return(0,i.jsxs)(s.FormKit.Panel,{children:[(0,i.jsx)(s.Form.Item,{label:e("data-importer.loader.sftp.host"),name:["loaderConfig","settings","host"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.sftp.host")})}],children:(0,i.jsx)(s.Input,{placeholder:"example.com"})}),(0,i.jsx)(s.Form.Item,{initialValue:22,label:e("data-importer.loader.sftp.port"),name:["loaderConfig","settings","port"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.sftp.port")})}],children:(0,i.jsx)(s.InputNumber,{max:65535,min:1})}),(0,i.jsx)(s.Form.Item,{label:e("data-importer.loader.sftp.username"),name:["loaderConfig","settings","username"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.sftp.username")})}],children:(0,i.jsx)(s.Input,{})}),(0,i.jsx)(s.Form.Item,{label:e("data-importer.loader.sftp.password"),name:["loaderConfig","settings","password"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.sftp.password")})}],children:(0,i.jsx)(s.InputPassword,{})}),(0,i.jsx)(s.Form.Item,{label:e("data-importer.loader.sftp.remote-path"),name:["loaderConfig","settings","remotePath"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.sftp.remote-path")})}],children:(0,i.jsx)(s.Input,{placeholder:"/path/to/file.csv"})})]})};class iY extends iW{renderSettings(e){return(0,i.jsx)(iQ,{})}constructor(...e){super(...e),this.id="sftp",this.label="data-importer.loader.sftp"}}iY=(0,rH.Cg)([(0,l.injectable)()],iY);let iJ=(0,p.createStyles)(e=>{let{css:t}=e;return{fullWidth:t`
      width: 100%;
    `}}),iZ=()=>{let{t:e}=(0,l.useTranslation)(),{styles:t}=iJ(),a=s.Form.useFormInstance(),r=s.Form.useWatch(["name"]),n=`${window.location.protocol}//${window.location.host}/pimcore-datahub-import/${r??""}/push`;return(0,i.jsxs)(s.FormKit.Panel,{children:[(0,i.jsx)(s.Form.Item,{label:e("data-importer.loader.push.api-key"),required:!0,children:(0,i.jsxs)(s.Compact,{className:t.fullWidth,children:[(0,i.jsx)(s.Form.Item,{name:["loaderConfig","settings","apiKey"],noStyle:!0,rules:[{required:!0,message:e("data-importer.loader.push.api-key-required")},{min:16,message:e("data-importer.loader.push.api-key-min-length")}],children:(0,i.jsx)(s.Input,{})}),(0,i.jsx)(s.Button,{htmlType:"button",icon:(0,i.jsx)(s.Icon,{value:"reload"}),onClick:()=>{let e=(0,tq.v4)();a.setFieldValue(["loaderConfig","settings","apiKey"],e,{triggerChange:!0})},type:"default",children:e("data-importer.loader.push.api-key.generate")})]})}),(0,i.jsx)(s.Form.Item,{name:["loaderConfig","settings","ignoreNotEmptyQueue"],valuePropName:"checked",children:(0,i.jsx)(s.Switch,{labelRight:e("data-importer.loader.push.ignore-not-empty-queue")})}),(0,i.jsx)(s.Form.Item,{label:e("data-importer.loader.push.endpoint"),children:(0,i.jsx)(s.Alert,{message:n,type:"info"})})]})};class i0 extends iW{renderSettings(e){return(0,i.jsx)(iZ,{})}constructor(...e){super(...e),this.id="push",this.label="data-importer.loader.push"}}i0=(0,rH.Cg)([(0,l.injectable)()],i0);let i1=()=>{let{t:e}=(0,l.useTranslation)(),{data:t,isLoading:a}=tv(),r=(null==t?void 0:t.connections.map(e=>({value:e.value??"",label:e.name??""})))??[];return(0,i.jsxs)(s.FormKit.Panel,{children:[(0,i.jsx)(s.Form.Item,{label:e("data-importer.loader.sql.connection"),name:["loaderConfig","settings","connection"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.sql.connection")})}],children:(0,i.jsx)(s.Select,{filterOption:E,loadingSkeleton:a,options:r,showSearch:!0})}),(0,i.jsx)(s.Form.Item,{label:e("data-importer.loader.sql.select"),name:["loaderConfig","settings","select"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.sql.select")})}],children:(0,i.jsx)(s.TextArea,{placeholder:"a, b, c",rows:4})}),(0,i.jsx)(s.Form.Item,{label:e("data-importer.loader.sql.from"),name:["loaderConfig","settings","from"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.loader.sql.from")})}],children:(0,i.jsx)(s.TextArea,{placeholder:"table_name INNER JOIN other_table ON condition",rows:4})}),(0,i.jsx)(s.Form.Item,{label:e("data-importer.loader.sql.where"),name:["loaderConfig","settings","where"],children:(0,i.jsx)(s.TextArea,{placeholder:"column = 'value'",rows:4})}),(0,i.jsx)(s.Form.Item,{label:e("data-importer.loader.sql.group-by"),name:["loaderConfig","settings","groupBy"],children:(0,i.jsx)(s.TextArea,{placeholder:"column1, column2",rows:4})})]})};class i2 extends iW{renderSettings(e){return(0,i.jsx)(i1,{})}constructor(...e){super(...e),this.id="sql",this.label="data-importer.loader.sql"}}i2=(0,rH.Cg)([(0,l.injectable)()],i2);class i3 extends P.DynamicTypeRegistryAbstract{}i3=(0,rH.Cg)([(0,l.injectable)()],i3);class i5 extends P.DynamicTypeAbstract{getTypeErrorMessage(e){}getDefaultSettings(e){return e}}i5=(0,rH.Cg)([(0,l.injectable)()],i5);let i9=e=>{let{showOverwriteMode:t=!1,settings:a,onChange:r}=e,{t:o}=(0,l.useTranslation)(),{styles:d}=ae();return(0,n.useEffect)(()=>{(null==a?void 0:a.writeIfTargetIsNotEmpty)!==!0&&((null==a?void 0:a.overwriteMode)!==void 0||(null==a?void 0:a.writeIfSourceIsEmpty)===!0)&&r({...a,overwriteMode:void 0,writeIfSourceIsEmpty:!1})},[null==a?void 0:a.writeIfTargetIsNotEmpty,null==a?void 0:a.overwriteMode,null==a?void 0:a.writeIfSourceIsEmpty]),(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)("div",{className:d.overwriteLabel,children:o("data-importer.mapping.advanced-modal.step-target.overwrite")}),(0,i.jsx)(s.Switch,{checked:(null==a?void 0:a.writeIfTargetIsNotEmpty)??!0,labelRight:(0,i.jsx)("span",{className:d.switchLabel,children:o("data-importer.mapping.advanced-modal.write-if-target-not-empty")}),onChange:e=>{r({...a,writeIfTargetIsNotEmpty:e,writeIfSourceIsEmpty:e})},size:"small",tooltip:o("data-importer.mapping.advanced-modal.step-target.write-if-target-not-empty.tooltip")}),t&&(0,i.jsxs)("div",{children:[(0,i.jsx)("div",{className:d.fieldLabel,children:o("data-importer.mapping.advanced-modal.step-target.overwrite-mode")}),(0,i.jsx)("div",{className:d.selectSkeletonWrapper,children:(0,i.jsx)(s.Select,{className:d.selectFull,onChange:e=>{r({...a,overwriteMode:e})},options:[{value:"replace",label:o("data-importer.mapping.advanced-modal.step-target.overwrite-mode.replace")},{value:"merge",label:o("data-importer.mapping.advanced-modal.step-target.overwrite-mode.merge")}],value:null==a?void 0:a.overwriteMode})})]}),(0,i.jsx)(s.Switch,{checked:(null==a?void 0:a.writeIfSourceIsEmpty)??!0,disabled:!((null==a?void 0:a.writeIfTargetIsNotEmpty)??!0),labelRight:(0,i.jsx)("span",{className:d.switchLabel,children:o("data-importer.mapping.advanced-modal.write-if-source-empty")}),onChange:e=>{r({...a,writeIfSourceIsEmpty:e})},size:"small",tooltip:o("data-importer.mapping.advanced-modal.step-target.write-if-source-empty.tooltip")})]})};function i6(e){let{options:t,isLoading:a,value:r,onChange:n}=e,{t:o}=(0,l.useTranslation)(),{styles:d}=ae();return(0,i.jsxs)("div",{children:[(0,i.jsx)("div",{className:d.fieldLabel,children:o("data-importer.mapping.advanced-modal.step-target.field-name")}),(0,i.jsx)("div",{className:d.selectSkeletonWrapper,children:(0,i.jsx)(s.Select,{className:d.selectFull,loadingSkeleton:a,onChange:n,options:t,showSearch:!0,value:r})})]})}function i4(e){let{value:t,onChange:a}=e,{t:r}=(0,l.useTranslation)(),{styles:o}=ae(),d=function(){let{validLanguages:e}=(0,c.useSettings)();return(0,n.useMemo)(()=>(e??[]).map(e=>({value:e,label:e})),[e])}();return(0,i.jsxs)("div",{children:[(0,i.jsx)("div",{className:o.fieldLabel,children:r("data-importer.mapping.item.data-target.language-placeholder")}),(0,i.jsx)("div",{className:o.selectSkeletonWrapper,children:(0,i.jsx)(s.Select,{className:o.selectFull,onChange:a,options:d,showSearch:!0,value:t})})]})}function i8(e){let{isLocalized:t,settings:a,onChange:r,classFieldOptions:n}=e;return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(i6,{onChange:e=>{r({...a,fieldName:e})},options:n,value:null==a?void 0:a.fieldName}),t&&(0,i.jsx)(i4,{onChange:e=>{r({...a,language:e})},value:null==a?void 0:a.language}),(0,i.jsx)(i9,{onChange:r,settings:a})]})}class i7 extends i5{supportsType(e){return!0}getDefaultSettings(e){return{...e,overwriteMode:void 0,keyId:void 0,fieldName:null==e?void 0:e.fieldName,language:null==e?void 0:e.language,writeIfTargetIsNotEmpty:(null==e?void 0:e.writeIfTargetIsNotEmpty)??!0,writeIfSourceIsEmpty:(null==e?void 0:e.writeIfSourceIsEmpty)??!0}}renderSettings(e){return(0,i.jsx)(i8,{...e})}constructor(...e){super(...e),this.id="direct",this.label="data-importer.mapping.item.data-target.type.direct"}}let ne=(0,p.createStyles)(e=>{let{css:t,token:a}=e;return{toolbar:t`
      margin-bottom: ${a.paddingSM}px;
    `,search:t`
      width: 320px;
      max-width: 100%;
    `,paginationRow:t`
      margin-top: ${a.paddingSM}px;
    `,footer:t`
      margin-top: ${a.paddingSM}px;
    `}}),nt=(0,eJ.createColumnHelper)(),na=e=>{let{open:t,classId:a,fieldName:r,transformationResultType:o,onClose:d,onSelect:c}=e,{t:p}=(0,l.useTranslation)(),{styles:u}=ne(),m=(0,l.useAppDispatch)(),[g,h]=(0,n.useState)(""),[f,x]=(0,n.useState)(1),[v,y]=(0,n.useState)(10),[b,j]=(0,n.useState)(null);(0,n.useEffect)(()=>{t&&(h(""),x(1),j(null))},[t]);let{data:S,isFetching:C}=e3({classId:a,fieldName:r,transformationResultType:o,start:(f-1)*v,limit:v,searchfilter:""===g?void 0:g},{skip:!t}),I=(null==S?void 0:S.data)??[],w=(null==S?void 0:S.total)??0,T=(0,n.useMemo)(()=>[nt.accessor("groupName",{header:p("classification-store.column.group")}),nt.accessor("keyName",{header:p("classification-store.column.name")}),nt.accessor("keyDescription",{header:p("classification-store.column.description")})],[p]),D=null===b?{}:{[b]:!0};return(0,i.jsxs)(s.Modal,{footer:null,onCancel:d,open:t,size:"XL",title:p("data-importer.mapping.advanced-modal.step-target.classification-store-key-modal.title"),children:[(0,i.jsxs)(s.Flex,{align:"center",className:u.toolbar,gap:"small",justify:"space-between",children:[(0,i.jsx)(s.Text,{children:p("data-importer.mapping.advanced-modal.step-target.classification-store-key-modal.description")}),(0,i.jsx)(s.SearchInput,{className:u.search,onChange:e=>{h(e.target.value),x(1)},placeholder:p("data-importer.mapping.advanced-modal.step-source.search-placeholder"),value:g,withClear:!0,withPrefix:!0})]}),(0,i.jsx)(s.Grid,{autoWidth:!0,columns:T,data:I,enableMultipleRowSelection:!1,enableRowSelection:!0,isLoading:C,onSelectedRowsChange:e=>{let t="function"==typeof e?e(D):e;j(Object.keys(t).find(e=>t[e])??null)},selectedRows:D,setRowId:(e,t)=>e.id??String(t)}),(0,i.jsx)(s.Flex,{className:u.paginationRow,justify:"flex-end",children:(0,i.jsx)(s.Pagination,{current:f,defaultPageSize:v,onChange:(e,t)=>{x(e),y(t)},showSizeChanger:!0,showTotal:e=>p("pagination.show-total",{total:e}),total:w})}),(0,i.jsxs)(s.Flex,{className:u.footer,gap:"extra-small",justify:"flex-end",children:[(0,i.jsx)(s.Button,{onClick:d,type:"default",children:p("cancel")}),(0,i.jsx)(s.Button,{disabled:null===b,onClick:()=>{if(null!==b){let e=I.find(e=>e.id===b);void 0!==e&&m(tp.util.upsertQueryData("bundleDataImporterClassificationstoreLoadKeyName",{keyId:b},{keyId:b,groupName:e.groupName,keyName:e.keyName})),c(b)}},type:"primary",children:p("common.apply-selection")})]})]})};function nr(e){let{classId:t,fieldName:a,transformationResultType:r,keyId:o,onChange:d}=e,{t:c}=(0,l.useTranslation)(),{styles:p}=ae(),[u,m]=(0,n.useState)(!1),{data:g}=e2({keyId:o??""},{skip:void 0===o||""===o}),h=(0,n.useMemo)(()=>void 0===o||""===o?c("data-importer.mapping.advanced-modal.step-target.classification-store-key-placeholder"):(null==g?void 0:g.groupName)!==void 0&&(null==g?void 0:g.keyName)!==void 0?c("data-importer.mapping.advanced-modal.step-target.classification-store-key-in-group",{key:g.keyName,group:g.groupName}):o,[o,null==g?void 0:g.groupName,null==g?void 0:g.keyName,c]);return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(na,{classId:t,fieldName:a,onClose:()=>{m(!1)},onSelect:e=>{d(e),m(!1)},open:u,transformationResultType:r??""}),(0,i.jsxs)("div",{children:[(0,i.jsx)("div",{className:p.fieldLabel,children:c("data-importer.mapping.advanced-modal.step-target.classification-store-key")}),(0,i.jsxs)(s.Flex,{align:"center",gap:"extra-small",children:[(0,i.jsx)(s.Input,{className:p.classificationStoreKeyInput,readOnly:!0,value:h}),(0,i.jsx)(s.Button,{onClick:()=>{m(!0)},type:"default",children:c("search")})]})]})]})}function ni(e){let{classId:t,settings:a,transformationResultType:r,onChange:i}=e,{data:o,isFetching:l}=e1({classId:t??""},{skip:void 0===t}),s=(0,n.useMemo)(()=>((null==o?void 0:o.attributes)??[]).filter(e=>void 0!==e.key).map(e=>({key:e.key??"",title:e.title??e.name??e.key??"",localized:e.localized??!1})),[null==o?void 0:o.attributes]),d=(0,n.useMemo)(()=>{var e;return(null==(e=s.find(e=>e.key===(null==a?void 0:a.fieldName)))?void 0:e.localized)??!1},[s,null==a?void 0:a.fieldName]),c=(0,n.useMemo)(()=>s.map(e=>({value:e.key,label:e.title})),[s]),p=(0,n.useRef)(r);return(0,n.useEffect)(()=>{p.current!==r&&(p.current=r,(null==a?void 0:a.keyId)!==void 0&&i({...a,keyId:void 0}))},[r,null==a?void 0:a.keyId]),{attributes:s,options:c,isFetching:l,isLocalized:d}}function nn(e){let{classId:t,settings:a,transformationResultType:r,onChange:n}=e,{options:o,isLocalized:l,isFetching:s}=ni(e),d=null==a?void 0:a.fieldName;return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(i6,{isLoading:s,onChange:e=>{n({...a,fieldName:e})},options:o,value:null==a?void 0:a.fieldName}),void 0!==d&&""!==d&&(0,i.jsx)(nr,{classId:t??"",fieldName:d,keyId:null==a?void 0:a.keyId,onChange:e=>{n({...a,keyId:e})},transformationResultType:r}),l&&(0,i.jsx)(i4,{onChange:e=>{n({...a,language:e})},value:null==a?void 0:a.language})]})}class no extends i5{supportsType(e){return!0}getDefaultSettings(e){return{...e,overwriteMode:void 0,keyId:null==e?void 0:e.keyId,fieldName:void 0,language:void 0}}renderSettings(e){return(0,i.jsx)(nn,{...e})}constructor(...e){super(...e),this.id="classificationstore",this.label="data-importer.mapping.item.data-target.type.classificationstore"}}function nl(e){let{settings:t,onChange:a}=e,{options:r,isLocalized:n,isFetching:o}=ni(e);return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(i6,{isLoading:o,onChange:e=>{a({...t,fieldName:e})},options:r,value:null==t?void 0:t.fieldName}),n&&(0,i.jsx)(i4,{onChange:e=>{a({...t,language:e})},value:null==t?void 0:t.language})]})}class ns extends i5{supportsType(e){return["array","quantityValueArray","inputQuantityValueArray","dateArray"].includes(e??"")}getTypeErrorMessage(e){return e("data-importer.mapping.advanced-modal.step-target.type-error.classificationstoreBatch")}getDefaultSettings(e){return{...e,overwriteMode:void 0,keyId:null==e?void 0:e.keyId,fieldName:void 0,language:void 0}}renderSettings(e){return(0,i.jsx)(nl,{...e})}constructor(...e){super(...e),this.id="classificationstoreBatch",this.label="data-importer.mapping.item.data-target.type.classificationstoreBatch"}}function nd(e){let{isLocalized:t,settings:a,onChange:r,classFieldOptions:n}=e;return(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(i6,{onChange:e=>{r({...a,fieldName:e})},options:n,value:null==a?void 0:a.fieldName}),t&&(0,i.jsx)(i4,{onChange:e=>{r({...a,language:e})},value:null==a?void 0:a.language}),(0,i.jsx)(i9,{onChange:r,settings:a,showOverwriteMode:(null==a?void 0:a.writeIfTargetIsNotEmpty)??!0})]})}class nc extends i5{supportsType(e){return["advancedDataObjectArray","dataObjectArray","assetArray","advancedAssetArray"].includes(e??"")}getTypeErrorMessage(e){return e("data-importer.mapping.advanced-modal.step-target.type-error.manyToManyRelation")}getDefaultSettings(e){return{...e,overwriteMode:null==e?void 0:e.overwriteMode,keyId:void 0,fieldName:null==e?void 0:e.fieldName,language:null==e?void 0:e.language,writeIfTargetIsNotEmpty:(null==e?void 0:e.writeIfTargetIsNotEmpty)??!0,writeIfSourceIsEmpty:(null==e?void 0:e.writeIfSourceIsEmpty)??!0}}renderSettings(e){return(0,i.jsx)(nd,{...e})}constructor(...e){super(...e),this.id="manyToManyRelation",this.label="data-importer.mapping.item.data-target.type.manyToManyRelation"}}class np extends P.DynamicTypeRegistryAbstract{getDynamicTypesForGroup(e){return this.getDynamicTypes().filter(t=>t.group===e)}}np=(0,rH.Cg)([(0,l.injectable)()],np);class nu extends P.DynamicTypeAbstract{}nu=(0,rH.Cg)([(0,l.injectable)()],nu);class nm extends nu{renderSettings(){return null}constructor(...e){super(...e),this.id="loading.notLoad",this.type="notLoad",this.label="data-importer.resolver.loading-strategy.notLoad",this.group="loading"}}function ng(e){let{columnHeaderOptions:t}=e,{t:a}=(0,l.useTranslation)();return(0,i.jsx)(O,{theme:"fieldset",title:a("data-importer.resolver.loading-strategy.id"),children:(0,i.jsx)(s.Form.Item,{label:a("data-importer.resolver.loading-strategy.data-source-index"),name:["resolverConfig","loadingStrategy","settings","dataSourceIndex"],children:(0,i.jsx)(s.Select,{filterOption:E,options:t,placeholder:a("data-importer.resolver.loading-strategy.data-source-index-placeholder"),showSearch:!0})})})}nm=(0,rH.Cg)([(0,l.injectable)()],nm);class nh extends nu{renderSettings(e){return(0,i.jsx)(ng,{...e})}constructor(...e){super(...e),this.id="loading.id",this.type="id",this.label="data-importer.resolver.loading-strategy.id",this.group="loading"}}function nf(e){let{columnHeaderOptions:t}=e,{t:a}=(0,l.useTranslation)();return(0,i.jsx)(O,{theme:"fieldset",title:a("data-importer.resolver.loading-strategy.path"),children:(0,i.jsx)(s.Form.Item,{label:a("data-importer.resolver.loading-strategy.data-source-index"),name:["resolverConfig","loadingStrategy","settings","dataSourceIndex"],children:(0,i.jsx)(s.Select,{filterOption:E,options:t,placeholder:a("data-importer.resolver.loading-strategy.data-source-index-placeholder"),showSearch:!0})})})}nh=(0,rH.Cg)([(0,l.injectable)()],nh);class nx extends nu{renderSettings(e){return(0,i.jsx)(nf,{...e})}constructor(...e){super(...e),this.id="loading.path",this.type="path",this.label="data-importer.resolver.loading-strategy.path",this.group="loading"}}function nv(e){let{columnHeaderOptions:t,languageOptions:a=[]}=e,{t:r}=(0,l.useTranslation)(),o=s.Form.useWatch(["resolverConfig","dataObjectClassId"]),d=s.Form.useWatch(["resolverConfig","loadingStrategy","settings","attributeName"]),{data:c,isLoading:p}=ts({classId:o??""},{skip:void 0===o||""===o}),u=(0,n.useMemo)(()=>((null==c?void 0:c.attributes)??[]).map(an),[c]),m=(0,n.useMemo)(()=>u.map(e=>({value:e.key,label:e.title})),[u]),g=(0,n.useMemo)(()=>{var e;return(null==(e=u.find(e=>e.key===d))?void 0:e.localized)??!1},[u,d]);return(0,i.jsxs)(O,{theme:"fieldset",title:r("data-importer.resolver.loading-strategy.attribute"),children:[(0,i.jsx)(s.Form.Item,{label:r("data-importer.resolver.loading-strategy.data-source-index"),name:["resolverConfig","loadingStrategy","settings","dataSourceIndex"],children:(0,i.jsx)(s.Select,{filterOption:E,options:t,placeholder:r("data-importer.resolver.loading-strategy.data-source-index-placeholder"),showSearch:!0})}),(0,i.jsx)(s.Form.Item,{label:r("data-importer.resolver.loading-strategy.attribute-name"),name:["resolverConfig","loadingStrategy","settings","attributeName"],children:(0,i.jsx)(s.Select,{filterOption:E,loadingSkeleton:p,options:m,placeholder:r("data-importer.resolver.loading-strategy.attribute-name-placeholder"),showSearch:!0})}),g&&(0,i.jsx)(s.Form.Item,{label:r("data-importer.resolver.loading-strategy.language"),name:["resolverConfig","loadingStrategy","settings","language"],children:(0,i.jsx)(s.Select,{filterOption:E,options:a,placeholder:r("data-importer.resolver.loading-strategy.language-placeholder"),showSearch:!0})}),(0,i.jsx)(s.Form.Item,{name:["resolverConfig","loadingStrategy","settings","includeUnpublished"],valuePropName:"checked",children:(0,i.jsx)(s.Switch,{labelRight:r("data-importer.resolver.loading-strategy.include-unpublished"),size:"small"})})]})}nx=(0,rH.Cg)([(0,l.injectable)()],nx);class ny extends nu{renderSettings(e){return(0,i.jsx)(nv,{...e})}constructor(...e){super(...e),this.id="loading.attribute",this.type="attribute",this.label="data-importer.resolver.loading-strategy.attribute",this.group="loading"}}function nb(){let{t:e}=(0,l.useTranslation)();return(0,i.jsx)(O,{theme:"fieldset",title:e("data-importer.resolver.location-strategy.staticPath"),children:(0,i.jsx)(s.Form.Item,{label:e("data-importer.resolver.location-strategy.path"),name:["resolverConfig","createLocationStrategy","settings","path"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.resolver.location-strategy.path")})}],children:(0,i.jsx)(s.ManyToOneRelationPath,{allowPathTextInput:!0,allowedDataObjectTypes:["folder"],dataObjectsAllowed:!0})})})}ny=(0,rH.Cg)([(0,l.injectable)()],ny);class nj extends nu{renderSettings(){return(0,i.jsx)(nb,{})}constructor(...e){super(...e),this.id="createLocation.staticPath",this.type="staticPath",this.label="data-importer.resolver.location-strategy.staticPath",this.group="createLocation"}}function nS(e){let{columnHeaderOptions:t}=e,{t:a}=(0,l.useTranslation)();return(0,i.jsxs)(O,{theme:"fieldset",title:a("data-importer.resolver.location-strategy.findOrCreateFolder"),children:[(0,i.jsx)(s.Form.Item,{label:a("data-importer.resolver.location-strategy.data-source-index"),name:["resolverConfig","createLocationStrategy","settings","dataSourceIndex"],children:(0,i.jsx)(s.Select,{filterOption:E,options:t,placeholder:a("data-importer.resolver.location-strategy.data-source-index-placeholder"),showSearch:!0})}),(0,i.jsx)(s.Form.Item,{label:a("data-importer.resolver.location-strategy.fallback-path"),name:["resolverConfig","createLocationStrategy","settings","fallbackPath"],tooltip:a("data-importer.resolver.location-strategy.fallback-path.tooltip"),children:(0,i.jsx)(s.Input,{placeholder:a("data-importer.resolver.location-strategy.fallback-path-placeholder")})})]})}nj=(0,rH.Cg)([(0,l.injectable)()],nj);class nC extends nu{renderSettings(e){return(0,i.jsx)(nS,{...e})}constructor(...e){super(...e),this.id="createLocation.findOrCreateFolder",this.type="findOrCreateFolder",this.label="data-importer.resolver.location-strategy.findOrCreateFolder",this.group="createLocation"}}function nI(e){var t;let{columnHeaderOptions:a,classOptions:r,isLoadingClasses:o,languageOptions:d=[]}=e,{t:c}=(0,l.useTranslation)(),p=s.Form.useWatch(["resolverConfig","createLocationStrategy","settings","findStrategy"]),u=s.Form.useWatch(["resolverConfig","createLocationStrategy","settings","attributeDataObjectClassId"]),m=s.Form.useWatch(["resolverConfig","createLocationStrategy","settings","attributeName"]),g=[{value:"id",label:c("data-importer.resolver.location-strategy.find-strategy.id")},{value:"path",label:c("data-importer.resolver.location-strategy.find-strategy.path")},{value:"attribute",label:c("data-importer.resolver.location-strategy.find-strategy.attribute")}],{data:h,isLoading:f}=ts({classId:u??"",systemRead:!0},{skip:void 0===u||""===u||"attribute"!==p}),x=(0,n.useMemo)(()=>((null==h?void 0:h.attributes)??[]).map(an),[h]),v=x.map(e=>({value:e.key,label:e.title})),y=(null==(t=x.find(e=>e.key===m))?void 0:t.localized)??!1;return(0,i.jsxs)(O,{theme:"fieldset",title:c("data-importer.resolver.location-strategy.findParent"),children:[(0,i.jsx)(s.Form.Item,{label:c("data-importer.resolver.location-strategy.find-strategy"),name:["resolverConfig","createLocationStrategy","settings","findStrategy"],children:(0,i.jsx)(s.Select,{filterOption:E,options:g,showSearch:!0})}),"attribute"===p&&(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(s.Form.Item,{label:c("data-importer.resolver.location-strategy.attribute-class"),name:["resolverConfig","createLocationStrategy","settings","attributeDataObjectClassId"],children:(0,i.jsx)(s.Select,{filterOption:E,loadingSkeleton:o,options:r,showSearch:!0})}),(0,i.jsx)(s.Form.Item,{label:c("data-importer.resolver.location-strategy.attribute-name"),name:["resolverConfig","createLocationStrategy","settings","attributeName"],children:(0,i.jsx)(s.Select,{filterOption:E,loadingSkeleton:f,options:v,showSearch:!0})}),y&&(0,i.jsx)(s.Form.Item,{label:c("data-importer.resolver.location-strategy.attribute-language"),name:["resolverConfig","createLocationStrategy","settings","attributeLanguage"],children:(0,i.jsx)(s.Select,{filterOption:E,options:d,showSearch:!0})})]}),(0,i.jsx)(s.Form.Item,{label:c("data-importer.resolver.location-strategy.data-source-index"),name:["resolverConfig","createLocationStrategy","settings","dataSourceIndex"],children:(0,i.jsx)(s.Select,{filterOption:E,options:a,placeholder:c("data-importer.resolver.location-strategy.data-source-index-placeholder"),showSearch:!0})}),(0,i.jsx)(s.Form.Item,{label:c("data-importer.resolver.location-strategy.fallback-path"),name:["resolverConfig","createLocationStrategy","settings","fallbackPath"],tooltip:c("data-importer.resolver.location-strategy.fallback-path.tooltip"),children:(0,i.jsx)(s.Input,{placeholder:c("data-importer.resolver.location-strategy.fallback-path-placeholder")})}),(0,i.jsx)(s.Form.Item,{name:["resolverConfig","createLocationStrategy","settings","asVariant"],valuePropName:"checked",children:(0,i.jsx)(s.Switch,{labelRight:c("data-importer.resolver.location-strategy.as-variant"),size:"small"})})]})}nC=(0,rH.Cg)([(0,l.injectable)()],nC);class nw extends nu{renderSettings(e){return(0,i.jsx)(nI,{...e})}constructor(...e){super(...e),this.id="createLocation.findParent",this.type="findParent",this.label="data-importer.resolver.location-strategy.findParent",this.group="createLocation"}}nw=(0,rH.Cg)([(0,l.injectable)()],nw);class nT extends nu{renderSettings(){return null}constructor(...e){super(...e),this.id="createLocation.doNotCreate",this.type="doNotCreate",this.label="data-importer.resolver.location-strategy.doNotCreate",this.group="createLocation"}}nT=(0,rH.Cg)([(0,l.injectable)()],nT);class nD extends nu{renderSettings(){return null}constructor(...e){super(...e),this.id="updateLocation.noChange",this.type="noChange",this.label="data-importer.resolver.location-strategy.noChange",this.group="updateLocation"}}function nN(){let{t:e}=(0,l.useTranslation)();return(0,i.jsx)(O,{theme:"fieldset",title:e("data-importer.resolver.location-strategy.staticPath"),children:(0,i.jsx)(s.Form.Item,{label:e("data-importer.resolver.location-strategy.path"),name:["resolverConfig","locationUpdateStrategy","settings","path"],required:!0,rules:[{required:!0,message:e("data-importer.validation.required",{field:e("data-importer.resolver.location-strategy.path")})}],children:(0,i.jsx)(s.ManyToOneRelationPath,{allowPathTextInput:!0,allowedDataObjectTypes:["folder"],dataObjectsAllowed:!0})})})}nD=(0,rH.Cg)([(0,l.injectable)()],nD);class nF extends nu{renderSettings(){return(0,i.jsx)(nN,{})}constructor(...e){super(...e),this.id="updateLocation.staticPath",this.type="staticPath",this.label="data-importer.resolver.location-strategy.staticPath",this.group="updateLocation"}}function nk(e){let{columnHeaderOptions:t}=e,{t:a}=(0,l.useTranslation)();return(0,i.jsxs)(O,{theme:"fieldset",title:a("data-importer.resolver.location-strategy.findOrCreateFolder"),children:[(0,i.jsx)(s.Form.Item,{label:a("data-importer.resolver.location-strategy.data-source-index"),name:["resolverConfig","locationUpdateStrategy","settings","dataSourceIndex"],children:(0,i.jsx)(s.Select,{filterOption:E,options:t,placeholder:a("data-importer.resolver.location-strategy.data-source-index-placeholder"),showSearch:!0})}),(0,i.jsx)(s.Form.Item,{label:a("data-importer.resolver.location-strategy.fallback-path"),name:["resolverConfig","locationUpdateStrategy","settings","fallbackPath"],tooltip:a("data-importer.resolver.location-strategy.fallback-path.tooltip"),children:(0,i.jsx)(s.Input,{placeholder:a("data-importer.resolver.location-strategy.fallback-path-placeholder")})})]})}nF=(0,rH.Cg)([(0,l.injectable)()],nF);class n$ extends nu{renderSettings(e){return(0,i.jsx)(nk,{...e})}constructor(...e){super(...e),this.id="updateLocation.findOrCreateFolder",this.type="findOrCreateFolder",this.label="data-importer.resolver.location-strategy.findOrCreateFolder",this.group="updateLocation"}}function nL(e){var t;let{columnHeaderOptions:a,classOptions:r,languageOptions:o=[]}=e,{t:d}=(0,l.useTranslation)(),c=s.Form.useWatch(["resolverConfig","locationUpdateStrategy","settings","findStrategy"]),p=s.Form.useWatch(["resolverConfig","locationUpdateStrategy","settings","attributeDataObjectClassId"]),u=s.Form.useWatch(["resolverConfig","locationUpdateStrategy","settings","attributeName"]),{data:m}=ts({classId:p??"",systemRead:!0},{skip:void 0===p||""===p||"attribute"!==c}),g=(0,n.useMemo)(()=>((null==m?void 0:m.attributes)??[]).map(an),[m]),h=g.map(e=>({value:e.key,label:e.title})),f=(null==(t=g.find(e=>e.key===u))?void 0:t.localized)??!1,x=[{value:"id",label:d("data-importer.resolver.location-strategy.find-strategy.id")},{value:"path",label:d("data-importer.resolver.location-strategy.find-strategy.path")},{value:"attribute",label:d("data-importer.resolver.location-strategy.find-strategy.attribute")}];return(0,i.jsxs)(O,{theme:"fieldset",title:d("data-importer.resolver.location-strategy.findParent"),children:[(0,i.jsx)(s.Form.Item,{label:d("data-importer.resolver.location-strategy.find-strategy"),name:["resolverConfig","locationUpdateStrategy","settings","findStrategy"],children:(0,i.jsx)(s.Select,{filterOption:E,options:x,showSearch:!0})}),"attribute"===c&&(0,i.jsxs)(i.Fragment,{children:[(0,i.jsx)(s.Form.Item,{label:d("data-importer.resolver.location-strategy.attribute-class"),name:["resolverConfig","locationUpdateStrategy","settings","attributeDataObjectClassId"],children:(0,i.jsx)(s.Select,{filterOption:E,options:r,showSearch:!0})}),(0,i.jsx)(s.Form.Item,{label:d("data-importer.resolver.location-strategy.attribute-name"),name:["resolverConfig","locationUpdateStrategy","settings","attributeName"],children:(0,i.jsx)(s.Select,{filterOption:E,options:h,showSearch:!0})}),f&&(0,i.jsx)(s.Form.Item,{label:d("data-importer.resolver.location-strategy.attribute-language"),name:["resolverConfig","locationUpdateStrategy","settings","attributeLanguage"],children:(0,i.jsx)(s.Select,{filterOption:E,options:o,showSearch:!0})})]}),(0,i.jsx)(s.Form.Item,{label:d("data-importer.resolver.location-strategy.data-source-index"),name:["resolverConfig","locationUpdateStrategy","settings","dataSourceIndex"],children:(0,i.jsx)(s.Select,{filterOption:E,options:a,placeholder:d("data-importer.resolver.location-strategy.data-source-index-placeholder"),showSearch:!0})}),(0,i.jsx)(s.Form.Item,{label:d("data-importer.resolver.location-strategy.fallback-path"),name:["resolverConfig","locationUpdateStrategy","settings","fallbackPath"],tooltip:d("data-importer.resolver.location-strategy.fallback-path.tooltip"),children:(0,i.jsx)(s.Input,{placeholder:d("data-importer.resolver.location-strategy.fallback-path-placeholder")})}),(0,i.jsx)(s.Form.Item,{name:["resolverConfig","locationUpdateStrategy","settings","asVariant"],valuePropName:"checked",children:(0,i.jsx)(s.Switch,{labelRight:d("data-importer.resolver.location-strategy.as-variant"),size:"small"})})]})}n$=(0,rH.Cg)([(0,l.injectable)()],n$);class nM extends nu{renderSettings(e){return(0,i.jsx)(nL,{...e})}constructor(...e){super(...e),this.id="updateLocation.findParent",this.type="findParent",this.label="data-importer.resolver.location-strategy.findParent",this.group="updateLocation"}}nM=(0,rH.Cg)([(0,l.injectable)()],nM);class nP extends nu{renderSettings(){return null}constructor(...e){super(...e),this.id="publishing.noChangeUnpublishNew",this.type="noChangeUnpublishNew",this.label="data-importer.resolver.publishing-strategy.noChangeUnpublishNew",this.group="publishing"}}nP=(0,rH.Cg)([(0,l.injectable)()],nP);class nR extends nu{renderSettings(){return null}constructor(...e){super(...e),this.id="publishing.noChangePublishNew",this.type="noChangePublishNew",this.label="data-importer.resolver.publishing-strategy.noChangePublishNew",this.group="publishing"}}nR=(0,rH.Cg)([(0,l.injectable)()],nR);class nA extends nu{renderSettings(){return null}constructor(...e){super(...e),this.id="publishing.alwaysPublish",this.type="alwaysPublish",this.label="data-importer.resolver.publishing-strategy.alwaysPublish",this.group="publishing"}}function nO(e){let{columnHeaderOptions:t}=e,{t:a}=(0,l.useTranslation)();return(0,i.jsx)(O,{theme:"fieldset",title:a("data-importer.resolver.publishing-strategy.attributeBased"),children:(0,i.jsx)(s.Form.Item,{label:a("data-importer.resolver.publishing-strategy.data-source-index"),name:["resolverConfig","publishingStrategy","settings","dataSourceIndex"],children:(0,i.jsx)(s.Select,{filterOption:E,options:t,placeholder:a("data-importer.resolver.publishing-strategy.data-source-index-placeholder"),showSearch:!0})})})}nA=(0,rH.Cg)([(0,l.injectable)()],nA);class nE extends nu{renderSettings(e){return(0,i.jsx)(nO,{...e})}constructor(...e){super(...e),this.id="publishing.attributeBased",this.type="attributeBased",this.label="data-importer.resolver.publishing-strategy.attributeBased",this.group="publishing"}}nE=(0,rH.Cg)([(0,l.injectable)()],nE);let nB={onInit:()=>{r.container.get(d.bundleServiceIds["DataHub/DynamicTypes/Adapter/Registry"]).registerDynamicType(r.container.get(B)),r.container.bind(z).to(iF).inSingletonScope(),r.container.bind(H).to(iL).inSingletonScope(),r.container.bind(q).to(iP).inSingletonScope(),r.container.bind(X).to(iB).inSingletonScope(),r.container.bind(V).to(iH).inSingletonScope(),r.container.bind(W).to(iA).inSingletonScope();let e=r.container.get(z);e.registerDynamicType(r.container.get(H)),e.registerDynamicType(r.container.get(q)),e.registerDynamicType(r.container.get(X)),e.registerDynamicType(r.container.get(V)),e.registerDynamicType(r.container.get(W)),r.container.bind(_).to(iq).inSingletonScope(),r.container.bind(G).to(iX).inSingletonScope(),r.container.bind(U).to(iG).inSingletonScope(),r.container.bind(K).to(iK).inSingletonScope(),r.container.bind(Q).to(iY).inSingletonScope(),r.container.bind(Y).to(i0).inSingletonScope(),r.container.bind(J).to(i2).inSingletonScope();let t=r.container.get(_);t.registerDynamicType(r.container.get(G)),t.registerDynamicType(r.container.get(U)),t.registerDynamicType(r.container.get(K)),t.registerDynamicType(r.container.get(Q)),t.registerDynamicType(r.container.get(Y)),t.registerDynamicType(r.container.get(J)),r.container.bind(Z).to(np).inSingletonScope(),r.container.bind(ee).to(nm).inSingletonScope(),r.container.bind(et).to(nh).inSingletonScope(),r.container.bind(ea).to(nx).inSingletonScope(),r.container.bind(er).to(ny).inSingletonScope(),r.container.bind(ei).to(nj).inSingletonScope(),r.container.bind(en).to(nC).inSingletonScope(),r.container.bind(eo).to(nw).inSingletonScope(),r.container.bind(el).to(nT).inSingletonScope(),r.container.bind(es).to(nD).inSingletonScope(),r.container.bind(ed).to(nF).inSingletonScope(),r.container.bind(ec).to(n$).inSingletonScope(),r.container.bind(ep).to(nM).inSingletonScope(),r.container.bind(eu).to(nP).inSingletonScope(),r.container.bind(em).to(nR).inSingletonScope(),r.container.bind(eg).to(nA).inSingletonScope(),r.container.bind(eh).to(nE).inSingletonScope();let a=r.container.get(Z);for(let e of[ee,et,ea,er,ei,en,eo,el,es,ed,ec,ep,eu,em,eg,eh])a.registerDynamicType(r.container.get(e));r.container.bind(ef).to(rW).inSingletonScope(),r.container.bind(ex).to(rG).inSingletonScope(),r.container.bind(ev).to(rK).inSingletonScope(),r.container.bind(ey).to(rY).inSingletonScope(),r.container.bind(eb).to(rZ).inSingletonScope(),r.container.bind(ej).to(r1).inSingletonScope(),r.container.bind(eS).to(r3).inSingletonScope(),r.container.bind(eC).to(r9).inSingletonScope(),r.container.bind(eI).to(r4).inSingletonScope(),r.container.bind(ew).to(r7).inSingletonScope(),r.container.bind(eT).to(it).inSingletonScope(),r.container.bind(eV).to(ii).inSingletonScope(),r.container.bind(eD).to(iu).inSingletonScope(),r.container.bind(eN).to(im).inSingletonScope(),r.container.bind(eF).to(ig).inSingletonScope(),r.container.bind(ek).to(ih).inSingletonScope(),r.container.bind(e$).to(ix).inSingletonScope(),r.container.bind(eL).to(iv).inSingletonScope(),r.container.bind(eM).to(iy).inSingletonScope(),r.container.bind(eP).to(ib).inSingletonScope(),r.container.bind(eR).to(ij).inSingletonScope(),r.container.bind(eA).to(il).inSingletonScope(),r.container.bind(eO).to(iS).inSingletonScope(),r.container.bind(eE).to(iC).inSingletonScope(),r.container.bind(eB).to(iI).inSingletonScope(),r.container.bind(ez).to(iw).inSingletonScope(),r.container.bind(eH).to(iT).inSingletonScope(),r.container.bind(eq).to(iD).inSingletonScope(),r.container.bind(eW).to(iN).inSingletonScope(),r.container.bind(eX).to(id).inSingletonScope();let i=r.container.get(ef);for(let e of[ex,ev,ey,eb,ej,eS,eC,eI,ew,eT,eD,eN,eF,ek,e$,eL,eM,eP,eR,eA,eO,eE,eB,ez,eH,eq,eW,eV,eX])i.registerDynamicType(r.container.get(e));r.container.bind(e_).to(i3).inSingletonScope(),r.container.bind(eG).to(i7).inSingletonScope(),r.container.bind(eU).to(no).inSingletonScope(),r.container.bind(eK).to(ns).inSingletonScope(),r.container.bind(eQ).to(nc).inSingletonScope();let n=r.container.get(e_);n.registerDynamicType(r.container.get(eG)),n.registerDynamicType(r.container.get(eU)),n.registerDynamicType(r.container.get(eK)),n.registerDynamicType(r.container.get(eQ)),setTimeout(()=>{let e;try{e=r.container.get("ChangeControl/Review/SurfaceRegistry")}catch{return}"function"==typeof(null==e?void 0:e.register)&&e.register("data-importer-config",rz)},0)}},nz=e=>{let{configName:t,onChange:a,onDelete:r}=e,{data:o,error:l,isLoading:s,isFetching:p,refetch:u,requestId:m}=tu({name:t},{refetchOnMountOrArgChange:!0}),[g,{isLoading:h}]=tm();(0,n.useEffect)(()=>{(0,a3.isNil)(l)||(0,d.trackConfigError)(l)},[l]);let f=s||p,x=(0,n.useMemo)(()=>(null==o?void 0:o.configuration)??{},[null==o?void 0:o.configuration]),v=(null==o?void 0:o.userPermissions)??{},y=(null==x?void 0:x.general)??{},b=!0===v.update&&!1!==y.writeable,j=!0===v.delete&&!1!==y.writeable,S=!1!==y.writeable&&!0!==v.update?"data-hub.config.no-update-permission":"config_not_writeable",C=async(e,a)=>{var r;let i=await g({name:t,bundleDataImporterConfigurationSaveParameters:{configuration:e,modificationDate:a}});if("error"in i)throw new c.ApiError(i.error??{});return{modificationDate:null==(r=i.data)?void 0:r.modificationDate}};return(0,i.jsx)(rt,{configName:t,configuration:x,isLoading:f,isWriteable:b,modificationDate:null==o?void 0:o.modificationDate,onChange:a,onSave:C,renderToolbar:e=>{let{isDirty:a,onSave:n}=e;return(0,i.jsx)(d.ConfigToolbar,{canDelete:j,configName:t,isDirty:a,isLoading:f,isSaving:h,isWriteable:b,onDelete:r,onRefresh:u,onSave:n,saveDisabledTooltipKey:S})},requestId:m})};class nH extends d.DynamicTypeDataHubAdapterAbstract{getIcon(){return{type:"name",value:"data-objects-importer",colorToken:"colorCodingPurple3"}}renderDetailView(e){return(0,i.jsx)(nz,{...e})}constructor(...e){super(...e),this.id="dataImporterDataObject"}}nH=(0,rH.Cg)([(0,l.injectable)()],nH),void 0!==(e=a.hmd(e)).hot&&e.hot.accept();let nq={name:"data-importer-plugin",onInit:e=>{let{container:t}=e;t.bind(String(B)).to(nH).inSingletonScope()},onStartup:e=>{let{moduleSystem:t}=e;t.registerModule(nB),console.log("Hello from data importer bundle.")}}}}]);